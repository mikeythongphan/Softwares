﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.Interface.Repository.Main.SalesCoordinators;
using LITS.Interface.Service.Main.SalesCoordinators;
using LITS.Service.Main.SalesCoordinators;
using LITS.Model.Views.Main;
using LITS.UI.Custom;

namespace LITS.UI.Areas.AutoLoanCorporate.Controllers
{
    public class SCMakerController : Controller
    {
        //private readonly ISalesCoordinatorsService salesCoordinatorsService;
        //private readonly IApplicationInformationService applicationInformationService;
        //private readonly ICustomerInformationService customerInformationService;

        //public MakerController(ISalesCoordinatorsService _salesCoordinatorsService,
        //    IApplicationInformationService _applicationInformationService,
        //    ICustomerInformationService _customerInformationService)
        //{
        //    this.salesCoordinatorsService = _salesCoordinatorsService;
        //    this.applicationInformationService = _applicationInformationService;
        //    this.customerInformationService = _customerInformationService;
        //}

        #region variables
        const string SalesCoordinators_ApplicationInput_DeduplicateGrid = "SalesCoordinators_ApplicationInput_DeduplicateGrid";



        #endregion


        // GET: SCMaker
        [ExceptionHandler]
        public ActionResult Index()
        {
            //SalesCoordinatorsViewModel obj = new SalesCoordinatorsViewModel();
            //var app = applicationInformationService.GetAll();
            //var cust = customerInformationService.GetAll();

            //obj.applicationInformationViewModel.Add(app);
            //obj.customerInformationViewModel.Add(cust);

            return View("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/SalesCoordinators.cshtml");
        }

        #region ApplicationInput

        public ActionResult _ApplicationInput_DeduplicateGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult _ApplicationInput_DeduplicateGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult _ApplicationInput_DeduplicateGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult _ApplicationInput_DeduplicateGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        #endregion

        #region LegalRepresentativeInformation
        public ActionResult SalesCoordinators_LegalInformation_IdentifCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }

        public ActionResult SalesCoordinators_LegalInformation_IdentifCationGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }

        public ActionResult SalesCoordinators_LegalInformation_IdentifCationGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }

        public ActionResult SalesCoordinators_LegalInformation_IdentifCationGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }
        #endregion

        #region CompanyIncome

        public ActionResult SalesCoordinators_CompanyIncome_TypeOfIGMVATGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_TypeOfIGMVATGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_TypeOfIGMVATGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_TypeOfIGMVATGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }

     
        public ActionResult SalesCoordinators_CompanyIncome_TypeOfIGMBankGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_TypeOfIGMBankGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_TypeOfIGMBankGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_TypeOfIGMBankGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }


        public ActionResult SalesCoordinators_CompanyIncome_CPPGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_CPPGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_CPPGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_CPPGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }

        public ActionResult SalesCoordinators_CompanyIncome_OtherIncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_OtherIncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_OtherIncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        public ActionResult SalesCoordinators_CompanyIncome_OtherIncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        #endregion

        #region BorrowerCreditBureau
        public ActionResult SalesCoordinators_BorrowerCreditBureau_Grid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }
        public ActionResult SalesCoordinators_BorrowerCreditBureau_Grid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }
        public ActionResult SalesCoordinators_BorrowerCreditBureau_Grid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }
        public ActionResult SalesCoordinators_BorrowerCreditBureau_Grid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }

        public ActionResult SalesCoordinators_BorrowerCreditBureau_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        public ActionResult SalesCoordinators_BorrowerCreditBureau_CreditCardGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        public ActionResult SalesCoordinators_BorrowerCreditBureau_CreditCardGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        public ActionResult SalesCoordinators_BorrowerCreditBureau_CreditCardGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        #endregion

        #region CarSalesInformation
        public ActionResult SalesCoordinators_CarSalesInformation_Grid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }
        public ActionResult SalesCoordinators_CarSalesInformation_Grid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }
        public ActionResult SalesCoordinators_CarSalesInformation_Grid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }
        public ActionResult SalesCoordinators_CarSalesInformation_Grid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }
        #endregion

    }
}
