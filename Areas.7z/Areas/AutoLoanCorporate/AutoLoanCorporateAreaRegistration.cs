﻿using System.Web.Mvc;

namespace LITS.UI.Areas.AutoLoanCorporate
{
    public class AutoLoanCorporateAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "AutoLoanCorporate";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "AutoLoanCorporate_default",
                "AutoLoanCorporate/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional },
                namespaces: new[] { "LITS.UI.Areas.AutoLoanCorporate.Controllers" }
            );
        }
    }
}