﻿using System.Web.Mvc;

namespace LITS.UI.Areas.AutoLoanPersonal
{
    public class AutoLoanPersonalAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "AutoLoanPersonal";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "AutoLoanPersonal_default",
                "AutoLoanPersonal/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional },
                namespaces: new[] { "LITS.UI.Areas.AutoLoanPersonal.Controllers" }
            );
        }
    }
}