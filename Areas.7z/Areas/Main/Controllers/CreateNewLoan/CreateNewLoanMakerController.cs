﻿using LITS.Model.PartialViews.Main.CreateNewLoan;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.UI.Controllers;
using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Common;
using LITS.Interface.Service.Main.CreateNewLoan;


namespace LITS.UI.Areas.Main.Controllers
{
    public class CreateNewLoanMakerController : BaseController
    {
        private readonly ICreateNewLoanService _CreateNewLoanService;

        public CreateNewLoanMakerController(IUnitOfWorkManager unitOfWorkManager,
            ICreateNewLoanService createNewLoanService)
            : base(unitOfWorkManager)
        {
            this._CreateNewLoanService = createNewLoanService;
        }


        #region Variables
        const string CreateNewLoan_TreeList = "CreateNewLoan_TreeList";
        const string Step2_Selected = "Step2_Selected";


        #endregion

        #region Index
        // GET: CreateNewLoanMaker
        public ActionResult Index()
        {
            var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            var controller = ControllerContext.RouteData.Values["controller"].ToString();

            LITS.Model.Views.Main.CreateNewLoanViewModel obj = new Model.Views.Main.CreateNewLoanViewModel();
            obj = _CreateNewLoanService.LoadIndexStep1(obj, area, controller, User.Identity.Name);

            Session[CreateNewLoan_TreeList] = obj._CreateNewLoanStep1ViewModel.lstCreateNewLoanStep1Tree;
            Session[Step2_Selected] = null;

            return View("~/Areas/Main/Views/CreateNewLoan/CreateNewLoan.cshtml");
        }

        #endregion

        #region CreateNewLoan_TreeList
        public ActionResult CreateNewLoan_TreeList_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step1_TreeList.cshtml", Session[CreateNewLoan_TreeList]);
        }
        #endregion

        #region CallbackPanel
        public ActionResult cpStep2_Callback()
        {
            var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            var controller = ControllerContext.RouteData.Values["controller"].ToString();

            LITS.Model.Views.Main.CreateNewLoanViewModel obj = new Model.Views.Main.CreateNewLoanViewModel();
            obj = _CreateNewLoanService.LoadIndexStep2(obj, area, controller, User.Identity.Name);

            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2.cshtml", obj._CreateNewLoanStep2ViewModel);
        }

        public int setSession_Step2_Selected(int? nodeKeySelected, int? typeSelected)
        {
            Session[Step2_Selected] = Json(new { NodeKeySelected = nodeKeySelected, TypeSelected = typeSelected }, JsonRequestBehavior.AllowGet);
            return 0;
        }

        #endregion


    }
}