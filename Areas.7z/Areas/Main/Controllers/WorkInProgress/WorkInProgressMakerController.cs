﻿using LITS.Model.PartialViews.Main.WorkInProgress;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.UI.Controllers;
using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Common;
using LITS.Interface.Service.Main.WorkInProgress;

namespace LITS.UI.Areas.Main.Controllers
{
    public class WorkInProgressMakerController : BaseController
    {
        private readonly IWorkInProgressService _WorkInProgressService;

        public WorkInProgressMakerController(IUnitOfWorkManager unitOfWorkManager,
            IWorkInProgressService workInProgressService)
            : base(unitOfWorkManager)
        {
            this._WorkInProgressService = workInProgressService;
        }


        #region Variables
        const string WorkInProgress_TreeList = "WorkInProgress_TreeList";
        const string WorkInProgress_Detail_Grid = "WorkInProgress_Detail_Grid";
        const string cbCustomerName_WorkInProgress = "cbCustomerName_WorkInProgress";
        const string cbCompanyName_WorkInProgress = "cbCompanyName_WorkInProgress";


        #endregion

        #region Index
        // GET: WorkInProgressMaker
        public ActionResult Index()
        {
            LITS.Model.Views.Main.WorkInProgressViewModel obj = new Model.Views.Main.WorkInProgressViewModel();
            obj = _WorkInProgressService.LoadIndex();

            Session[WorkInProgress_TreeList] = obj._WorkInProgressTreeViewModel;
            Session[WorkInProgress_Detail_Grid] = null;
            Session[cbCustomerName_WorkInProgress] = obj._WorkInProgressMasterViewModel._WorkInProgressMasterCustomerViewModel;
            Session[cbCompanyName_WorkInProgress] = obj._WorkInProgressMasterViewModel._WorkInProgressMasterCompanyViewModel;

            return View("~/Areas/Main/Views/WorkInProgress/WorkInProgress.cshtml", obj);
        }
        #endregion

        #region WorkInProgress_TreeList
        public ActionResult WorkInProgress_TreeList_Callback()
        {
            return PartialView("~/Areas/Main/Views/WorkInProgress/PartialViews/_TreeList.cshtml", Session[WorkInProgress_TreeList]);
        }
        #endregion

        #region WorkInProgress_Detail_Grid
        public ActionResult WorkInProgress_Detail_Grid_Callback(string treeListSelected, DateTime? fromDate, DateTime? toDate,
            int? status, string applicationNo, string customerName, string companyName)
        {
            if (!string.IsNullOrEmpty(treeListSelected) || fromDate.HasValue || toDate.HasValue
                || status.HasValue || !string.IsNullOrEmpty(applicationNo) || !string.IsNullOrEmpty(customerName) || !string.IsNullOrEmpty(companyName))
            {
                // Select TreeList
                List<WorkInProgressTreeViewModel> _WorkInProgressTreeViewModel = new List<WorkInProgressTreeViewModel>();
                foreach (var s in treeListSelected.Split(','))
                {
                    _WorkInProgressTreeViewModel.Add(new WorkInProgressTreeViewModel()
                    {
                        ID = Convert.ToInt32(s)
                    });
                };

                // Master Select Field
                WorkInProgressMasterViewModel _WorkInProgressMasterViewModel = new WorkInProgressMasterViewModel()
                {
                    FromDate = fromDate,
                    ToDate = toDate,
                    StatusID = status,
                    ApplicationNo = applicationNo,
                    CustomerName = customerName,
                    CompanyName = companyName
                };

                // obj for params function search data
                LITS.Model.Views.Main.WorkInProgressViewModel obj = new Model.Views.Main.WorkInProgressViewModel()
                {
                    _WorkInProgressMasterViewModel = _WorkInProgressMasterViewModel,
                    _WorkInProgressTreeViewModel = _WorkInProgressTreeViewModel
                };

                // Call function search data
                var area = ControllerContext.RouteData.DataTokens["area"].ToString();
                var controller = ControllerContext.RouteData.Values["controller"].ToString();

                LITS.Model.Views.Main.WorkInProgressViewModel data = new Model.Views.Main.WorkInProgressViewModel();
                data = _WorkInProgressService.SearchData(obj, area, controller);

                Session[WorkInProgress_Detail_Grid] = data._WorkInProgressDetailViewModel;
            }

            return PartialView("~/Areas/Main/Views/WorkInProgress/PartialViews/_Detail_Grid.cshtml", Session[WorkInProgress_Detail_Grid]);
        }
        #endregion

        #region WorkInProgress_Detail_Grid_child
        public ActionResult WorkInProgress_Detail_Grid_child_Callback(int? ApplicationID)
        {
            // viewdata set name Grid child for not duplicate
            ViewData["ApplicationID"] = ApplicationID;

            // Call function load data for child grid
            var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            var controller = ControllerContext.RouteData.Values["controller"].ToString();

            LITS.Model.Views.Main.WorkInProgressViewModel data = new Model.Views.Main.WorkInProgressViewModel();
            data = _WorkInProgressService.LoadChildDetail(ApplicationID.Value, area, controller);

            return PartialView("~/Areas/Main/Views/WorkInProgress/PartialViews/_Detail_Grid_child.cshtml", data._WorkInProgressDetailChildViewModel);
        }
        #endregion

        #region Combobox LargeData
        public ActionResult cbCustomerName_WorkInProgress_Callback()
        {
            return PartialView("~/Areas/Main/Views/WorkInProgress/PartialViews/_cbCustomerName.cshtml");
        }

        public static IEnumerable<WorkInProgressMasterCustomerViewModel> Get_CustomerName_ByCondition(DevExpress.Web.ListEditItemsRequestedByFilterConditionEventArgs args)
        {
            // Get Data
            var data = (List<WorkInProgressMasterCustomerViewModel>)System.Web.HttpContext.Current.Session[cbCustomerName_WorkInProgress];

            var skip = args.BeginIndex;
            var take = args.EndIndex - args.BeginIndex + 1;
            var query = (from dt in data
                         where dt.CustomerName.ToUpper().Contains(args.Filter.ToUpper())
                            || dt.CustomerIdentification.ToUpper().Contains(args.Filter.ToUpper())
                         orderby dt.CustomerName
                         select dt
                    ).Skip(skip).Take(take);

            return query.ToList();
        }

        public static WorkInProgressMasterCustomerViewModel Get_CustomerName_ByID(DevExpress.Web.ListEditItemRequestedByValueEventArgs args)
        {
            // Get Data
            var data = (List<WorkInProgressMasterCustomerViewModel>)System.Web.HttpContext.Current.Session[cbCustomerName_WorkInProgress];

            int id;
            if (args.Value == null || !int.TryParse(args.Value.ToString(), out id))
                return null;
            return data.Where(p => p.CustomerID == id).Take(1).SingleOrDefault();
        }


        public ActionResult cbCompanyName_WorkInProgress_Callback()
        {
            return PartialView("~/Areas/Main/Views/WorkInProgress/PartialViews/_cbCompanyName.cshtml");
        }

        public static IEnumerable<WorkInProgressMasterCompanyViewModel> Get_CompanyName_ByCondition(DevExpress.Web.ListEditItemsRequestedByFilterConditionEventArgs args)
        {
            // Get Data
            var data = (List<WorkInProgressMasterCompanyViewModel>)System.Web.HttpContext.Current.Session[cbCompanyName_WorkInProgress];

            var skip = args.BeginIndex;
            var take = args.EndIndex - args.BeginIndex + 1;
            var query = (from dt in data
                         where dt.CompanyName.ToUpper().Contains(args.Filter.ToUpper())
                            || dt.CompanyCode.ToUpper().Contains(args.Filter.ToUpper())
                         orderby dt.CompanyName
                         select dt
                    ).Skip(skip).Take(take);

            return query.ToList();
        }

        public static WorkInProgressMasterCompanyViewModel Get_CompanyName_ByID(DevExpress.Web.ListEditItemRequestedByValueEventArgs args)
        {
            // Get Data
            var data = (List<WorkInProgressMasterCompanyViewModel>)System.Web.HttpContext.Current.Session[cbCompanyName_WorkInProgress];

            int id;
            if (args.Value == null || !int.TryParse(args.Value.ToString(), out id))
                return null;
            return data.Where(p => p.CompanyID == id).Take(1).SingleOrDefault();
        }
        #endregion


    }
}