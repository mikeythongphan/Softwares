﻿using RaoTorrent.Core.Controls.DeviceDirectory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RaoTorrent.Core.Providers
{
    public static class ServiceProvider
    {

        public static TService GetService<TService>() => GetCurrent().GetService<TService>();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static IServiceProvider GetCurrent()
        {
#if WINDOWS10_0_17763_0_OR_GREATER
			return MauiWinUIApplication.Current.Services;
#elif ANDROID
            return MauiApplication.Current.Services;
#elif IOS || MACCATALYST
			return MauiUIApplicationDelegate.Current.Services;
#else
			return null;
#endif
        }
    }
}
