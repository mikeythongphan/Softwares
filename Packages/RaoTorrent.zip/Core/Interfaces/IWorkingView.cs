﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RaoTorrent.Core.Interfaces
{
    public interface IWorkingView
    {
        string StatusMessage { get; set; }
    }
}
