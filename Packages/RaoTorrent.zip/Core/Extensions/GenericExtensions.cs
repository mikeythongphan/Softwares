﻿using System.Collections.ObjectModel;

namespace RaoTorrent.Core.Extensions
{
    public static class GenericExtensions
    {

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obs"></param>
        /// <param name="objs"></param>
        public static void  Refresh<T>(this ObservableCollection<T> obs, List<T> objs)
        {
            obs.Clear();
            objs.ForEach(obs.Add);
        }
    }
}
