﻿using System.Windows.Input;

namespace RaoTorrent.Core.Controls;

public class Button : ContentView
{

    public event EventHandler Clicked;

    public bool HasBorder
    {
        get => Border.BorderColor == Colors.Transparent;
        set => Border.BorderColor = value ?  Colors.LightGray : Colors.Transparent;
    }

    public string Text
    {
        get => ItemText.Text;
        set => ItemText.Text = value;
    }

    public string FontFamily
    {
        get => ItemText.FontFamily;
        set => ItemText.FontFamily = value;
    }

    /// <summary>
    /// 
    /// </summary>
    private ICommand _command;
    public ICommand Command
    {
        get => _command;
        set => _command = value;
    }

    /// <summary>
    /// 
    /// </summary>
    private object _commandParam;
    public object CommandParam
    {
        get => _commandParam;
        set => _commandParam = value;
    }

    private Grid Wrapper { get; set; } = new Grid();
    private Frame Border { get; set; } = new Frame();
    private Label ItemText { get; set; } = new Label();

    /// <summary>
    /// 
    /// </summary>
    public Button()
    {
        InitializeComponent();
    }

    /// <summary>
    /// 
    /// </summary>
    private void InitializeComponent()
    {

        ItemText.HorizontalOptions = LayoutOptions.Center;
        ItemText.VerticalOptions = LayoutOptions.Center;
        ItemText.LineBreakMode = LineBreakMode.NoWrap;
        ItemText.FontSize = 12;

        Border.CornerRadius = 5;
        Border.BorderColor = Colors.LightGray;
        Border.HasShadow = false;
        Border.Padding = new Thickness(5,3,5,3);
        Border.Content = ItemText;

        Wrapper.Children.Add(Border);

        GestureRecognizers.Add(new TapGestureRecognizer
        {
            Command = new Command(() =>
            {
                Clicked?.Invoke(this, EventArgs.Empty);
                if (Command != null)
                {
                    if (Command.CanExecute(CommandParam))
                        Command.Execute(CommandParam);
                }
            })


        });

        Content = Border;
    }

}
