﻿
namespace RaoTorrent.Core.Controls
{
    public class Spinner50 : ContentView
    {

        private Image SpinnerObj {  get; set; } = new Image();

        /// <summary>
        /// 
        /// </summary>
        public Spinner50()
        {
            SpinnerObj.Source = "loader.gif";
            SpinnerObj.WidthRequest = 50;
            SpinnerObj.VerticalOptions = LayoutOptions.Center;
            SpinnerObj.HorizontalOptions = LayoutOptions.Center;
            Content = SpinnerObj;
        }
    }
}
