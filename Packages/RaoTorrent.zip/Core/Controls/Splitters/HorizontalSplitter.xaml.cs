using System.ComponentModel;
using System.Diagnostics;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace RaoTorrent.Core.Controls;

public partial class HorizontalSplitter : ContentView
{

    /// <summary>
    /// 
    /// </summary>
    public static readonly BindableProperty LeftViewWidthProperty = BindableProperty.Create(nameof(LeftViewWidth),
        typeof(GridLength), typeof(HorizontalSplitter), new GridLength(300.0d));

    [TypeConverter(typeof(GridLengthTypeConverter))]
    public GridLength LeftViewWidth
    {
        get => (GridLength)GetValue(LeftViewWidthProperty);
        set => SetValue(LeftViewWidthProperty, value);
    }

    /// <summary>
    /// 
    /// </summary>
    public static readonly BindableProperty RightViewWidthProperty = BindableProperty.Create(nameof(RightViewWidth),
        typeof(GridLength), typeof(HorizontalSplitter), GridLength.Star);

    [TypeConverter(typeof(GridLengthTypeConverter))]
    public GridLength RightViewWidth
    {
        get => (GridLength)GetValue(RightViewWidthProperty);
        set => SetValue(RightViewWidthProperty, value);
    }

    /// <summary>
    /// 
    /// </summary>
    public static readonly BindableProperty LeftViewProperty = BindableProperty.Create(nameof(LeftView),
        typeof(View), typeof(HorizontalSplitter), default(View));  
    public View LeftView
    {
        get => (View)GetValue(LeftViewProperty);
        set => SetValue(LeftViewProperty, value);
    }

    /// <summary>
    /// 
    /// </summary>
    public static readonly BindableProperty RightViewProperty = BindableProperty.Create(nameof(RightView),
        typeof(View), typeof(HorizontalSplitter), default(View));
    public View RightView
    {
        get => (View)GetValue(RightViewProperty);
        set => SetValue(RightViewProperty, value);
    }

    private double PanX { get; set; }
    private bool AllowPan { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public HorizontalSplitter()
	{
		InitializeComponent();
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    void OnPanUpdated(object sender, PanUpdatedEventArgs e)
    {

        if (!AllowPan) return;

        switch (e.StatusType)
        {
            case GestureStatus.Running:
                var width = (int)Math.Round(PanX + e.TotalX);
                if (width < 300) width = 300;
                Wrapper.ColumnDefinitions[0].Width = width - 3;
                break;
            case GestureStatus.Completed:
                PanX = Content.TranslationX;
                AllowPan = false;
                break;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnPointerEntered(object sender, PointerEventArgs e)
    {
        Wrapper.ColumnDefinitions[1].Width = 6;
        PanX = e.GetPosition(null).Value.X;
        AllowPan = true;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnPointerExited(object sender, PointerEventArgs e)
    {
        Wrapper.ColumnDefinitions[1].Width = 2;
    }

}