﻿
namespace RaoTorrent.Core.Controls
{
    public class DataGridColumnCheckBox : DataGridColumn
    {
        public CheckBox HeaderCheckBox { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DataGridColumnCheckBox()
        {
            HeaderCheckBox = new CheckBox();
            HeaderCheckBox.VerticalOptions = LayoutOptions.Center;
            HeaderCheckBox.HorizontalOptions = LayoutOptions.Center;
        }
    }

}
