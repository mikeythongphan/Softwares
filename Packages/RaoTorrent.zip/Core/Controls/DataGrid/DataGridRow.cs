namespace RaoTorrent.Core.Controls;

internal sealed class DataGridRow : Grid
{

    private Color? _bgColor;
    private Color? _textColor;
    private bool _hasSelected;

    public CheckBox ItemCheckBox { get; set; }

    public DataGrid DataGrid
    {
        get => (DataGrid)GetValue(DataGridProperty);
        set => SetValue(DataGridProperty, value);
    }

    public static readonly BindableProperty DataGridProperty =
        BindablePropertyExtensions.Create<DataGrid>(null, BindingMode.OneTime,
            propertyChanged: (b, o, n) =>
            {
                var self = (DataGridRow)b;

                if (o is DataGrid oldDataGrid)
                {
                    oldDataGrid.ItemSelected -= self.DataGridItemSelected;
                }

                if (n is DataGrid newDataGrid && newDataGrid.SelectionEnabled)
                {
                    newDataGrid.ItemSelected += self.DataGridItemSelected;
                }
            });

    /// <summary>
    /// 
    /// </summary>
    public DataGridRow()
    {
        InitializeComponent();

    }

    /// <summary>
    /// 
    /// </summary>
    private void InitializeComponent()
    {
        ItemCheckBox = new CheckBox();
        ItemCheckBox.VerticalOptions = LayoutOptions.Center;
        ItemCheckBox.HorizontalOptions = LayoutOptions.Center;
    }

    /// <summary>
    /// 
    /// </summary>
    private void CreateView()
    {
        ColumnDefinitions.Clear();
        Children.Clear();

        SetStyling();

        for (var i = 0; i < DataGrid.Columns.Count; i++)
        {
            var col = DataGrid.Columns[i];
            if (col.ColumnDefinition == null) col.ColumnDefinition = new ColumnDefinition(GridLength.Star);
            ColumnDefinitions.Add(col.ColumnDefinition);

            if (!col.IsVisible) continue;

            var cell = CreateCell(col);
            SetColumn((BindableObject)cell, i);
            Children.Add(cell);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    private void SetStyling()
    {
        UpdateColors();
        BackgroundColor = DataGrid.BorderColor;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="col"></param>
    /// <returns></returns>
    private View CreateCell(DataGridColumn col)
    {
        View cell;
        if (col is DataGridColumnCheckBox)
        {

            cell = new ContentView
            {
                BackgroundColor = _bgColor,
                Content = ItemCheckBox
            };

            if (!string.IsNullOrWhiteSpace(col.PropertyName))
            {
                ItemCheckBox.SetBinding(CheckBox.IsCheckedProperty,
                    new Binding(col.PropertyName, mode: BindingMode.TwoWay, source: BindingContext));
            }

            return cell;
        }


        if (col.CellTemplate != null)
        {
            cell = new ContentView
            {
                BackgroundColor = _bgColor,
                Content = col.CellTemplate.CreateContent() as View
            };

            if (!string.IsNullOrWhiteSpace(col.PropertyName))
                cell.SetBinding(BindingContextProperty, new Binding(col.PropertyName, source: BindingContext));
            return cell;
        }

        cell = new Label
        {
            TextColor = _textColor,
            FontSize = 12,
            BackgroundColor = _bgColor,
            VerticalOptions = LayoutOptions.Fill,
            HorizontalOptions = LayoutOptions.Fill,
            VerticalTextAlignment = col.VerticalContentAlignment.ToTextAlignment(),
            HorizontalTextAlignment = TextAlignment.Start,
            LineBreakMode = col.LineBreakMode
        };

        if (!string.IsNullOrWhiteSpace(col.PropertyName))
        {
            cell.SetBinding(Label.TextProperty,
                new Binding(col.PropertyName, BindingMode.Default, stringFormat: col.StringFormat, source: BindingContext));
        }
        cell.SetBinding(Label.FontSizeProperty,
            new Binding(DataGrid.FontSizeProperty.PropertyName, BindingMode.Default, source: DataGrid));
        cell.SetBinding(Label.FontFamilyProperty,
            new Binding(DataGrid.FontFamilyProperty.PropertyName, BindingMode.Default, source: DataGrid));

        return cell;
    }

    /// <summary>
    /// 
    /// </summary>
    private void UpdateColors()
    {
        _hasSelected = DataGrid.SelectedItem == BindingContext;
        var rowIndex = DataGrid.InternalItems?.IndexOf(BindingContext) ?? -1;

        if (rowIndex < 0) return;

        _bgColor = DataGrid.SelectionEnabled && _hasSelected
                ? DataGrid.ActiveRowColor
                : DataGrid.RowsBackgroundColorPalette.GetColor(rowIndex, BindingContext);
        _textColor = DataGrid.RowsTextColorPalette.GetColor(rowIndex, BindingContext);

        foreach (var v in Children)
        {
            if (v is View view)
            {
                view.BackgroundColor = _bgColor;

                if (view is Label label)
                {
                    label.TextColor = _textColor;
                }
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    protected override void OnBindingContextChanged()
    {
        base.OnBindingContextChanged();
        if (BindingContext != DataGrid.BindingContext) CreateView();
    }

    /// <summary>
    /// 
    /// </summary>
    protected override void OnParentSet()
    {
        base.OnParentSet();
        if (Parent == null) DataGrid.ItemSelected -= DataGridItemSelected;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void DataGridItemSelected(object? sender, SelectionChangedEventArgs e)
    {
        if (!DataGrid.SelectionEnabled) return;
        if (_hasSelected || (e.CurrentSelection.Count > 0 && e.CurrentSelection[^1] == BindingContext)) UpdateColors();
    }

}
