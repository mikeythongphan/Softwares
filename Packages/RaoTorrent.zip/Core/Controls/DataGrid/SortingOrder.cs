﻿namespace RaoTorrent.Core.Controls;

/// <summary>
/// 
/// </summary>
public enum DataGridSortingOrder
{
    None = 0,
    Ascendant = 1,
    Descendant = 2
}