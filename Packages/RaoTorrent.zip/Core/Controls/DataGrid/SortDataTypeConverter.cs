using System.ComponentModel;
using System.Globalization;

namespace RaoTorrent.Core.Controls;

/// <summary>
/// Converts string to <c>SortData</c> enum.
/// This needs to be public or it will produce a MethodAccessException
/// </summary>
public sealed class DataGridSortDataTypeConverter : TypeConverter 
{

    /// <summary>
    /// 
    /// </summary>
    /// <param name="context"></param>
    /// <param name="culture"></param>
    /// <param name="value"></param>
    /// <returns></returns>
    public override object? ConvertFrom(ITypeDescriptorContext? context, CultureInfo? culture, object value)
        => int.TryParse(value.ToString(), out var index) ? (DataGridSortData)index : base.ConvertFrom(context, culture, value);
}
