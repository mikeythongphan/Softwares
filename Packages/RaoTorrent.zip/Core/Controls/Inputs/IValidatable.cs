﻿using System.ComponentModel;

namespace RaoTorrent.Core.Controls;

public interface IValidatable : INotifyPropertyChanged
{
    public List<IValidation> Validations { get; }

    bool IsValid { get; }

    void DisplayValidation();

    void ResetValidation();
}
