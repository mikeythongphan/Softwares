﻿namespace RaoTorrent.Core.Controls.Helpers;

internal static class RadianHelper
{

    /// <summary>
    /// 
    /// </summary>
    /// <param name="angle"></param>
    /// <returns></returns>
    public static double DegreeToRadian(double angle) => Math.PI * angle / 180.0;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="angle"></param>
    /// <returns></returns>
    public static double RadianToDegree(double angle) => angle * (180.0 / Math.PI);
}
