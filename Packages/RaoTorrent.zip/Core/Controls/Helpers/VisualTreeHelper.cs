﻿namespace RaoTorrent.Core.Controls.Helpers;

public static class VisualTreeHelper
{

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="element"></param>
    /// <returns></returns>
    public static T GetParent<T>(this Element element) where T : Element
    {
        if (element is T) return element as T;
        if (element.Parent != null) return element.Parent.GetParent<T>();
        return default;
    }
}
