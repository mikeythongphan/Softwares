﻿namespace RaoTorrent.Core.Controls;

public class VerticalSeparator : ContentView
{

    public double Space
    {
        get => WidthRequest;
        set => WidthRequest = value;
    }

    /// <summary>
    /// 
    /// </summary>
    public VerticalSeparator()
    {
        Content = new BoxView
        {
            Color = Colors.Transparent,
            WidthRequest = 0,
            VerticalOptions = LayoutOptions.Fill,
        };
    }

}
