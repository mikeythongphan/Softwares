﻿namespace RaoTorrent.Core.Controls;

public class TreeViewNodeTappedEventArgs : EventArgs
{

    public TreeViewNode Node { get; set; }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="treeViewNode"></param>
    public TreeViewNodeTappedEventArgs(TreeViewNode treeViewNode)
    {
        Node = treeViewNode;
    }

}