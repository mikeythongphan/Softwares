﻿using System.ComponentModel;

namespace RaoTorrent.Core.Controls;

public partial class TreeView : ContentView
{

    private TreeViewNodes _rootNodes = new TreeViewNodes();
    public TreeViewNodes RootNodes
    {
        get => _rootNodes;
        set 
        {
            _rootNodes = value;
            UpdatetNodes();
        }
    }

    private TreeViewSelectionMode _selectionMode = TreeViewSelectionMode.Single;
    public TreeViewSelectionMode SelectionMode
    {
        get => _selectionMode;
        set => _selectionMode = value;
    }

    public TreeViewNode SelectedItem { get; set; }

    private double _indentation = 24.0d;
    public double Indentation
    {
        get => _indentation;
        set => _indentation = value;
    }

    private Color _backgroundColor = Color.FromArgb("#FFF");
    public new Color BackgroundColor
    {
        get => _backgroundColor;
        set => _backgroundColor = value;
    }

    private Color _backgroundColorSelected = Color.FromArgb("#2687FB");
    public Color BackgroundColorSelected
    {
        get => _backgroundColorSelected;
        set => _backgroundColorSelected = value;
    }

    private Color _textColor = Color.FromArgb("#000");
    public Color TextColor
    {
        get => _textColor;
        set => _textColor = value;
    }

    private Color _textColorSelected = Color.FromArgb("#FFF");
    public Color TextColorSelected
    {
        get => _textColorSelected;
        set => _textColorSelected = value;
    }

    private double _fontSize = 12.0d;
    public double FontSize
    {
        get => _fontSize;
        set => _fontSize = value;
    }

    private double _fontSizeSelectd = 12.0d;
    public double FontSizeSelected
    {
        get => _fontSizeSelectd;
        set => _fontSizeSelectd = value;
    }

    public event EventHandler SelectedItemChanged;
    public event EventHandler<TreeViewNodeTappedEventArgs> ItemTapped;
    public event EventHandler<TreeViewNodeDoubleTappedEventArgs> ItemDoubleTapped;

    protected StackLayout TreeViewContainer { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public TreeView()
    {
        TreeViewContainer = new StackLayout();
        var content = new ScrollView();
        content.Content = TreeViewContainer;
        Content = content;
    }

    /// <summary>
    /// 
    /// </summary>
    public void Clear()
    {
        TreeViewContainer.Children.Clear();
        RootNodes.Clear();
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="selectedItem"></param>
    /// <param name="isSelected"></param>
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal void UpdateSelectedItem(TreeViewNode selectedItem, bool isSelected)
    {
        if (SelectionMode == TreeViewSelectionMode.None) return;
        if (SelectedItem == selectedItem) return;

        UnSelectItems(RootNodes);
        selectedItem.IsSelected = isSelected;
        SelectedItem = isSelected ? selectedItem : null;
        SelectedItemChanged?.Invoke(this, EventArgs.Empty);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="args"></param>
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal void SendItemTapped(TreeViewNodeTappedEventArgs args)
    {
        ItemTapped?.Invoke(this, args);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="args"></param>
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal void SendItemDoubleTapped(TreeViewNodeDoubleTappedEventArgs args)
    {
        ItemDoubleTapped?.Invoke(this, args);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="treeViewNodes"></param>
    void UnSelectItems(TreeViewNodes treeViewNodes)
    {

        if (treeViewNodes == null) return;

        foreach (var childNode in treeViewNodes)
        {
            childNode.IsSelected = false;
            childNode.UpdateLayout();
            UnSelectItems(childNode.Children);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    void UpdatetNodes()
    {
        if (RootNodes == null || RootNodes.Count == 0) return;

        foreach (var childNode in RootNodes)
        {
            if (TreeViewContainer.Children.Contains(childNode)) continue;
            
            UpdateTreeViewNodes(childNode);
            try
            {
                TreeViewContainer.Children.Add(childNode);
            }
            catch (Exception ex)
            {
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="treeViewNode"></param>
    void UpdateTreeViewNodes(TreeViewNode treeViewNode)
    {
        UpdateTreeViewNode(treeViewNode);

        if (treeViewNode.Children != null)
        {
            foreach (var childNode in treeViewNode.Children)
                UpdateTreeViewNodes(childNode);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="treeViewNode"></param>
    void UpdateTreeViewNode(TreeViewNode treeViewNode)
    {

        if (treeViewNode == null) return;

        if (treeViewNode.ParentNode == null) treeViewNode.Indentation = 0;
        else treeViewNode.Indentation = treeViewNode.ParentNode.Indentation + 10;

        treeViewNode.BackgroundColor = BackgroundColor;
        treeViewNode.BackgroundColorSelected = BackgroundColorSelected;
        treeViewNode.TextColor = TextColor;
        treeViewNode.TextColorSelected = TextColorSelected;
        treeViewNode.FontSize = FontSize;
        treeViewNode.FontSizeSelected = FontSizeSelected;

    }
}
