﻿namespace RaoTorrent.Core.Controls;

public enum TreeViewSelectionMode
{
    None,
    Single
}