﻿using RaoTorrent.Core.Controls.Helpers;
using System.Runtime.CompilerServices;

namespace RaoTorrent.Core.Controls;

public class TreeViewNode : ContentView
{

    public TreeViewNode ParentNode { get; set; }
    public TreeView TreeView { get; set; }

    /// <summary>
    /// 
    /// </summary>
    private bool _hasChildren;
    public bool HasChildren
    {
        get => _hasChildren;
        private set => _hasChildren = value;
    }

    /// <summary>
    /// 
    /// </summary>
    private TreeViewNodes _childrent;
    public new TreeViewNodes Children
    {
        get => _childrent;
        set
        {
            _childrent = value;
            HasChildren = value != null & value.Count > 0;
            UpdateChildren();
        }
    }

    public string Text
    {
        get => ItemText.Text;
        set { ItemText.Text = value; }
    }

    public ImageSource Icon
    {
        get => ItemIcon.Source;
        set => ItemIcon.Source = value;
    }

    public ImageSource IconSelected
    {
        get => ItemIcon.Source;
        set => ItemIcon.Source = value;
    }

    /// <summary>
    /// 
    /// </summary>
    private double _isIndentation;
    public double Indentation
    {
        get => _isIndentation;
        set 
        {
            _isIndentation = value;
            UpdateCurrent();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    private bool _isExpanded;
    public bool IsExpanded
    {
        get => _isExpanded;
        set 
        {
            _isExpanded = value;
            UpdateIsExpanded();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    private bool _isSelected;
    public bool IsSelected
    {
        get => _isSelected;
        set 
        {
            _isSelected = value;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    private Color _backgroundColor = Color.FromArgb("#FFF");
    public new Color BackgroundColor
    {
        get => _backgroundColor;
        set => _backgroundColor = value;
    }

    /// <summary>
    /// 
    /// </summary>
    private Color _backgroundColorSelected = Color.FromArgb("#2687FB");
    public Color BackgroundColorSelected
    {
        get => _backgroundColorSelected;
        set => _backgroundColorSelected = value;
    }

    /// <summary>
    /// 
    /// </summary>
    private Color _textColor = Color.FromArgb("#000");
    public Color TextColor
    {
        get => _textColor;
        set => _textColor = value;
    }

    /// <summary>
    /// 
    /// </summary>
    private Color _textColorSelected = Color.FromArgb("#FFF");
    public Color TextColorSelected
    {
        get => _textColorSelected;
        set => _textColorSelected = value;
    }

    /// <summary>
    /// 
    /// </summary>
    private double _fontSize = 12.0d;
    public double FontSize
    {
        get => _fontSize;
        set => _fontSize = value;
    }

    /// <summary>
    /// 
    /// </summary>
    private double _fontSizeSelected = 12.0d;
    public double FontSizeSelected
    {
        get => _fontSizeSelected;
        set => _fontSizeSelected = value;
    }

    public event EventHandler<TreeViewNodeExpandedCollapsedEventArgs> Expanded;
    public event EventHandler<TreeViewNodeExpandedCollapsedEventArgs> Collapsed;

    private StackLayout Wrapper { get; set; } = new StackLayout();
    protected Grid TreeItem { get; set; } = new Grid();
    private StackLayout ChildContainer { get; set; } = new StackLayout();
    protected Grid ItemIndicator { get; set; } = new Grid();
    private Image ItemIcon { get; set; } = new Image();
    private Label ItemText { get; set; } = new Label();
    private Label RightIndicator { get; set; } = new Label();
    private Label DownIndicator { get; set; } = new Label();

    /// <summary>
    /// 
    /// </summary>
    public TreeViewNode()
    {
        InitializeComponent();
        UpdateIsEnabled();
        UpdateIsExpanded();
    }

    /// <summary>
    /// 
    /// </summary>
    private void InitializeComponent()
    {

        Wrapper = new StackLayout
        {
            BindingContext = this,
        };

        TreeItem.Margin = new Thickness(Indentation, 0, 0, 0);
        TreeItem.ColumnSpacing = 0;
        TreeItem.ColumnDefinitions.Add(new ColumnDefinition(15));
        TreeItem.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));
        TreeItem.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));

        ItemIndicator = new Grid();

        ItemIcon.WidthRequest = 15;
        ItemIcon.Source = Icon;
        ItemIcon.HorizontalOptions = LayoutOptions.Start;
        ItemIcon.VerticalOptions = LayoutOptions.Center;
                    
        ItemText.HorizontalOptions = LayoutOptions.Start;
        ItemText.VerticalOptions = LayoutOptions.Center;
        ItemText.Margin = new Thickness(5, 0, 0, 0);

        RightIndicator.FontFamily = "FontAwesomeSolid";
        RightIndicator.Text = "\uf054;";
        RightIndicator.TextColor = Colors.LightGray;
        RightIndicator.FontSize = 12;
        RightIndicator.VerticalOptions = LayoutOptions.Center;
        RightIndicator.Margin = new Thickness(2, 0, 0, 0);

        DownIndicator.FontFamily = "FontAwesomeSolid";
        DownIndicator.Text = "\uf078;";
        DownIndicator.TextColor = Colors.LightGray;
        DownIndicator.FontSize = 12;
        DownIndicator.VerticalOptions = LayoutOptions.Center;
        DownIndicator.Margin = new Thickness(2, 0, 0, 0);

        ItemIndicator.Children.Add(RightIndicator);
        ItemIndicator.Children.Add(DownIndicator);

        Grid.SetColumn(ItemIndicator, 0);
        Grid.SetColumn(ItemIcon, 1);
        Grid.SetColumn(ItemText, 2);

        TreeItem.Children.Add(ItemIndicator);
        TreeItem.Children.Add(ItemIcon);
        TreeItem.Children.Add(ItemText);

        Wrapper.Children.Add(TreeItem);
        Wrapper.Children.Add(ChildContainer);
        Content = Wrapper;
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="width"></param>
    /// <param name="height"></param>
    protected override void OnSizeAllocated(double width, double height)
    {
        base.OnSizeAllocated(width, height);

        UpdateLayout();
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="propertyName"></param>
    protected override void OnPropertyChanged([CallerMemberName] string propertyName = null)
    {
        base.OnPropertyChanged(propertyName);

        if (propertyName == IsEnabledProperty.PropertyName) UpdateIsEnabled();
    }

    /// <summary>
    /// 
    /// </summary>
    private void UpdateChildren()
    {

        RightIndicator.IsVisible = !IsExpanded & HasChildren;
        DownIndicator.IsVisible = IsExpanded & HasChildren;

        if (Children == null || Children.Count == 0) return;

        foreach (var childNode in Children)
            if (!ChildContainer.Children.Contains(childNode))
                ChildContainer.Children.Add(childNode);
    }

    /// <summary>
    /// 
    /// </summary>
    private void UpdateIsEnabled()
    {
        if (IsEnabled)
        {
            var indicatorGesture = new TapGestureRecognizer();
            indicatorGesture.Tapped += OnIndicatorTapped;
            ItemIndicator.GestureRecognizers.Add(indicatorGesture);

            var textGesturedTap = new TapGestureRecognizer();
            textGesturedTap.Tapped += OnTextTapped;
            ItemText.GestureRecognizers.Add(textGesturedTap);

            var textGesturedDoubleTap = new TapGestureRecognizer
            {
                NumberOfTapsRequired = 2
            };

            textGesturedDoubleTap.Tapped += OnTextDoubleTapped;
            ItemText.GestureRecognizers.Add(textGesturedDoubleTap);
        }
        else
        {
            // TODO: Remove only specific gestures.
            ItemIndicator.GestureRecognizers.Clear();
            ItemText.GestureRecognizers.Clear();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    private void UpdateCurrent()
    {
        // TODO: Refactor (Optimize).
        if (TreeView == null) TreeView = VisualTreeHelper.GetParent<TreeView>(this);
        TreeView?.UpdateSelectedItem(this, IsSelected);
        UpdateLayout();
    }

    /// <summary>
    /// 
    /// </summary>
    public void UpdateLayout()
    {
        if (ChildContainer == null) return;

        if (ItemText == null) return;
        if (ItemText.Parent is View parent) parent.HeightRequest = ItemText.Height + 6;

        if (IsSelected)
        {
            Wrapper.BackgroundColor = BackgroundColorSelected;
            ItemText.TextColor = TextColorSelected;
            ItemText.FontSize = FontSizeSelected;
        }
        else
        {
            Wrapper.BackgroundColor = BackgroundColor;
            ItemText.TextColor = TextColor;
            ItemText.FontSize = FontSize;
        }

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected virtual void OnIndicatorTapped(object sender, EventArgs e)
    {
        if (Children == null || Children.Count == 0) return;

        IsExpanded = !IsExpanded;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnTextTapped(object sender, EventArgs e)
    {
        if (TreeView == null) TreeView = VisualTreeHelper.GetParent<TreeView>(this);

        if (TreeView != null)
        {
            TreeView.SendItemTapped(new TreeViewNodeTappedEventArgs(this));
            if (TreeView.SelectionMode == TreeViewSelectionMode.None) return;
        }

        IsSelected = !IsSelected;
        UpdateCurrent();

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnTextDoubleTapped(object sender, EventArgs e)
    {
        if (Children == null || Children.Count == 0) return;
        if (TreeView == null) TreeView = VisualTreeHelper.GetParent<TreeView>(this);
        if (TreeView != null) TreeView.SendItemDoubleTapped(new TreeViewNodeDoubleTappedEventArgs(this));

        IsExpanded = !IsExpanded;
    }

    /// <summary>
    /// 
    /// </summary>
    private void UpdateIsExpanded()
    {
        ChildContainer.IsVisible = IsExpanded;
        RightIndicator.IsVisible = !IsExpanded;
        DownIndicator.IsVisible = IsExpanded;

        if (IsExpanded)
        {
            var treeViewNodeExpandedCollapsedEventArgs = new TreeViewNodeExpandedCollapsedEventArgs(this);
            Expanded?.Invoke(this, treeViewNodeExpandedCollapsedEventArgs);
        }
        else
        {
            var treeViewNodeExpandedCollapsedEventArgs = new TreeViewNodeExpandedCollapsedEventArgs(this);
            Collapsed?.Invoke(this, treeViewNodeExpandedCollapsedEventArgs);
        }
    }
}
