﻿namespace RaoTorrent.Core.Controls;

public class Accordion : ContentView
{

    public View Body
    {
        get => BodyView.Content;
        set => BodyView.Content = value;
    }

    public string Title
    {
        get => HeaderText.Text;
        set => HeaderText.Text = value;
    }

    /// <summary>
    /// 
    /// </summary>
    public static readonly BindableProperty IsOpenBindablePropertyProperty = BindableProperty.Create(nameof(IsOpen), typeof(bool), typeof(Accordion), true, propertyChanged: IsOpenChanged);

    public bool IsOpen
    {
        get { return (bool)GetValue(IsOpenBindablePropertyProperty); }
        set { SetValue(IsOpenBindablePropertyProperty, value); }
    }

    public Color HeaderBackgroundColor
    {
        get => HeaderView.BackgroundColor;
        set => HeaderView.BackgroundColor = value;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="bindable"></param>
    /// <param name="oldValue"></param>
    /// <param name="newValue"></param>
    private static void IsOpenChanged(BindableObject bindable, object oldValue, object newValue)
    {
        bool isOpen;

        if (bindable != null && newValue != null)
        {
            var control = (Accordion)bindable;
            isOpen = (bool)newValue;

            if (control.IsOpen == false)
            {
                VisualStateManager.GoToState(control, "Open");
                control.Close();
            }
            else
            {
                VisualStateManager.GoToState(control, "Closed");
                control.Open();
            }
        }
    }

    public uint AnimationDuration { get; set; }

    private StackLayout Wrapper { get; set; } = new StackLayout();
    protected Grid HeaderView { get; set; } = new Grid();
    private Label HeaderText { get; set; } = new Label();
    protected Label Indicator { get; set; } = new Label();
    private ContentView BodyView { get; set; } = new ContentView();

    /// <summary>
    /// 
    /// </summary>
    public Accordion()
    {
        InitializeComponent();
        AnimationDuration = 250;
        IsOpen = true;
    }

    /// <summary>
    /// 
    /// </summary>
    private void InitializeComponent()
    {

        HeaderView.Margin = new Thickness(5, 5, 5, 0);
        HeaderView.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
        HeaderView.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));

        HeaderText.FontSize = 12;
        HeaderText.FontAttributes = FontAttributes.Bold;
        HeaderText.VerticalOptions = LayoutOptions.Start;
        HeaderText.HorizontalOptions = LayoutOptions.Start;
        HeaderView.Children.Add(HeaderText);

        Indicator.FontSize = 12;
        Indicator.FontAttributes = FontAttributes.Bold;
        Indicator.FontFamily = "FontAwesomeSolid";
        Indicator.Text = "\uf078;";
        Indicator.VerticalOptions = LayoutOptions.Start;
        HeaderView.Children.Add(Indicator);

        var headerGesturedTap = new TapGestureRecognizer();
        headerGesturedTap.Tapped += TitleTapped;
        HeaderView.GestureRecognizers.Add(headerGesturedTap);

        Wrapper.Children.Add(HeaderView);
        Wrapper.Children.Add(BodyView);
        Content = Wrapper;

        Grid.SetColumn(HeaderText, 0);
        Grid.SetColumn(Indicator, 1);

    }

    /// <summary>
    /// 
    /// </summary>
    async void Close()
    {
        await Task.WhenAll(
            BodyView.TranslateTo(0, -10, AnimationDuration),
            Indicator.RotateTo(-180, AnimationDuration),
            BodyView.FadeTo(0, 50));
        BodyView.IsVisible = false;
    }

    /// <summary>
    /// 
    /// </summary>
    async void Open()
    {
        BodyView.IsVisible = true;
        await Task.WhenAll(
            BodyView.TranslateTo(0, 0, AnimationDuration),
            Indicator.RotateTo(0, AnimationDuration),
            BodyView.FadeTo(30, 200, Easing.SinIn));
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void TitleTapped(object sender, EventArgs e)
    {
        IsOpen = !IsOpen;
    }

}
