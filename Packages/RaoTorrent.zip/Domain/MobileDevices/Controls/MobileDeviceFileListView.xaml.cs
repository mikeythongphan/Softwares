using RaoTorrent.Core.Extensions;
using RaoTorrent.Domain.MobileDevices.DataObjects;
using RaoTorrent.Domain.MobileDevices.ViewModels;
using System.Collections.ObjectModel;

namespace RaoTorrent.Domain.MobileDevices.Controls;

public partial class MobileDeviceFileListView : ContentView
{

    public event EventHandler<SelectionChangedEventArgs> ItemSelected;

    public ObservableCollection<MobileDeviceFileVM> Items { get; } = new();
    public ObservableCollection<MobileDeviceFileVM> SelectedItems { get; set; } = new();

    /// <summary>
    /// 
    /// </summary>
    public MobileDeviceFileListView()
	{
		InitializeComponent();
        FileList.BindingContext = this;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnItemSelected(object sender, SelectionChangedEventArgs e)
    {
        ItemSelected?.Invoke(this, e);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public List<MobileDeviceFileInfo> GetSelectedFiles()
    {
        var files = Items.Where(x => x.IsSelected)
            .ToList()
            .MapTo<MobileDeviceFileVM, MobileDeviceFileInfo>();
        return files;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="files"></param>
    public void Refresh(List<MobileDeviceFileInfo> files)
    {
        var items = files.MapTo<MobileDeviceFileInfo, MobileDeviceFileVM>();
        Items.Refresh(items);
    }

    /// <summary>
    /// 
    /// </summary>
    public void UnSelectAll()
    {
        foreach(var item in Items.Where(x => x.IsSelected)) item.IsSelected = false;
    }
}