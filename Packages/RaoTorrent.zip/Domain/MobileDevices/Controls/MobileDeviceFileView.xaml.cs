using RaoTorrent.Core.Controls.DeviceDirectory;
using RaoTorrent.Core.Interfaces;
using RaoTorrent.Domain.MobileDevices.Android;
using RaoTorrent.Domain.MobileDevices.Apple;
using RaoTorrent.Domain.MobileDevices.DataObjects;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Handlers;
using RaoTorrent.Core.Extensions;
using RaoTorrent.Domain.MobileDevices.ViewModels;

namespace RaoTorrent.Domain.MobileDevices.Controls;

public partial class MobileDeviceFileView : ContentView, IWorkingView
{
    private static List<string> ImageFileExtensions = new List<string>() { ".JPEG", ".JPG", ".PNG", ".GIF", ".TIFF", ".PSD", ".PDF", ".EPS", ".AI", ".INDD", ".RAW" };

    private IFolderPicker FolderPicker => GlobalVars.FolderPicker;
    private AppleDeviceService AppleDevice { get; set; } = new AppleDeviceService();
    private AndroidDeviceService DroidDevice { get; set; } = new AndroidDeviceService();

    private MobileDeviceTreeViewNode SelectedDir { get; set; }

    public static readonly BindableProperty StatusMessageProperty = BindableProperty.Create(nameof(StatusMessage),
        typeof(string), typeof(MobileDeviceExplorer), string.Empty);
    public string StatusMessage
    {
        get => (string)GetValue(StatusMessageProperty);
        set => SetValue(StatusMessageProperty, value);
    }

    /// <summary>
    /// 
    /// </summary>
    public static readonly BindableProperty IsLoadingProperty = BindableProperty.Create(nameof(IsLoading),
        typeof(bool), typeof(MobileDeviceExplorer), false);
    public bool IsLoading
    {
        get => (bool)GetValue(IsLoadingProperty);
        set => SetValue(IsLoadingProperty, value);
    }

    /// <summary>
    /// 
    /// </summary>
    public static readonly BindableProperty IsCopyingFileProperty = BindableProperty.Create(nameof(IsCopyingFile),
        typeof(bool), typeof(MobileDeviceExplorer), false);
    public bool IsCopyingFile
    {
        get => (bool)GetValue(IsCopyingFileProperty);
        set => SetValue(IsCopyingFileProperty, value);
    }

    private static ContentPage page = new ContentPage();

    /// <summary>
    /// 
    /// </summary>
    public MobileDeviceFileView()
    {
        InitializeComponent();
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnMobileDeviceFileListViewItemSelected(object sender, SelectionChangedEventArgs e)
    {
        if (SelectedDir == null) return;

        if (e.CurrentSelection == null) return;

        if (e.CurrentSelection.Count != 1) return;

        var fileSelected = e.CurrentSelection.First() as MobileDeviceFileVM;

        if (ImageFileExtensions.Any(Path.GetExtension(fileSelected.AbsolutePath).ToUpper().Contains))
        {
            Image image = new Image();

            if (SelectedDir.IsAppleDevice) 
                FilePreview = new MobileDeviceFilePreviewView { Content = await AppleDevice.GetImage(fileSelected, this) };
            else
                FilePreview = new MobileDeviceFilePreviewView { Content = await DroidDevice.GetImage(fileSelected, this) };
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="node"></param>
    public async Task LoadFiles(MobileDeviceTreeViewNode node)
    {
        IsLoading = true;
        var files = new List<MobileDeviceFileInfo>();
        await Task.Run(async () =>
        {
            files = node.IsAppleDevice ? await AppleDevice.GetFiles(node) : DroidDevice.GetFiles(node);
        });

        var items = files.MapTo<MobileDeviceFileInfo, MobileDeviceFileVM>();
        FileList.Items.Refresh(items);

        SelectedDir = node;
        IsLoading = false;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnViewFileList(object sender, EventArgs e)
    {

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnViewFileThumbnail(object sender, EventArgs e)
    {

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnExport(object sender, EventArgs e)
    {
        if (SelectedDir == null) return;

        var pickedFolder = await FolderPicker.PickFolder();

        var files = FileList.GetSelectedFiles();
        if (files == null || files.Count == 0) return;

        IsCopyingFile = true;

        if (SelectedDir.IsAppleDevice) await AppleDevice.Export(files, pickedFolder, this);
        else await DroidDevice.Export(files, pickedFolder, this);

        FileList.UnSelectAll();

        StatusMessage = string.Empty;
        IsCopyingFile = false;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnImport(object sender, EventArgs e)
    {
        if (SelectedDir == null) return;

        var result = await FilePicker.PickMultipleAsync(new PickOptions
        {
            PickerTitle = "Select Files"
        });

        if (result == null || result.Count() == 0) return;

        IsCopyingFile = true;
        if (SelectedDir.IsAppleDevice) await AppleDevice.Import(SelectedDir.DeviceID, result, SelectedDir.AbsolutePath, this);
        else await DroidDevice.Import(SelectedDir.DeviceName, result, SelectedDir.AbsolutePath, this);

        var files = SelectedDir.IsAppleDevice ? await AppleDevice.GetFiles(SelectedDir) : DroidDevice.GetFiles(SelectedDir);
        FileList.Refresh(files);
        IsCopyingFile = false;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnDelete(object sender, EventArgs e)
    {
        if (SelectedDir == null) return;

        var files = FileList.GetSelectedFiles();
        if (files == null || files.Count == 0) return;

        bool answer = await Application.Current.MainPage.DisplayAlert("Question?", "Would you like to Delete File", "Yes", "No");

        if (answer)
        {
            if (SelectedDir.IsAppleDevice) await AppleDevice.Delete(files, this);
            else await DroidDevice.Delete(files, this);

            files = SelectedDir.IsAppleDevice ? await AppleDevice.GetFiles(SelectedDir) : DroidDevice.GetFiles(SelectedDir);
            FileList.Refresh(files);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnRename(object sender, EventArgs e)
    {
        if (SelectedDir == null) return;

        var files = FileList.GetSelectedFiles();
        if (files == null || files.Count == 0 || files.Count > 1) return;

        string answer = await Application.Current.MainPage.DisplayPromptAsync("Question?", "What's new file name?");

        if (string.IsNullOrEmpty(answer)) return;

        if (SelectedDir.IsAppleDevice) await AppleDevice.Rename(files.First(), SelectedDir.AbsolutePath + "/" + answer, this);
        else await DroidDevice.Rename(files.First(), SelectedDir.AbsolutePath + "/" + answer, this);

        files = SelectedDir.IsAppleDevice ? await AppleDevice.GetFiles(SelectedDir) : DroidDevice.GetFiles(SelectedDir);
        FileList.Refresh(files);

    }
}