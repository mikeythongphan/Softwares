namespace RaoTorrent.Domain.MobileDevices.Controls;

public partial class MobileDeviceFilePreviewView : ContentView
{
	public MobileDeviceFilePreviewView()
	{
		InitializeComponent();
	}
}