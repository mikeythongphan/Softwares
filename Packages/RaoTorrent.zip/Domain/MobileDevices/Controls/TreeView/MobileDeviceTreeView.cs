﻿using RaoTorrent.Core.Controls;

namespace RaoTorrent.Domain.MobileDevices.Controls;

public class MobileDeviceTreeView : TreeView
{
    public new MobileDeviceTreeViewNode SelectedItem
    {
        get => base.SelectedItem as MobileDeviceTreeViewNode;
        set => base.SelectedItem = value;
    }

}
