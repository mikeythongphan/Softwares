﻿using RaoTorrent.Core.Extensions;

namespace RaoTorrent.Domain.MobileDevices.DataObjects
{
    public class MobileDeviceFileInfo
    {
        public string DeviceID { get; set; }
        public string DeviceName { get; set; }

        private string _filename { get; set; }
        public string FileName 
        {
            get => _filename;
            set
            {
                _filename = value;
                var index = _filename.IndexOf('.');
                if (index < 0) return;
                FName = _filename.Substring(0, index);
                FileExtension = _filename.Substring(index + 1).ToUpper();
            }
        }

        public string FName { get; set; }
        public string FileExtension { get; set; }

        private ulong _fileSize { get; set; }
        public ulong FileSize 
        {
            get => _fileSize;
            set
            {
                _fileSize = value;
                FileSizeKB = ((int)Math.Round(FileSize / 1024.0d)).ToString("#,###") + " KB";
            }
        }

        public string FileSizeKB { get; set; }
        public string DateModified { get; set; }
        public string AbsolutePath { get; set; }
        public bool IsSelected { get; set; }

    }
}
