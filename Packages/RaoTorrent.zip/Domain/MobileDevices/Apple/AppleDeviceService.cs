﻿using RaoTorrent.Core.Controls;
using RaoTorrent.Core.Extensions;
using RaoTorrent.Core.Interfaces;
using RaoTorrent.Domain.MobileDevices.Controls;
using RaoTorrent.Domain.MobileDevices.DataObjects;
using RaoTorrent.Domain.MobileDevices.ViewModels;

namespace RaoTorrent.Domain.MobileDevices.Apple;

public class AppleDeviceService
{

    /// <summary>
    /// 
    /// </summary>
    /// <param name="files"></param>
    /// <param name="localDir"></param>
    /// <param name="view"></param>
    /// <returns></returns>
    public async Task Export(List<MobileDeviceFileInfo> files, string localDir, IWorkingView view)
    {

        if (files == null || files.Count == 0 || string.IsNullOrEmpty(localDir)) return;

        if (!Directory.Exists(localDir)) return;

        var device = await AppleDeviceManager.Instance.Connect(files.First().DeviceID);

        foreach (var file in files)
        {
            view.StatusMessage = $"Copying {file.FileName}. Please wait...";
            await Task.Run(() =>
            {
                device.Export(file.AbsolutePath, Path.Combine(localDir, file.FileName));
            });
        }

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="deviceID"></param>
    /// <param name="files"></param>
    /// <param name="deviceDir"></param>
    /// <param name="view"></param>
    /// <returns></returns>
    public async Task Import(string deviceID, IEnumerable<FileResult> files, string deviceDir, IWorkingView view)
    {
        if (files == null || string.IsNullOrEmpty(deviceDir)) return;

        if (files.Count() == 0) return;

        var device = await AppleDeviceManager.Instance.Connect(deviceID);
        foreach (var file in files)
        {
            view.StatusMessage = $"Copying {file.FileName}. Please wait...";
            await Task.Run(() =>
            {
                device.Import(file.FullPath, deviceDir + "/" + file.FileName);
            });
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="treeNode"></param>
    /// <returns></returns>
    public async Task<List<MobileDeviceFileInfo>> GetFiles(MobileDeviceTreeViewNode treeNode)
    {

        var result = new List<MobileDeviceFileInfo>();

        var dirPath = treeNode.AbsolutePath;

        var device = await AppleDeviceManager.Instance.Connect(treeNode.DeviceID);
        var filenames = device.GetDeviceDirectory(dirPath);
        if (filenames == null) return null;
        foreach (var filename in filenames)
        {

            var filePath = $"{dirPath}/{filename}";
            var fileInfo = device.GetFileInfo(filePath);
            if (fileInfo == null || fileInfo.Count == 0 || fileInfo.Contains("S_IFDIR")) continue;

            long nanoseconds = !string.IsNullOrEmpty(fileInfo[9]) ? long.Parse(fileInfo[9].ToString()) : 0;
            DateTime epochTime = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            DateTime? dateModified = nanoseconds != 0 ? epochTime.AddTicks(nanoseconds / 100) : null;

            var file = new MobileDeviceFileInfo
            {
                DeviceID = treeNode.DeviceID,
                DeviceName = treeNode.DeviceName,
                AbsolutePath = filePath,
                FileName = filename,
                FileSize = !string.IsNullOrEmpty(fileInfo[1]) ? fileInfo[1].ToULong() : 0,
                DateModified = dateModified != null ? ((DateTime)dateModified).ToString("dddd, dd MMMM yyyy HH:mm:ss") : string.Empty
            };
            result.Add(file);
        }

        return result;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="dirInfo"></param>
    /// <returns></returns>
    public async Task<List<MobileDeviceFileInfo>> GetDirectories(MobileDeviceFileInfo dirInfo)
    {

        var result = new List<MobileDeviceFileInfo>();

        var device = await AppleDeviceManager.Instance.Connect(dirInfo.DeviceID);
        var filenames = device.GetDeviceDirectory(dirInfo.AbsolutePath);
        if (filenames == null) return null;
        foreach (var filename in filenames.OrderBy(x => x))
        {

            if (filename == "." || filename == "..") continue;

            var childPath = $"{dirInfo.AbsolutePath}/{filename}";
            var childInfo = device.GetFileInfo(childPath);
            if (childInfo == null || childInfo.Count == 0 || !childInfo.Contains("S_IFDIR")) continue;

            var file = new MobileDeviceFileInfo
            {
                DeviceID = dirInfo.DeviceID,
                DeviceName = dirInfo.DeviceName,
                AbsolutePath = childPath,
                FileName = filename
            };
            result.Add(file);

        }

        return result;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public async Task<List<MobileDeviceFileInfo>> GetDevices()
    {
        var result = new List<MobileDeviceFileInfo>();
        var deviceIDs = AppleDeviceManager.GetDevices();
        foreach (var deviceID in deviceIDs)
        {
            var device = await AppleDeviceManager.Instance.Connect(deviceID);
            var obj = new MobileDeviceFileInfo
            {
                DeviceID = deviceID,
                DeviceName = device.GetDeviceName(),
                AbsolutePath = string.Empty
            };
            result.Add(obj);
        }
        return result;
    }

    /// <summary>
    /// 
    /// </summary>
    public async Task<TreeViewNodes> GetTree()
    {

        var result = new TreeViewNodes();

        var deviceIDs = AppleDeviceManager.GetDevices();
        foreach (var deviceID in deviceIDs)
        {

            var device = await AppleDeviceManager.Instance.Connect(deviceID);
            var deviceName = device.GetDeviceName();

            var deviceNode = new MobileDeviceTreeViewNode();
            deviceNode.IsExpanded = true;
            deviceNode.Text = deviceName;
            deviceNode.Icon = "iphone.png";
            deviceNode.DeviceID = deviceID;
            deviceNode.DeviceName = deviceName;
            deviceNode.IsAppleDevice = true;
            deviceNode.Children = device.GetTreeDirectories(deviceID, "/", deviceNode);
            result.Add(deviceNode);

        }

        return result;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="files"></param>
    /// <param name="localDir"></param>
    /// <param name="view"></param>
    /// <returns></returns>
    public async Task Delete(List<MobileDeviceFileInfo> files, IWorkingView view)
    {

        if (files == null || files.Count == 0) return;

        var device = await AppleDeviceManager.Instance.Connect(files.First().DeviceID);

        foreach (var file in files)
        {
            view.StatusMessage = $"Deleting {file.FileName}. Please wait...";
            await Task.Run(() =>
            {
                device.Delete(file.AbsolutePath);
            });
        }

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="files"></param>
    /// <param name="localDir"></param>
    /// <param name="view"></param>
    /// <returns></returns>
    public async Task Rename(MobileDeviceFileInfo file, string newName, IWorkingView view)
    {

        if (file == null) return;

        var device = await AppleDeviceManager.Instance.Connect(file.DeviceID);

        view.StatusMessage = $"Renaming {file.FileName}. Please wait...";
        await Task.Run(() =>
        {
            device.Rename(file.AbsolutePath, newName);
        });

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="files"></param>
    /// <param name="localDir"></param>
    /// <param name="view"></param>
    /// <returns></returns>
    public async Task<Image> GetImage(MobileDeviceFileVM file, IWorkingView view)
    {

        if (file == null) return null;

        var device = await AppleDeviceManager.Instance.Connect(file.DeviceID);

        view.StatusMessage = $"Getting Image {file.FileName}. Please wait...";

        Image image = new Image();

        await Task.Run(() =>
        {
            MemoryStream stream = new MemoryStream();
            stream = device.Export(file.AbsolutePath);

            image = new Image
            {
                Source = ImageSource.FromStream(() => stream)
            };
        });

        return image;
    }
}
