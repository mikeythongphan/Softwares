﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace RaoTorrent.Domain.MobileDevices.ViewModels
{
    public class MobileDeviceFileVM : INotifyPropertyChanged
    {
        public string DeviceID { get; set; }
        public string DeviceName { get; set; }
        public string FileName { get; set; }
        public string FName { get; set; }
        public string FileExtension { get; set; }
        public ulong FileSize { get; set; }
        public string FileSizeKB { get; set; }
        public string DateModified { get; set; }
        public string AbsolutePath { get; set; }

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set => SetPropertyValue(ref _isSelected, value);
        }

        /// <summary>
        /// 
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="field"></param>
        /// <param name="value"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        protected bool SetPropertyValue<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
        {
            if (value == null ? field != null : !value.Equals(field))
            {
                field = value;

                var handler = this.PropertyChanged;
                if (handler != null)
                {
                    handler(this, new PropertyChangedEventArgs(propertyName));
                }
                return true;
            }
            return false;
        }
    }
}
