﻿using AppKit;
using Microsoft.Maui.Platform;
using RaoTorrent.Core.Controls;
using UIKit;


namespace RaoTorrent.Platforms.MacCatalyst.Core
{

    public static class CursorExtensions
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="visualElement"></param>
        /// <param name="cursor"></param>
        /// <param name="mauiContext"></param>
        public static void SetCustomCursor(this VisualElement visualElement, CursorIcon cursor, IMauiContext? mauiContext)
        {
            ArgumentNullException.ThrowIfNull(mauiContext);
            var view = visualElement.ToPlatform(mauiContext);
            if (view.GestureRecognizers is not null)
            {
                foreach (var recognizer in view.GestureRecognizers.OfType<PointerUIHoverGestureRecognizer>())
                {
                    view.RemoveGestureRecognizer(recognizer);
                }
            }

            view.AddGestureRecognizer(new PointerUIHoverGestureRecognizer(r =>
            {
                switch (r.State)
                {
                    case UIGestureRecognizerState.Began:
                        GetNSCursor(cursor).Set();
                        break;
                    case UIGestureRecognizerState.Ended:
                        NSCursor.ArrowCursor.Set();
                        break;
                }
            }));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cursor"></param>
        /// <returns></returns>
        static NSCursor GetNSCursor(CursorIcon cursor)
        {
            return cursor switch
            {
                CursorIcon.Hand => NSCursor.OpenHandCursor,
                CursorIcon.IBeam => NSCursor.IBeamCursor,
                CursorIcon.Cross => NSCursor.CrosshairCursor,
                CursorIcon.Arrow => NSCursor.ArrowCursor,
                CursorIcon.SizeAll => NSCursor.ResizeUpCursor,
                CursorIcon.Wait => NSCursor.OperationNotAllowedCursor,
                _ => NSCursor.ArrowCursor,
            };
        }

        /// <summary>
        /// 
        /// </summary>
        class PointerUIHoverGestureRecognizer : UIHoverGestureRecognizer
        {

            /// <summary>
            /// 
            /// </summary>
            /// <param name="action"></param>
            public PointerUIHoverGestureRecognizer(Action<UIHoverGestureRecognizer> action) : base(action)
            {
            }
        }
    }
}
