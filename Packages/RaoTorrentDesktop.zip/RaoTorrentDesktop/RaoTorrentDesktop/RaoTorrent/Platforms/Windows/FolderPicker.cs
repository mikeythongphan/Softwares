﻿using RaoTorrent.Core.Interfaces;
using WindowsFolderPicker = Windows.Storage.Pickers.FolderPicker;

namespace RaoTorrent.Platforms.Windows
{
    public class FolderPicker : IFolderPicker
    {

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<string> PickFolder()
        {
            var folderPicker = new WindowsFolderPicker();
            folderPicker.FileTypeFilter.Add("*");
            var hwnd = ((MauiWinUIWindow)App.Current.Windows[0].Handler.PlatformView).WindowHandle;
            WinRT.Interop.InitializeWithWindow.Initialize(folderPicker, hwnd);
            var result = await folderPicker.PickSingleFolderAsync();
            return result?.Path;
        }
    }
}
