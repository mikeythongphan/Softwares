﻿namespace RaoTorrent;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}

