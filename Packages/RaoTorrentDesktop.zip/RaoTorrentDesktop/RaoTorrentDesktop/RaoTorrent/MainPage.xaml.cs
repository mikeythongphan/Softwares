﻿using RaoTorrent.Core.Controls;
using RaoTorrent.Domain.MobileDevices.Controls;

namespace RaoTorrent;

public partial class MainPage : ContentPage
{

    /// <summary>
    /// 
    /// </summary>
    public MainPage()
    {
        InitializeComponent();
        MobileDeviceFiles.LoadFiles(null);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnMobileDeviceExplorerItemTapper(object sender, TreeViewNodeTappedEventArgs e)
    {
        if (e == null || e.Node == null) return;
        await MobileDeviceFiles.LoadFiles(e.Node as MobileDeviceTreeViewNode);
    }
}

