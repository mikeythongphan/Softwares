﻿using iMobileDevice.Afc;
using iMobileDevice.iDevice;
using iMobileDevice.Lockdown;
using iMobileDevice.MobileImageMounter;
using iMobileDevice;
using System.Collections.ObjectModel;
using RaoTorrent.Core.Controls;
using RaoTorrent.Domain.MobileDevices.Controls;
using System.Runtime.InteropServices;

namespace RaoTorrent.Domain.MobileDevices.Apple;

public class AppleDeviceManager : IDisposable
{

    private bool _disposed = false;

    private static IiDeviceApi DeviceAPI => LibiMobileDevice.Instance.iDevice;
    private static ILockdownApi LockdownAPI => LibiMobileDevice.Instance.Lockdown;
    private static IMobileImageMounterApi ImageMounterAPI => LibiMobileDevice.Instance.MobileImageMounter;
    private static IAfcApi AfcAPI => LibiMobileDevice.Instance.Afc;

    private iDeviceHandle _device;
    public iDeviceHandle Device => _device;

    private LockdownClientHandle _lockdownClient;
    public LockdownClientHandle LockdownClient => _lockdownClient;

    private LockdownServiceDescriptorHandle _lockdownService;
    public LockdownServiceDescriptorHandle LockdownService => _lockdownService;

    private MobileImageMounterClientHandle _imageMounter;
    public MobileImageMounterClientHandle ImageMounter => _imageMounter;

    private LockdownServiceDescriptorHandle _afcService;
    public LockdownServiceDescriptorHandle AfcService => _afcService;

    private AfcClientHandle _afcClient;
    public AfcClientHandle AfcClient => _afcClient;

    /// <summary>
    /// 
    /// </summary>
    public AppleDeviceManager()
    {
    }

    /// <summary>
    /// 
    /// </summary>
    public static AppleDeviceManager Instance => new AppleDeviceManager();

    /// <summary>
    /// 
    /// </summary>
    public void Dispose()
    {

        Dispose(disposing: true);
        GC.SuppressFinalize(this);

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="disposing"></param>
    protected virtual void Dispose(bool disposing)
    {

        if (!_disposed)
        {
            // If disposing equals true, dispose all managed and unmanaged resources.
            if (disposing)
            {
            }

            if (_afcClient != null) _afcClient.Close();
            if (_afcService != null) _afcService.Close();
            if (_imageMounter != null) _imageMounter.Close();
            if (_lockdownService != null) _lockdownService.Close();
            if (_lockdownClient != null) _lockdownClient.Close();
            if (_device != null) _device.Close();

            _disposed = true;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="deviceID"></param>
    public async Task<AppleDeviceManager> Connect(string deviceID)
    {

        await Task.Run(() =>
        {
            GetDevice(deviceID, out _device);
            GetLockdownClient(out _lockdownClient);
            StartLockdownService(out _lockdownService);
            GetImageMounter(out _imageMounter);
            StartAfcService(out _afcService);
            CreateAfcClient(out _afcClient);
        });

        return this;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="mobileFilePath"></param>
    /// <param name="computerFilePath"></param>
    public void Export(string mobileFilePath, string computerFilePath)
    {
        ReadOnlyCollection<string> fileInformation = GetFileInfo(mobileFilePath);

        if (fileInformation == null || fileInformation.Count == 0) return;

        long fileSize = Convert.ToInt64(fileInformation[1]);

        ulong fileHandle = 0;
        AfcFileOpen(AfcFileMode.FopenRdonly, mobileFilePath, ref fileHandle);
        if (fileHandle == 0) return;

        FileStream fileStream = new FileStream(computerFilePath, FileMode.Create, FileAccess.Write);
        const int bufferSize = 4194304;
        for (int i = 0; i < fileSize / bufferSize + 1; i++)
        {
            uint bytesRead = 0;

            long remainder = fileSize - i * bufferSize;
            int currBufferSize = remainder >= bufferSize ? bufferSize : (int)remainder;
            byte[] currBuffer = new byte[currBufferSize];

            if (AfcFileRead(fileHandle, currBuffer, currBufferSize, ref bytesRead) != AfcError.Success)
            {
                AfcAPI.afc_file_close(AfcClient, fileHandle);
                return;
            }

            fileStream.Write(currBuffer, 0, currBufferSize);
        }

        fileStream.Close();
        AfcAPI.afc_file_close(AfcClient, fileHandle);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="mobileFilePath"></param>
    /// <returns></returns>
    public MemoryStream ReadFile(string mobileFilePath)
    {

        ReadOnlyCollection<string> fileInformation = GetFileInfo(mobileFilePath);
        if (fileInformation == null || fileInformation.Count == 0) return null;

        var length = Convert.ToUInt32(fileInformation[1]);
        byte[] byteArr = new byte[length];
        AfcReadFile(AfcFileMode.FopenRdonly, mobileFilePath, length, ref byteArr);

        var result = new MemoryStream(byteArr);
        return result;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="computerFilePath"></param>
    /// <param name="mobileFilePath"></param>
    public void Import(string computerFilePath, string mobileFilePath)
    {

        ReadOnlyCollection<string> fileInformation = GetFileInfo(mobileFilePath);
        if (fileInformation != null) return;

        FileStream fileStream = new FileStream(computerFilePath, FileMode.Open, FileAccess.Read, FileShare.Read);

        ulong fileHandle = 0;
        AfcFileOpen(AfcFileMode.FopenWronly, mobileFilePath, ref fileHandle);
        if (fileHandle == 0) return;

        uint amount = 0;
        byte[] buf = new byte[8192];
        do
        {
            amount = (uint)fileStream.Read(buf, 0, buf.Length);
            if (amount > 0)
            {
                uint written = 0, total = 0;
                while (total < amount)
                {
                    if (AfcFileWrite(fileHandle, buf, amount, ref written) != AfcError.Success)
                    {
                        AfcAPI.afc_file_close(AfcClient, fileHandle);
                        return;
                    }

                    total += written;
                }

                if (total != amount)
                {
                    AfcAPI.afc_file_close(AfcClient, fileHandle);
                    return;
                }
            }
        } while (amount > 0);

        AfcAPI.afc_file_close(AfcClient, fileHandle);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="mobileFilePath"></param>
    /// <param name="computerFilePath"></param>
    public void Delete(string mobileFilePath)
    {
        ReadOnlyCollection<string> fileInformation = GetFileInfo(mobileFilePath);

        if (fileInformation == null || fileInformation.Count == 0) return;

        var result = AfcAPI.afc_remove_path(AfcClient, mobileFilePath);
        if (result == AfcError.Success) return;
        throw new Exception($"Unable to execute afc_remove_path::{result}.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="mobileFilePath"></param>
    /// <param name="computerFilePath"></param>
    public void Rename(string mobileOldFilePath, string mobileNewFilePath)
    {
        ReadOnlyCollection<string> fileInformation = GetFileInfo(mobileOldFilePath);

        if (fileInformation == null || fileInformation.Count == 0) return;

        var result = AfcAPI.afc_rename_path(AfcClient, mobileOldFilePath, mobileNewFilePath);
        if (result == AfcError.Success) return;
        throw new Exception($"Unable to execute afc_rename_path::{result}.");

    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public static List<string> GetDevices()
    {
        int totalDevices = 0;
        ReadOnlyCollection<string> uniqueDeviceIDs;

        var deviceError = DeviceAPI.idevice_get_device_list(out uniqueDeviceIDs, ref totalDevices);
        if (deviceError == iDeviceError.NoDevice) return null;
        deviceError.ThrowOnError();

        return uniqueDeviceIDs.ToList();

    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    public string GetDeviceName()
    {
        if (LockdownAPI.lockdownd_get_device_name(LockdownClient, out string result) == LockdownError.Success
            && !string.IsNullOrEmpty(result)) return result;
        throw new Exception("Unable to retrieve device name.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    public ReadOnlyCollection<string> GetDeviceInfo()
    {
        if (AfcAPI.afc_get_device_info(AfcClient, out ReadOnlyCollection<string> result) == AfcError.Success
            && result != null && result.Count > 0) return result;
        throw new Exception("Unable to retrieve device information.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="path"></param>
    /// <exception cref="Exception"></exception>
    public void CreateDirectory(string path)
    {
        var result = AfcAPI.afc_make_directory(AfcClient, path);
        if (result == AfcError.Success) return;
        throw new Exception($"Unable to execute afc_make_directory::{result}.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="path"></param>
    /// <returns></returns>
    public ReadOnlyCollection<string> GetDeviceDirectory(string path) =>
        AfcAPI.afc_read_directory(AfcClient, path, out ReadOnlyCollection<string> result) == AfcError.Success
        && result != null && result.Count > 0 ? result : null;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="path"></param>
    /// <returns></returns>
    public ReadOnlyCollection<string> GetFileInfo(string path) =>
        AfcAPI.afc_get_file_info(AfcClient, path, out ReadOnlyCollection<string> result) == AfcError.Success
        && result != null && result.Count > 0 ? result : null;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="deviceID"></param>
    /// <param name="parentDir"></param>
    /// <returns></returns>
    public TreeViewNodes GetTreeDirectories(string deviceID, string parentDir, MobileDeviceTreeViewNode parent)
    {

        var result = new TreeViewNodes();

        var parentPath = parentDir == "/" ? $"/{parentDir}" : parentDir;
        var directories = GetDeviceDirectory(parentPath);
        if (directories == null) return null;

        foreach (var directory in directories)
        {
            if (directory == "." || directory == "..") continue;

            var dirPath = $"{parentDir}/{directory}";
            var fileInfo = GetFileInfo(dirPath);
            if (fileInfo == null) continue;

            if (fileInfo.Count == 0 || !fileInfo.Contains("S_IFDIR")) continue;

            var directoryNode = new MobileDeviceTreeViewNode();
            directoryNode.Text = directory;
            directoryNode.Icon = "folder_close.png";
            directoryNode.AbsolutePath = dirPath;
            var children = GetTreeDirectories(deviceID, dirPath, directoryNode);
            if (children != null && children.Count > 0)
            {
                directoryNode.Children = children;
            }
            result.Add(directoryNode);
        }

        result.ToList().ForEach(x => x.ParentNode = parent);
        return result.Count > 0 ? result : null;

    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="udid"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    private void GetDevice(string udid, out iDeviceHandle result)
    {
        if (DeviceAPI.idevice_new(out result, udid) == iDeviceError.Success) return;
        throw new Exception("Unable to open device, is it connected?");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="result"></param>
    /// <exception cref="Exception"></exception>
    private void GetLockdownClient(out LockdownClientHandle result)
    {
        if (LockdownAPI.lockdownd_client_new_with_handshake(Device, out result, "RAO") == LockdownError.Success) return;
        throw new Exception("Unable to connect to lockdownd.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="result"></param>
    /// <exception cref="Exception"></exception>
    private void StartLockdownService(out LockdownServiceDescriptorHandle result)
    {
        if (LockdownAPI.lockdownd_start_service(LockdownClient,
            "com.apple.mobile.mobile_image_mounter", out result) == LockdownError.Success) return;
        throw new Exception("Unable to start lockdown service descriptor.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="result"></param>
    /// <exception cref="Exception"></exception>
    private void GetImageMounter(out MobileImageMounterClientHandle result)
    {
        if (ImageMounterAPI.mobile_image_mounter_new(Device, LockdownService, out result) == MobileImageMounterError.Success) return;
        throw new Exception("Unable to create mobile image mounter instance.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="result"></param>
    /// <exception cref="Exception"></exception>
    private void StartAfcService(out LockdownServiceDescriptorHandle result)
    {
        if (LockdownAPI.lockdownd_start_service(LockdownClient, "com.apple.afc", out result) == LockdownError.Success) return;
        throw new Exception("Unable to start AFC service.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="result"></param>
    /// <exception cref="Exception"></exception>
    private void CreateAfcClient(out AfcClientHandle result)
    {
        if (AfcAPI.afc_client_new(Device, AfcService, out result) == AfcError.Success) return;
        throw new Exception("Unable to create AFC Client.");
    }

    /// <summary>
    /// AfcFileOpen
    /// </summary>
    /// <param name="path"></param>
    /// <param name="fileHandle"></param>
    private void AfcFileOpen(AfcFileMode afcFileMode, string path, ref ulong fileHandle)
    {
        if (AfcAPI.afc_file_open(AfcClient, path, afcFileMode, ref fileHandle) == AfcError.Success) return;
        throw new Exception("Unable to execute afc_file_open.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="afcFileMode"></param>
    /// <param name="path"></param>
    /// <param name="length"></param>
    /// <param name="result"></param>
    /// <exception cref="Exception"></exception>
    private void AfcReadFile(AfcFileMode afcFileMode, string path, uint length, ref byte[] result)
    {
        ulong handle = 0;
        uint bytesRead = 0;
        if (AfcAPI.afc_file_open(AfcClient, path, afcFileMode, ref handle) != AfcError.Success) throw new Exception("Unable to execute afc_file_open.");
        if (AfcAPI.afc_file_read(AfcClient, handle, result, length, ref bytesRead) != AfcError.Success) throw new Exception("Unable to execute afc_file_read.");
        if (AfcAPI.afc_file_close(AfcClient, handle) != AfcError.Success) throw new Exception("Unable to execute afc_file_close.");

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="fileHandle"></param>
    /// <param name="currBuffer"></param>
    /// <param name="currBufferSize"></param>
    /// <param name="bytesRead"></param>
    /// <returns></returns>
    private AfcError AfcFileRead(ulong fileHandle, byte[] currBuffer, int currBufferSize, ref uint bytesRead)
    {
        return AfcAPI.afc_file_read(AfcClient, fileHandle, currBuffer, Convert.ToUInt32(currBufferSize), ref bytesRead);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="fileHandle"></param>
    /// <param name="currBuffer"></param>
    /// <param name="currBufferSize"></param>
    /// <param name="bytesRead"></param>
    /// <returns></returns>
    private AfcError AfcFileWrite(ulong fileHandle, byte[] data, uint length, ref uint written)
    {
        return AfcAPI.afc_file_write(AfcClient, fileHandle, data, length, ref written);
    }

}
