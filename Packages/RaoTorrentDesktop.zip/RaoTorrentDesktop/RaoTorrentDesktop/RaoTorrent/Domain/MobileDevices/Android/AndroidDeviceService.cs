﻿using MediaDevices;
using Microsoft.Maui.Controls;
using RaoTorrent.Core.Controls;
using RaoTorrent.Core.Controls.Helpers;
using RaoTorrent.Core.Interfaces;
using RaoTorrent.Domain.MobileDevices.Controls;
using RaoTorrent.Domain.MobileDevices.DataObjects;
using RaoTorrent.Domain.MobileDevices.ViewModels;

namespace RaoTorrent.Domain.MobileDevices.Android;

public class AndroidDeviceService
{

    private static List<string> ValidDirectories = new List<string>() { "\\Bộ nhớ trong dùng chung", "Document", "Music", "Picture", "Video", "Download" };
    private const int MaxLevel = 5;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="dirInfo"></param>
    /// <returns></returns>
    public async Task<List<MobileDeviceFileInfo>> GetDirectories(MobileDeviceFileInfo dirInfo)
    {

        var result = new List<MobileDeviceFileInfo>();

        await Task.Run(() =>
        {

            var devices = MediaDevice.GetDevices();
            if (devices == null || devices.Count() == 0) return;

            using var device = devices.Where(x => x.Description == dirInfo.DeviceName).FirstOrDefault();
            if (device == null) return;

            device.Connect();
            if (device.Model == "Apple iPhone" || !device.IsConnected) return;

            var pathRoot = device.GetDirectoryInfo(@"\\");
            if (pathRoot == null || pathRoot.EnumerateDirectories().FirstOrDefault() == null) return;

            if (string.IsNullOrEmpty(dirInfo.AbsolutePath)) dirInfo.AbsolutePath = @"\\";
            var pathDir = device.GetDirectoryInfo(dirInfo.AbsolutePath);
            if (pathDir == null || pathDir.EnumerateDirectories() == null || pathDir.EnumerateDirectories().FirstOrDefault() == null) return;

            foreach (MediaDirectoryInfo dir in pathDir.EnumerateDirectories().OrderBy(x => x.Name))
            {
                var file = new MobileDeviceFileInfo
                {
                    DeviceID = dirInfo.DeviceID,
                    DeviceName = dirInfo.DeviceName,
                    AbsolutePath = dir.FullName,
                    FileName = dir.Name
                };

                result.Add(file);
            }

            device.Disconnect();

        });

        return result;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public async Task<List<MobileDeviceFileInfo>> GetDevices()
    {
        var result = new List<MobileDeviceFileInfo>();

        await Task.Run(() =>
        {
            var droidDevices = MediaDevice.GetDevices();
            foreach (var droidDevice in droidDevices)
            {
                droidDevice.Connect();

                if (droidDevice.Model != "Apple iPhone" && droidDevice.IsConnected)
                {
                    var path = droidDevice.GetDirectoryInfo(@"\\");
                    if (path != null && path.EnumerateDirectories().FirstOrDefault() != null)
                    {
                        var obj = new MobileDeviceFileInfo
                        {
                            DeviceID = droidDevice.DeviceId,
                            DeviceName = droidDevice.Description,
                            AbsolutePath = string.Empty
                        };
                        result.Add(obj);
                    }
                }

                droidDevice.Disconnect();
            }
        });
        return result;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public TreeViewNodes GetTree()
    {

        var result = new TreeViewNodes();

        //#if WINDOWS

        var droidDevices = MediaDevice.GetDevices();

        foreach (var droidDevice in droidDevices)
        {
            using (droidDevice)
            {
                droidDevice.Connect();

                if (droidDevice.Model != "Apple iPhone" && droidDevice.IsConnected)
                {
                    var pathRoot = droidDevice.GetDirectoryInfo(@"\\");

                    if (pathRoot != null && pathRoot.EnumerateDirectories().FirstOrDefault() != null)
                    {
                        var deviceNode = new MobileDeviceTreeViewNode();
                        deviceNode.IsExpanded = true;
                        deviceNode.Text = droidDevice.Description;
                        deviceNode.Icon = "android.png";
                        deviceNode.DeviceID = droidDevice.DeviceId;
                        deviceNode.DeviceName = droidDevice.Description;
                        deviceNode.Children = GetDirectories(droidDevice, droidDevice.Description, pathRoot.EnumerateDirectories().FirstOrDefault().FullName, deviceNode);
                        result.Add(deviceNode);
                    }
                }

                droidDevice.Disconnect();
            }
        }

        //#endif

        return result;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="deviceID"></param>
    /// <param name="dirPath"></param>
    /// <returns></returns>
    public async Task CreateDirectory(string deviceID, string dirPath)
    {
        //var device = await AppleDeviceManager.Instance.Connect(deviceID);
        //device.CreateDirectory(dirPath);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="device"></param>
    /// <param name="deviceName"></param>
    /// <param name="parentDir"></param>
    /// <param name="parent"></param>
    /// <returns></returns>
    private TreeViewNodes GetDirectories(MediaDevice device, string deviceName, string parentDir, TreeViewNode parent)
    {
        var result = new TreeViewNodes();

        //#if WINDOWS
        if (device.Model != "Apple iPhone" && device.IsConnected)
        {
            var pathDir = device.GetDirectoryInfo(parentDir);

            if (pathDir != null)
            {
                var directories = pathDir.EnumerateDirectories();

                foreach (MediaDirectoryInfo d in directories)
                {
                    //if (ValidDirectories.Any(d.FullName.Contains)
                    //    && d.FullName.Split('\\').Length <= MaxLevel)
                    {
                        var directoryNode = new MobileDeviceTreeViewNode();
                        directoryNode.Text = d.Name;
                        directoryNode.AbsolutePath = d.FullName;
                        directoryNode.Icon = "folder_close.png";
                        var children = GetDirectories(device, device.Description, d.FullName, directoryNode);
                        if (children != null && children.Count > 0)
                        {
                            directoryNode.Children = children;
                        }
                        result.Add(directoryNode);
                    }
                }
            }
        }

        result.ToList().ForEach(x => x.ParentNode = parent);

        //#endif

        return result.Count > 0 ? result : null;
    }

    /// <summary>
    /// GetFiles
    /// </summary>
    /// <param name="dirInfo"></param>
    /// <returns></returns>
    public List<MobileDeviceFileInfo> GetFiles(MobileDeviceFileInfo dirInfo)
    {
        var result = new List<MobileDeviceFileInfo>();

        var dirPath = dirInfo.AbsolutePath;

        var devices = MediaDevice.GetDevices();
        if (devices == null || devices.Count() == 0) return result;

        using var device = devices.Where(x => x.Description == dirInfo.DeviceName).First();
        device.Connect();

        if (device.Model == "Apple iPhone" || !device.IsConnected) return result;

        var pathRoot = device.GetDirectoryInfo(@"\\");
        if (pathRoot == null || pathRoot.EnumerateDirectories().FirstOrDefault() == null) return result;

        var pathDir = device.GetDirectoryInfo(dirInfo.AbsolutePath);
        if (pathDir == null) return result;

        var mediaFiles = pathDir.EnumerateFiles();
        if (mediaFiles == null) return result;



        foreach (MediaFileInfo mediaFile in mediaFiles)
        {
            var file = MobileDeviceFileInfo.Create(dirInfo.DeviceID, dirInfo.DeviceName,
                           mediaFile.FullName, mediaFile.Name, mediaFile.Length, mediaFile.LastWriteTime, string.Empty);
            result.Add(file);
        }

        device.Disconnect();

        return result;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="files"></param>
    /// <param name="localDir"></param>
    /// <param name="view"></param>
    /// <returns></returns>
    public async Task Export(List<MobileDeviceFileInfo> files, string localDir, IWorkingView view)
    {

        if (files == null || files.Count == 0 || string.IsNullOrEmpty(localDir)) return;

        if (!Directory.Exists(localDir)) return;

        var devices = MediaDevice.GetDevices();
        if (devices == null || devices.Count() == 0) return;
        var device = devices.Where(x => x.Description == files.First().DeviceName).First();

        using (device)
        {
            device.Connect();

            if (device.Model != "Apple iPhone" && device.IsConnected)
            {
                if (Directory.Exists(localDir))
                {
                    var count = 0;
                    var total = files.Count();
                    foreach (var file in files)
                    {
                        view.StatusMessage = $"Copying {count++}/{total} {file.FileName}. Please wait...";
                        await Task.Run(() =>
                        {
                            if (!device.FileExists(file.AbsolutePath) || string.IsNullOrEmpty(file.FileName)) return;
                            MemoryStream memoryStream = new MemoryStream();
                            device.DownloadFile(file.AbsolutePath, memoryStream);
                            memoryStream.Position = 0;
                            StreamHelper.WriteSreamToDisk(localDir + $@"\{file.FileName}", memoryStream);
                        });
                    }
                }
            }

            device.Disconnect();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="files"></param>
    /// <param name="deviceDir"></param>
    public async Task Import(string deviceName, IEnumerable<FileResult> files, string deviceDir, IWorkingView view)
    {
        if (files == null || string.IsNullOrEmpty(deviceDir)) return;

        if (files.Count() == 0) return;

        var devices = MediaDevice.GetDevices();
        if (devices == null || devices.Count() == 0) return;
        var device = devices.Where(x => x.Description == deviceName).First();

        using (device)
        {
            device.Connect();

            if (device.Model == "Apple iPhone" || !device.IsConnected) return;

            var count = 0;
            var total = files.Count();
            foreach (var file in files)
            {
                view.StatusMessage = $"Importing {count++}/{total} {file.FileName}. Please wait...";
                await Task.Run(() =>
                {
                    if (device.FileExists(Path.Combine(deviceDir, file.FileName))) return;
                    device.UploadFile(file.FullPath, Path.Combine(deviceDir, file.FileName));
                });
            }

            device.Disconnect();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="files"></param>
    /// <param name="localDir"></param>
    /// <param name="view"></param>
    /// <returns></returns>
    public async Task Delete(List<MobileDeviceFileInfo> files, IWorkingView view)
    {
        if (files == null || files.Count == 0) return;

        var devices = MediaDevice.GetDevices();
        if (devices == null || devices.Count() == 0) return;
        var device = devices.Where(x => x.Description == files.First().DeviceName).First();

        using (device)
        {
            device.Connect();

            if (device.Model != "Apple iPhone" && device.IsConnected)
            {
                var count = 0;
                var total = files.Count();
                foreach (var file in files)
                {
                    view.StatusMessage = $"Deleting {count++}/{total} {file.FileName}. Please wait...";
                    await Task.Run(() =>
                    {
                        if (!device.FileExists(file.AbsolutePath) || string.IsNullOrEmpty(file.FileName)) return;
                        device.DeleteFile(file.AbsolutePath);
                    });
                }
            }

            device.Disconnect();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="file"></param>
    /// <param name="device"></param>
    /// <returns></returns>
    public async Task Delete(MobileDeviceFileInfo file, MediaDevice device = null)
    {

        if (file == null) return;

        if (device == null)
        {
            device = RetrieveDevice(file.DeviceName);
            if (device != null) return;
        }

        using (device)
        {
            device.Connect();

            if (device.DeviceType == MediaDevices.DeviceType.Phone && device.IsConnected)
            {
                await Task.Run(() =>
                {
                    if (!device.FileExists(file.AbsolutePath) || string.IsNullOrEmpty(file.FileName)) return;
                    device.DeleteFile(file.AbsolutePath);
                });
            }

            device.Disconnect();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="deviceName"></param>
    /// <returns></returns>
    private MediaDevice RetrieveDevice(string deviceName)
    {
        var devices = MediaDevice.GetDevices();
        if (devices == null || devices.Count() == 0) return null;
        var device = devices.FirstOrDefault(x => x.Description == deviceName);
        return device;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="files"></param>
    /// <param name="localDir"></param>
    /// <param name="view"></param>
    /// <returns></returns>
    public async Task Rename(MobileDeviceFileInfo file, string newName, IWorkingView view)
    {
        if (file == null) return;

        var devices = MediaDevice.GetDevices();
        if (devices == null || devices.Count() == 0) return;
        var device = devices.Where(x => x.Description == file.DeviceName).First();

        using (device)
        {
            device.Connect();

            if (device.Model != "Apple iPhone" && device.IsConnected)
            {
                view.StatusMessage = $"Renaming {file.FileName}. Please wait...";

                await Task.Run(() =>
                {
                    if (device.FileExists(file.AbsolutePath) && !string.IsNullOrEmpty(file.FileName))
                    {
                        device.Rename(file.AbsolutePath, newName);
                    }
                });
            }

            device.Disconnect();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="file"></param>
    /// <returns></returns>
    public async Task<MemoryStream> ReadFile(MobileDeviceFileInfo file)
    {

        if (file == null) return null;

        var devices = MediaDevice.GetDevices();
        if (devices == null || devices.Count() == 0) return null;
        var device = devices.Where(x => x.Description == file.DeviceName).First();
        MemoryStream result = null;

        using (device)
        {
            device.Connect();

            if (device.Model != "Apple iPhone" && device.IsConnected)
            {
                await Task.Run(() =>
                {
                    if (device.FileExists(file.AbsolutePath) && !string.IsNullOrEmpty(file.FileName))
                    {
                        MemoryStream memoryStream = new MemoryStream();
                        device.DownloadFile(file.AbsolutePath, memoryStream);
                        memoryStream.Position = 0;
                        result = memoryStream;
                    }
                });
            }

            device.Disconnect();
        }

        return result;
    }
}
