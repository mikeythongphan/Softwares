﻿using RaoTorrent.Core.Extensions;

namespace RaoTorrent.Domain.MobileDevices.DataObjects
{
    public class MobileDeviceFileInfo
    {
        public string DeviceID { get; set; }
        public string DeviceName { get; set; }

        private string imageUrl { get; set; }
        public string Thumbnail { get; set; }
        public string ImageThumbnail
        {
            get => imageUrl;
            set 
            {
                imageUrl = value;
                Thumbnail = imageUrl;
            }
        }

        private string _filename { get; set; }
        public string FileName 
        {
            get => _filename;
            set
            {
                _filename = value;
                var index = _filename.LastIndexOf('.');
                if (index < 0) return;
                FName = _filename.Substring(0, index);
                FileExtension = _filename.Substring(index + 1).ToUpper();
            }
        }

        public string FName { get; set; }
        public string FileExtension { get; set; }

        private ulong _fileSize { get; set; }
        public ulong FileSize 
        {
            get => _fileSize;
            set
            {
                _fileSize = value;
                FileSizeKB = ((int)Math.Round(FileSize / 1024.0d)).ToString("#,###") + " KB";
            }
        }

        public string FileSizeKB { get; set; }
        public string DateModified { get; set; }
        public string AbsolutePath { get; set; }
        public bool IsSelected { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="deviceID"></param>
        /// <param name="deviceName"></param>
        /// <param name="absolutePath"></param>
        /// <param name="name"></param>
        /// <param name="size"></param>
        /// <param name="dateModified"></param>
        /// <returns></returns>
        public static MobileDeviceFileInfo Create(string deviceID, string deviceName, string absolutePath, string name, ulong size, DateTime? dateModified, string imageThumbnail)
        {
            var obj = new MobileDeviceFileInfo();
            obj.DeviceID = deviceID;
            obj.DeviceName = deviceName;
            obj.AbsolutePath = absolutePath;
            obj.FileName = name;
            obj.FileSize = size;
            obj.DateModified = dateModified != null ? ((DateTime)dateModified).ToString("MM/dd/yyyy HH:mm:ss") : string.Empty;
            obj.ImageThumbnail = imageThumbnail;
            return obj;
        }

    }
}
