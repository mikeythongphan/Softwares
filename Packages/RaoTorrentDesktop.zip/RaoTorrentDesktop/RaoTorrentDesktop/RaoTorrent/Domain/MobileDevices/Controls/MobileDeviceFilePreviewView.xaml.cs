using CommunityToolkit.Maui.Views;
using Microsoft.Maui.Storage;
using RaoTorrent.Domain.MobileDevices.Android;
using RaoTorrent.Domain.MobileDevices.Apple;
using RaoTorrent.Domain.MobileDevices.ViewModels;
using System.CodeDom.Compiler;
using Freeware;
using RaoTorrent.Core.Extensions;
using RaoTorrent.Domain.MobileDevices.DataObjects;

namespace RaoTorrent.Domain.MobileDevices.Controls;

public partial class MobileDeviceFilePreviewView : ContentView
{

    /// <summary>
    /// 
    /// </summary>
    public static readonly BindableProperty IsLoadingProperty = BindableProperty.Create(nameof(IsLoading),
        typeof(bool), typeof(MobileDeviceExplorer), false);
    public bool IsLoading
    {
        get => (bool)GetValue(IsLoadingProperty);
        set => SetValue(IsLoadingProperty, value);
    }


    private AppleDeviceService AppleDevice { get; set; } = new AppleDeviceService();
    private AndroidDeviceService DroidDevice { get; set; } = new AndroidDeviceService();

    private static List<string> ImageExtensions => new List<string>() { "HEIC", "JPEG", "JPG", "PNG", "GIF", "TIFF", "PSD", "EPS", "AI", "INDD", "RAW" };
    private static List<string> PdfExtensions => new List<string>() { "PDF" };
    private static List<string> MovieExtensions => new List<string>() { "MP4", "MOV" };

    public MobileDeviceFilePreviewView()
    {
        InitializeComponent();
    }

    /// <summary>
    /// 
    /// </summary>
    public void Clear()
    {
        FileViewer.Children.Clear();

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="file"></param>
    public async Task LoadFile(MobileDeviceFileVM fileVM)
    {

        Clear();
        IsLoading = true;

        var file = fileVM.MapTo<MobileDeviceFileVM, MobileDeviceFileInfo>();
        var fs = fileVM.IsAppleDevice ? await AppleDevice.ReadFile(file) : await DroidDevice.ReadFile(file);
        if (ImageExtensions.Contains(file.FileExtension))
        {
            var image = new Image();

            var tempFiles = new TempFileCollection();
            string fileName = tempFiles.AddExtension(file.FileExtension);
            System.Drawing.Image imagex = System.Drawing.Image.FromStream(fs);
            System.Drawing.Image thumb = imagex.GetThumbnailImage(120, 120, () => false, IntPtr.Zero);
            thumb.Save(Path.ChangeExtension(fileName, "thumb"));

            image.Source = ImageSource.FromStream(() => fs);
            FileViewer.Children.Add(image);
        }
        else if (MovieExtensions.Contains(file.FileExtension))
        {
            var tempFiles = new TempFileCollection();

            string fileName = tempFiles.AddExtension(file.FileExtension);

            using (FileStream fileStream = new FileStream(fileName, FileMode.Create, System.IO.FileAccess.Write))
            {
                byte[] bytes = new byte[fs.Length];
                fs.Read(bytes, 0, (int)fs.Length);
                fileStream.Write(bytes, 0, bytes.Length);
                fs.Close();
            }

            MediaElement mediaElement = new MediaElement()
            {
                ShouldAutoPlay = true,
                ShouldShowPlaybackControls = false,
                Source = FileMediaSource.FromFile(fileName)
            };

            FileViewer.Children.Add(mediaElement);
        }
        else if (PdfExtensions.Contains(file.FileExtension))
        {
            var tempFiles = new TempFileCollection();

            string fileImage = tempFiles.AddExtension("PNG");

            byte[] buff = Pdf2Png.Convert(fs, 1);
            MemoryStream ms = new MemoryStream(buff);
            System.Drawing.Image img = System.Drawing.Image.FromStream(ms);
            img.Save(fileImage, System.Drawing.Imaging.ImageFormat.Tiff);

            Image image = new Image()
            {
                Source = ImageSource.FromFile(fileImage)
            };

            FileViewer.Children.Add(image);
        }

        IsLoading = false;

    }
}