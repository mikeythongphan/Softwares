namespace RaoTorrent.Domain.MobileDevices.Controls;

public partial class MobileDeviceFileThumbnailView : ContentView
{
	public MobileDeviceFileThumbnailView()
	{
		InitializeComponent();
	}
}