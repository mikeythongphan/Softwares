using RaoTorrent.Core.Controls;
using RaoTorrent.Domain.MobileDevices.Android;
using RaoTorrent.Domain.MobileDevices.Apple;
using RaoTorrent.Domain.MobileDevices.DataObjects;

namespace RaoTorrent.Domain.MobileDevices.Controls;

public partial class MobileDeviceExplorer : ContentView
{

    public event EventHandler<TreeViewNodeTappedEventArgs> ItemTapped;

    private AppleDeviceService AppleDevice { get; set; } = new AppleDeviceService();
    private AndroidDeviceService DroidDevice { get; set; } = new AndroidDeviceService();

    /// <summary>
    /// 
    /// </summary>
    public static readonly BindableProperty IsLoadingProperty = BindableProperty.Create(nameof(IsLoading),
        typeof(bool), typeof(MobileDeviceExplorer), true);
    public bool IsLoading
    {
        get => (bool)GetValue(IsLoadingProperty);
        set => SetValue(IsLoadingProperty, value);
    }

    /// <summary>
    /// 
    /// </summary>
    public MobileDeviceExplorer()
	{
		InitializeComponent();
        LoadMobileDeviceTree();
	}

    /// <summary>
    /// 
    /// </summary>
    private async void LoadMobileDeviceTree()
    {
        IsLoading = true;

        var treeview = new TreeViewNodes();

        await Task.Run(async () =>
        {
            var appleDevices = await AppleDevice.GetDevices();
            await LoadDevices(treeview, appleDevices, true);

            var droidDevices = await DroidDevice.GetDevices();
            await LoadDevices(treeview, droidDevices, false);
        });

        DeviceTree.Clear();
        DeviceTree.RootNodes = treeview;
        IsLoading = false;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="treeview"></param>
    /// <returns></returns>
    private async Task LoadDevices(TreeViewNodes treeview, List<MobileDeviceFileInfo> devices, bool isAppleDevice)
    {
        foreach (var device in devices)
        {

            var children = isAppleDevice ? await AppleDevice.GetDirectories(device) : await DroidDevice.GetDirectories(device);
            var deviceNode = MobileDeviceTreeViewNode.CreateDevice(device, isAppleDevice);
            var childNodes = new TreeViewNodes();

            foreach (var child in children)
            {
                var childNode = MobileDeviceTreeViewNode.CreateDirectory(child, deviceNode);
                childNodes.Add(childNode);
            }

            deviceNode.Children = childNodes;
            treeview.Add(deviceNode);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnRefresh(object sender, EventArgs e)
    {
        LoadMobileDeviceTree();
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnDeviceTreeItemTapped(object sender, TreeViewNodeTappedEventArgs e)
    {
        if (e == null || e.Node == null) return;
        ItemTapped?.Invoke(this, e);
    }

}