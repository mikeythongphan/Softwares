﻿using DeviceDetectorNET.Class.Device;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;
using RaoTorrent.Core.Controls;
using RaoTorrent.Domain.MobileDevices.Android;
using RaoTorrent.Domain.MobileDevices.Apple;
using RaoTorrent.Domain.MobileDevices.DataObjects;

namespace RaoTorrent.Domain.MobileDevices.Controls
{
    public class MobileDeviceTreeViewNode : TreeViewNode
    {

        private AppleDeviceService AppleDevice { get; set; } = new AppleDeviceService();
        private AndroidDeviceService DroidDevice { get; set; } = new AndroidDeviceService();


        public new MobileDeviceTreeViewNode ParentNode
        {
            get => base.ParentNode as MobileDeviceTreeViewNode;
            set => base.ParentNode = value;
        }

        /// <summary>
        /// 
        /// </summary>
        private bool _isAppleDevice;
        public bool IsAppleDevice
        {
            get => ParentNode != null ? ParentNode.IsAppleDevice : _isAppleDevice;
            set => _isAppleDevice = value;
        }

        /// <summary>
        /// 
        /// </summary>
        private string _deviceName;
        public string DeviceName
        {
            get => ParentNode != null ? ParentNode.DeviceName : _deviceName;
            set => _deviceName = value;
        }

        /// <summary>
        /// 
        /// </summary>
        private string _deviceID;
        public string DeviceID
        {
            get => ParentNode != null ? ParentNode.DeviceID : _deviceID;
            set => _deviceID = value;
        }

        public string AbsolutePath { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public MobileDeviceTreeViewNode() : base()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 
        /// </summary>
        private void InitializeComponent()
        {
            if (IsEnabled)
            {
                ItemIndicator.GestureRecognizers.Clear();
                var indicatorGesture = new TapGestureRecognizer();
                indicatorGesture.Tapped += async (s, e) =>
                {
                    IsExpanded = !IsExpanded;

                    if (!IsExpanded) return;
                    if (Children != null && Children.Count > 0) return;

                    var dirInfo = ToMobileDeviceFileInfo(this);

                    var children = IsAppleDevice ? await AppleDevice.GetDirectories(dirInfo) : await DroidDevice.GetDirectories(dirInfo);
                    var childNodes = new TreeViewNodes();
                    foreach (var child in children)
                    {
                        var childNode = CreateDirectory(child, this);
                        childNodes.Add(childNode);
                    }
                    Children = childNodes;

                };
                ItemIndicator.GestureRecognizers.Add(indicatorGesture);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        public static MobileDeviceTreeViewNode CreateDevice(MobileDeviceFileInfo file, bool isAppleDevice)
        {
            var obj = new MobileDeviceTreeViewNode();
            obj.Text = file.DeviceName;
            obj.DeviceID = file.DeviceID;
            obj.DeviceName = file.DeviceName;
            obj.AbsolutePath = file.AbsolutePath;
            obj.Icon = "iphone.png";
            obj.IsAppleDevice = isAppleDevice;
            obj.IsExpanded = true;
            return obj;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="file"></param>
        /// <param name="parent"></param>
        /// <returns></returns>
        public static MobileDeviceTreeViewNode CreateDirectory(MobileDeviceFileInfo file,
            MobileDeviceTreeViewNode parent)
        {
            var obj = new MobileDeviceTreeViewNode();
            obj.ParentNode = parent;
            obj.DeviceID = file.DeviceID;
            obj.DeviceName = file.DeviceName;
            obj.Text = file.FileName;
            obj.AbsolutePath = file.AbsolutePath;
            obj.Indentation = parent.Indentation + 10;
            obj.Icon = "folder_close.png";
            obj.TreeItem.Margin = new Thickness(obj.Indentation, 0, 0, 0);
            return obj;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        public static MobileDeviceFileInfo ToMobileDeviceFileInfo(MobileDeviceTreeViewNode node)
        {
            var obj = new MobileDeviceFileInfo();
            obj.DeviceID = node.DeviceID;
            obj.DeviceName = node.DeviceName;
            obj.FileName = node.Text;
            obj.AbsolutePath = node.AbsolutePath;
            return obj;
        }

    }
}
