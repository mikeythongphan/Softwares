﻿using RaoTorrent.Core.Controls;
using System.Windows.Input;
using Button = RaoTorrent.Core.Controls.Button;

namespace RaoTorrent.Domain.MobileDevices.Controls;

public class MobileDeviceAccordion : Accordion
{

    public event EventHandler OnRefresh;

    /// <summary>
    /// 
    /// </summary>
    private ICommand _command;
    public ICommand Command
    {
        get => _command;
        set => _command = value;
    }

    /// <summary>
    /// 
    /// </summary>
    private object _commandParam;
    public object CommandParam
    {
        get => _commandParam;
        set => _commandParam = value;
    }

    private Button BtnRefresh { get; set; } = new Button();

    /// <summary>
    /// 
    /// </summary>
    public MobileDeviceAccordion() : base()
    {
        HeaderView.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));

        BtnRefresh.FontFamily = "FontAwesomeSolid";
        BtnRefresh.Text = "\uf021";
        BtnRefresh.HasBorder = false;
        BtnRefresh.Margin = new Thickness(0,0,10,0);
        BtnRefresh.Clicked += BtnRefreshClicked;

        Grid.SetColumn(BtnRefresh, 1);
        Grid.SetColumn(Indicator, 2);

        HeaderView.Children.Add(BtnRefresh);


    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void BtnRefreshClicked(object sender, EventArgs e)
    {
        OnRefresh?.Invoke(this, e);
    }
}
