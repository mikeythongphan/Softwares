namespace RaoTorrent.Domain.MobileDevices.Controls;

public partial class ListViewThumbnail : ContentView
{
	public ListViewThumbnail()
	{
		InitializeComponent();
	}
}