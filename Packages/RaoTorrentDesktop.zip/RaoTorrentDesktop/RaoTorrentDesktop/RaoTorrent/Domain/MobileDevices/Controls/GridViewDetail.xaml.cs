namespace RaoTorrent.Domain.MobileDevices.Controls;

public partial class GridViewDetail : ContentView
{
    public event EventHandler<SelectionChangedEventArgs> ItemSelected;

    public GridViewDetail()
	{
		InitializeComponent();
        FileList.BindingContext = this;
    }

    private void OnItemSelected(object sender, SelectionChangedEventArgs e)
    {
        ItemSelected?.Invoke(this, e);
    }
}