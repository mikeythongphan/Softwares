using RaoTorrent.Core.Extensions;
using RaoTorrent.Domain.MobileDevices.DataObjects;
using RaoTorrent.Domain.MobileDevices.ViewModels;
using System.Collections.ObjectModel;

namespace RaoTorrent.Domain.MobileDevices.Controls;

public partial class MobileDeviceFileListView : ContentView
{

    /// <summary>
    /// 
    /// </summary>
    public static readonly BindableProperty IsLoadingProperty = BindableProperty.Create(nameof(IsLoading),
        typeof(bool), typeof(MobileDeviceExplorer), false);
    public bool IsLoading
    {
        get => (bool)GetValue(IsLoadingProperty);
        set => SetValue(IsLoadingProperty, value);
    }

    public static readonly BindableProperty IsViewThumbnailProperty = BindableProperty.Create(nameof(IsViewThumbnail),
        typeof(bool), typeof(MobileDeviceFileListView), false);
    public bool IsViewThumbnail
    {
        get => (bool)GetValue(IsViewThumbnailProperty);
        set => SetValue(IsViewThumbnailProperty, value);
    }

    public static readonly BindableProperty IsViewDetailProperty = BindableProperty.Create(nameof(IsViewDetail),
        typeof(bool), typeof(MobileDeviceFileListView), false);
    public bool IsViewDetail
    {
        get => (bool)GetValue(IsViewDetailProperty);
        set => SetValue(IsViewDetailProperty, value);
    }

    public static readonly BindableProperty StreamProperty = BindableProperty.Create(nameof(StreamDetail),
        typeof(Stream), typeof(MobileDeviceFileListView), false);
    public Stream StreamDetail
    {
        get => (Stream)GetValue(StreamProperty);
        set => SetValue(StreamProperty, value);
    }

    public event EventHandler<SelectionChangedEventArgs> ItemSelected;
    public ObservableCollection<MobileDeviceFileVM> Items { get; } = new();
    public ObservableCollection<MobileDeviceFileVM> SelectedItems { get; set; } = new();

    /// <summary>
    /// 
    /// </summary>
    public MobileDeviceFileListView()
    {
        InitializeComponent();
        FileList.BindingContext = this;
        FileListThumbnail.BindingContext = this;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnItemSelected(object sender, SelectionChangedEventArgs e)
    {
        ItemSelected?.Invoke(this, e);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="node"></param>
    public async Task LoadFiles(MobileDeviceTreeViewNode node)
    {
        IsLoading = true;
        IsViewDetail = false;
        IsViewThumbnail = false;

        //FileList.ClearHeaderCheckBoxes();
        //var dirInfo = MobileDeviceTreeViewNode.ToMobileDeviceFileInfo(node);
        //var files = node.IsAppleDevice ? await GlobalVars.AppleDevice.GetFiles(dirInfo) : GlobalVars.DroidDevice.GetFiles(dirInfo);

        var files = await GetFiles();

        var items = files.MapTo<MobileDeviceFileInfo, MobileDeviceFileVM>();
        Items.Refresh(items);

        IsViewDetail = false;
        IsViewThumbnail = false;
        IsLoading = false;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public List<MobileDeviceFileInfo> GetSelectedFiles()
    {
        var files = Items.Where(x => x.IsSelected)
            .ToList()
            .MapTo<MobileDeviceFileVM, MobileDeviceFileInfo>();
        return files;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="files"></param>
    public void Refresh(List<MobileDeviceFileInfo> files)
    {
        var items = files.MapTo<MobileDeviceFileInfo, MobileDeviceFileVM>();
        Items.Refresh(items);
    }

    /// <summary>
    /// 
    /// </summary>
    public void UnSelectAll()
    {
        foreach (var item in Items.Where(x => x.IsSelected)) item.IsSelected = false;
        //FileList.ClearHeaderCheckBoxes();
    }

    public async Task<List<MobileDeviceFileInfo>> GetFiles()
    {

        var result = new List<MobileDeviceFileInfo>();

        var path = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

        if (DeviceInfo.Platform == DevicePlatform.WinUI)
        {
            path = "C:\\Users\\v31327\\Downloads\\HLBVN\\";
        }

        var filenames = Directory.EnumerateFiles("C:\\path", "*.*", SearchOption.AllDirectories)
            .Where(s => s.EndsWith(".png"));
        if (filenames == null) return null;
        foreach (var filename in filenames)
        {
            var fileInfo = new FileInfo(filename);
            if (fileInfo == null) continue;

            string imageSource = string.Empty;

            if (!filename.Contains(".png"))
                imageSource = "thumbnails.png";
            else
                imageSource = filename;

            MemoryStream ms = new MemoryStream();
            using (FileStream filex = new FileStream(filename, FileMode.Open, FileAccess.Read))
                filex.CopyTo(ms);

            //StreamDetail = ms;

            var file = MobileDeviceFileInfo.Create(string.Empty, string.Empty,
                  fileInfo.FullName, fileInfo.Name, (ulong)fileInfo.Length, fileInfo.CreationTime, Convert.ToBase64String(ms.ToArray()));
            result.Add(file);
        }

        return result;
    }
}