using RaoTorrent.Core.Interfaces;
using RaoTorrent.Domain.MobileDevices.Android;
using RaoTorrent.Domain.MobileDevices.Apple;
using RaoTorrent.Domain.MobileDevices.ViewModels;
using RaoTorrent.Domain.MobileDevices.DataObjects;
using RaoTorrent.Core.Extensions;
using System.Windows.Markup;
using System.Xml.Linq;
using YamlDotNet.Core;

namespace RaoTorrent.Domain.MobileDevices.Controls;

public partial class MobileDeviceFileView : ContentView, IWorkingView
{

    private IFolderPicker FolderPicker => GlobalVars.FolderPicker;
    private AppleDeviceService AppleDevice { get; set; } = new AppleDeviceService();
    private AndroidDeviceService DroidDevice { get; set; } = new AndroidDeviceService();

    private MobileDeviceTreeViewNode SelectedDir { get; set; }

    public static readonly BindableProperty StatusMessageProperty = BindableProperty.Create(nameof(StatusMessage),
        typeof(string), typeof(MobileDeviceExplorer), string.Empty);
    public string StatusMessage
    {
        get => (string)GetValue(StatusMessageProperty);
        set => SetValue(StatusMessageProperty, value);
    }

    /// <summary>
    /// 
    /// </summary>
    public static readonly BindableProperty IsProcessingProperty = BindableProperty.Create(nameof(IsProcessing),
        typeof(bool), typeof(MobileDeviceExplorer), false);
    public bool IsProcessing
    {
        get => (bool)GetValue(IsProcessingProperty);
        set => SetValue(IsProcessingProperty, value);
    }

    public static readonly BindableProperty IsViewThumbnailProperty = BindableProperty.Create(nameof(IsViewThumbnail),
    typeof(bool), typeof(MobileDeviceFileListView), false);
    public bool IsViewThumbnail
    {
        get => (bool)GetValue(IsViewThumbnailProperty);
        set => SetValue(IsViewThumbnailProperty, value);
    }

    public static readonly BindableProperty IsIsViewDetailProperty = BindableProperty.Create(nameof(IsViewDetail),
        typeof(bool), typeof(MobileDeviceFileListView), false);
    public bool IsViewDetail
    {
        get => (bool)GetValue(IsIsViewDetailProperty);
        set => SetValue(IsIsViewDetailProperty, value);
    }

    /// <summary>
    /// 
    /// </summary>
    public MobileDeviceFileView()
    {
        InitializeComponent();
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnMobileDeviceFileListViewItemSelected(object sender, SelectionChangedEventArgs e)
    {

        if (SelectedDir == null || e.CurrentSelection == null
            || e.CurrentSelection.Count == 0 || e.CurrentSelection.Count > 1) return;

        var file = e.CurrentSelection.First() as MobileDeviceFileVM;
        file.IsAppleDevice = SelectedDir.IsAppleDevice;
        await FilePreview.LoadFile(file);

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="node"></param>
    public async Task LoadFiles(MobileDeviceTreeViewNode node)
    {
        FilePreview.Clear();
        await FileList.LoadFiles(node);
        SelectedDir = node;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnCreateDirectory(object sender, EventArgs e)
    {

        if (SelectedDir == null) return;

        string result = await Application.Current.MainPage.DisplayPromptAsync("Message", "Please enter the new direcotory name.");
        if (string.IsNullOrEmpty(result)) return;

        var filePath = SelectedDir.AbsolutePath + "/" + result;
        if (SelectedDir.IsAppleDevice) await AppleDevice.CreateDirectory(SelectedDir.DeviceID, filePath);
        else await DroidDevice.CreateDirectory(SelectedDir.DeviceID, filePath);
        //SelectedDir.TreeView.Refresh(); // TODO

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnDeleteDirectory(object sender, EventArgs e)
    {

        if (SelectedDir == null) return;

        bool result = await Application.Current.MainPage.DisplayAlert("Message", $"Do you want to delete {SelectedDir.Text}?", "Yes", "No");
        if (!result) return;

        var file = MobileDeviceTreeViewNode.ToMobileDeviceFileInfo(SelectedDir);
        if (SelectedDir.IsAppleDevice) await AppleDevice.Delete(file);
        else await DroidDevice.Delete(file);
        //SelectedDir.TreeView.Refresh(); // TODO

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnViewFileList(object sender, EventArgs e)
    {
        FilePreview.Clear();
        await FileList.LoadFiles(null);
        FileList.IsViewThumbnail = false;
        FileList.IsViewDetail = true;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnViewFileThumbnail(object sender, EventArgs e)
    {
        FilePreview.Clear();
        await FileList.LoadFiles(null);
        FileList.IsViewThumbnail = true;
        FileList.IsViewDetail = false;

        //MobileDeviceFileVM fileVM = new MobileDeviceFileVM();

        //if (SelectedDir == null) return;

        //var file = fileVM.MapTo<MobileDeviceFileVM, MobileDeviceFileInfo>();
        //var fs = fileVM.IsAppleDevice ? await AppleDevice.ReadFile(file) : await DroidDevice.ReadFile(file);

        ////var file = e.CurrentSelection.First() as MobileDeviceFileVM;
        ////file.IsAppleDevice = SelectedDir.IsAppleDevice;

        //int imageHeight = 100;
        //int imageWidth = 100;

        //System.Drawing.Image fullSizeImg = System.Drawing.Image.FromStream(fs);
        //System.Drawing.Image.GetThumbnailImageAbort dummyCallBack = new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);
        //System.Drawing.Image thumbNailImage = fullSizeImg.GetThumbnailImage(imageWidth, imageHeight, dummyCallBack, IntPtr.Zero);
        //thumbNailImage.Save(fs, System.Drawing.Imaging.ImageFormat.Jpeg);
        //thumbNailImage.Dispose();
        //fullSizeImg.Dispose();
    }

    public bool ThumbnailCallback()
    {
        return false;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnExport(object sender, EventArgs e)
    {
        if (SelectedDir == null) return;

        var pickedFolder = await FolderPicker.PickFolder();

        var files = FileList.GetSelectedFiles();
        if (files == null || files.Count == 0) return;

        IsProcessing = true;

        if (SelectedDir.IsAppleDevice) await AppleDevice.Export(files, pickedFolder, this);
        else await DroidDevice.Export(files, pickedFolder, this);

        FileList.UnSelectAll();

        StatusMessage = string.Empty;
        IsProcessing = false;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnImport(object sender, EventArgs e)
    {
        if (SelectedDir == null) return;

        var result = await FilePicker.PickMultipleAsync(new PickOptions
        {
            PickerTitle = "Select Files"
        });

        if (result == null || result.Count() == 0) return;

        IsProcessing = true;
        if (SelectedDir.IsAppleDevice) await AppleDevice.Import(SelectedDir.DeviceID, result, SelectedDir.AbsolutePath, this);
        else await DroidDevice.Import(SelectedDir.DeviceName, result, SelectedDir.AbsolutePath, this);

        var dirInfo = MobileDeviceTreeViewNode.ToMobileDeviceFileInfo(SelectedDir);
        var files = SelectedDir.IsAppleDevice ? await AppleDevice.GetFiles(dirInfo) : DroidDevice.GetFiles(dirInfo);
        FileList.Refresh(files);
        IsProcessing = false;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnDelete(object sender, EventArgs e)
    {
        if (SelectedDir == null) return;

        var files = FileList.GetSelectedFiles();
        if (files == null || files.Count == 0) return;

        bool result = await Application.Current.MainPage.DisplayAlert("Message", "Do you want to delete the selected files?", "Yes", "No");
        if (!result) return;

        IsProcessing = true;

        if (SelectedDir.IsAppleDevice) await AppleDevice.Delete(files, this);
        else await DroidDevice.Delete(files, this);

        var dirInfo = MobileDeviceTreeViewNode.ToMobileDeviceFileInfo(SelectedDir);
        files = SelectedDir.IsAppleDevice ? await AppleDevice.GetFiles(dirInfo) : DroidDevice.GetFiles(dirInfo);
        FileList.Refresh(files);

        IsProcessing = false;

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnRename(object sender, EventArgs e)
    {
        if (SelectedDir == null) return;

        var files = FileList.GetSelectedFiles();
        if (files == null || files.Count == 0 || files.Count > 1) return;

        string result = await Application.Current.MainPage.DisplayPromptAsync("Message", "Please enter the new file name.");

        if (string.IsNullOrEmpty(result)) return;

        var filePath = SelectedDir.AbsolutePath + "/" + result;
        if (SelectedDir.IsAppleDevice) await AppleDevice.Rename(files.First(), filePath, this);
        else await DroidDevice.Rename(files.First(), filePath, this);

        var dirInfo = MobileDeviceTreeViewNode.ToMobileDeviceFileInfo(SelectedDir);
        files = SelectedDir.IsAppleDevice ? await AppleDevice.GetFiles(dirInfo) : DroidDevice.GetFiles(dirInfo);
        FileList.Refresh(files);

    }

    public void GenerateThumbnail(string thumbPath, int thumbWidth, int thumbHeight, string thumbNewPath)
    {
        System.Drawing.Image image = new System.Drawing.Bitmap(thumbPath);
        System.Drawing.Image imageThumbnail = image.GetThumbnailImage(thumbWidth, thumbHeight, null, new IntPtr());
        imageThumbnail.Save(thumbNewPath);
    }

    public void Example_GetThumb(/*PaintEventArgs e*/)
    {
        System.Drawing.Image.GetThumbnailImageAbort myCallback =
        new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);
        System.Drawing.Bitmap myBitmap = new System.Drawing.Bitmap("Climber.jpg");
        System.Drawing.Image myThumbnail = myBitmap.GetThumbnailImage(
        40, 40, myCallback, IntPtr.Zero);
        //e.Graphics.DrawImage(myThumbnail, 150, 75);
    }
}