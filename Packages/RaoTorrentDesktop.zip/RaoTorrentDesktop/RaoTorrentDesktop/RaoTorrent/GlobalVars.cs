﻿using RaoTorrent.Core.Interfaces;
using RaoTorrent.Domain.MobileDevices.Android;
using RaoTorrent.Domain.MobileDevices.Apple;
using ServiceProvider = RaoTorrent.Core.Providers.ServiceProvider;

namespace RaoTorrent
{
    public static class GlobalVars
    {
        public static IFolderPicker FolderPicker => ServiceProvider.GetService<IFolderPicker>();

        public static AppleDeviceService AppleDevice { get; set; } = new AppleDeviceService();
        public static AndroidDeviceService DroidDevice { get; set; } = new AndroidDeviceService();

    }
}
