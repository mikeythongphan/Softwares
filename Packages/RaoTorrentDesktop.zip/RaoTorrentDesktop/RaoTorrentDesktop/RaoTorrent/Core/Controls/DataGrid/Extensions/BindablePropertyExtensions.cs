using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using static Microsoft.Maui.Controls.BindableProperty;

namespace RaoTorrent.Core.Controls;

internal static class BindablePropertyExtensions
{

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TType"></typeparam>
    /// <param name="defaultValue"></param>
    /// <param name="defaultBindingMode"></param>
    /// <param name="validateValue"></param>
    /// <param name="propertyChanged"></param>
    /// <param name="propertyChanging"></param>
    /// <param name="coerceValue"></param>
    /// <param name="defaultValueCreator"></param>
    /// <param name="propertyName"></param>
    /// <returns></returns>
    /// <exception cref="InvalidOperationException"></exception>
    /// <exception cref="ArgumentException"></exception>
    public static BindableProperty Create<TType>(
        TType? defaultValue = default,
        BindingMode defaultBindingMode = BindingMode.OneWay,
        ValidateValueDelegate<TType?>? validateValue = null,
        BindingPropertyChangedDelegate<TType?>? propertyChanged = null,
        BindingPropertyChangingDelegate<TType?>? propertyChanging = null,
        CoerceValueDelegate<TType?>? coerceValue = null,
        CreateDefaultValueDelegate? defaultValueCreator = null,
        [CallerMemberName] string propertyName = "")
    {
        if (!propertyName.EndsWith("Property", StringComparison.Ordinal))
        {
            throw new InvalidOperationException("This extension must be used on a BindableProperty whose name is suffixed with the word 'Property'");
        }

        var trimmedPropertyName = propertyName[..^8];

        if (new StackTrace().GetFrame(1) is not StackFrame callerFrame)
        {
            throw new ArgumentException("StackFrame not found");
        }

        if (callerFrame.GetMethod() is not MethodBase callerMethod)
        {
            throw new ArgumentException("Caller method not found");
        }

        var callerType = callerMethod.DeclaringType;

        ValidateValueDelegate? untypedValidateValue = null;
        if (validateValue != null)
        {
            untypedValidateValue = (b, v) => validateValue(b, v is TType typedValue ? typedValue : default);
        }

        BindingPropertyChangedDelegate? untypedPropertyChanged = null;
        if (propertyChanged != null)
        {
            untypedPropertyChanged = (b, o, n) => propertyChanged(b, o is TType typedOldValue ? typedOldValue : default, n is TType typedNewValue ? typedNewValue : default);
        }

        BindingPropertyChangingDelegate? untypedPropertyChanging = null;
        if (propertyChanging != null)
        {
            untypedPropertyChanging = (b, o, n) => propertyChanging(b, o is TType typedOldValue ? typedOldValue : default, n is TType typedNewValue ? typedNewValue : default);
        }

        CoerceValueDelegate? untypedCoerceValue = null;
        if (coerceValue != null)
        {
            untypedCoerceValue = (b, v) => coerceValue(b, v is TType typedValue ? typedValue : default);
        }

        return BindableProperty.Create(
            trimmedPropertyName,
            typeof(TType),
            callerType,
            defaultValue,
            defaultBindingMode,
            untypedValidateValue,
            untypedPropertyChanged,
            untypedPropertyChanging,
            untypedCoerceValue,
            defaultValueCreator);
    }
}
