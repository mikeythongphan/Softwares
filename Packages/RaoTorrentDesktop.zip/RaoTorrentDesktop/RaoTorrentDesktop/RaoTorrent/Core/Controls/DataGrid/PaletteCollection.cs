namespace RaoTorrent.Core.Controls;

/// <summary>
/// Creates PaletteCollection for row's visual. It repeats colors consecutively for rows.
/// </summary>
public sealed class DataGridPaletteCollection : List<Color>, IDataGridColorProvider
{
    /// <summary>
    /// Determines the <c>Color</c> for the row
    /// </summary>
    /// <param name="rowIndex">Index of the row based on DataSource</param>
    /// <param name="item">Item on the index</param>
    /// <returns>Color for the row</returns>
    public Color GetColor(int rowIndex, object item) => Count > 0 ? this.ElementAt(rowIndex % Count) : Colors.White;
}
