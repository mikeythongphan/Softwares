using System.ComponentModel;

namespace RaoTorrent.Core.Controls;

/// <summary>
/// 
/// </summary>
[TypeConverter(typeof(DataGridSortDataTypeConverter))]
public sealed class DataGridSortData
{

    /// <summary>
    /// 
    /// </summary>
    /// <param name="index"></param>
    public static implicit operator DataGridSortData(int index) => new()
    {
        Index = Math.Abs(index),
        Order = index < 0 ? DataGridSortingOrder.Descendant : DataGridSortingOrder.Ascendant
    };

    /// <summary>
    /// 
    /// </summary>
    /// <param name="obj"></param>
    /// <returns></returns>
    public override bool Equals(object? obj) => obj is DataGridSortData other && other.Index == Index && other.Order == Order;

    public DataGridSortData()
    { }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="index"></param>
    /// <param name="order"></param>
    public DataGridSortData(int index, DataGridSortingOrder order)
    {
        Index = index;
        Order = order;
    }

    /// <summary>
    /// Sorting order for the column
    /// </summary>
    public DataGridSortingOrder Order { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public int Index { get; set; }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public override int GetHashCode() => HashCode.Combine(Index, Order);
}
