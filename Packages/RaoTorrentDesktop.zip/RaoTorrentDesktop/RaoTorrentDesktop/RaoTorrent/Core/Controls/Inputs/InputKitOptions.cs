﻿namespace RaoTorrent.Core.Controls;

public class InputKitOptions
{
    public static Func<Color> GetAccentColor { get; set; } = () => Color.FromArgb("#512bdf");
}
