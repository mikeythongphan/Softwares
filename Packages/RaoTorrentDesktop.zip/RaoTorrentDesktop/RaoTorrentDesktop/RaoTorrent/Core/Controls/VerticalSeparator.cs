﻿namespace RaoTorrent.Core.Controls;

public class VerticalSeparator : ContentView
{

    public double Space
    {
        get => WidthRequest;
        set => WidthRequest = value;
    }

    /// <summary>
    /// 
    /// </summary>
    public VerticalSeparator()
    {
        InitializeComponent(0);
    }

    /// <summary>
    /// 
    /// </summary>
    public VerticalSeparator(int space = 0)
    {
        InitializeComponent(space);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="space"></param>
    void InitializeComponent(int space)
    {
        Content = new BoxView
        {
            Color = Colors.Transparent,
            WidthRequest = space,
            VerticalOptions = LayoutOptions.Fill,
        };
    }

}
