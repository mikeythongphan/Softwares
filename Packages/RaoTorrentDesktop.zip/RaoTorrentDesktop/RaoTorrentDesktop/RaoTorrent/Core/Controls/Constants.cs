﻿namespace RaoTorrent.Core.Controls
{
    public enum CursorIcon
    {
        Wait,
        Hand,
        Arrow,
        IBeam,
        Cross,
        SizeAll
    }
}
