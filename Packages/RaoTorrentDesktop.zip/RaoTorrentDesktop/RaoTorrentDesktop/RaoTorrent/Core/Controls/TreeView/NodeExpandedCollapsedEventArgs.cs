﻿namespace RaoTorrent.Core.Controls;

public class TreeViewNodeExpandedCollapsedEventArgs  : EventArgs
{

    public TreeViewNode Node { get; set; }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="treeViewNode"></param>
    public TreeViewNodeExpandedCollapsedEventArgs(TreeViewNode treeViewNode)
    {
        Node = treeViewNode;
    }

}