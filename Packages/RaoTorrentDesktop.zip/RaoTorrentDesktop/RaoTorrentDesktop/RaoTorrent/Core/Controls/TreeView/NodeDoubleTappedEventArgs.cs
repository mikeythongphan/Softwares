﻿namespace RaoTorrent.Core.Controls;

public class TreeViewNodeDoubleTappedEventArgs : EventArgs
{

    public TreeViewNode Node { get; set; }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="treeViewNode"></param>
    public TreeViewNodeDoubleTappedEventArgs(TreeViewNode treeViewNode)
    {
        Node = treeViewNode;
    }
    
}