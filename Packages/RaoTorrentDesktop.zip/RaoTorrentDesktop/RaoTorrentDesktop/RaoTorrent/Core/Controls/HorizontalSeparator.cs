﻿namespace RaoTorrent.Core.Controls;

public class HorizontalSeparator : ContentView
{

    public double Space
    {
        get => HeightRequest;
        set => HeightRequest = value;
    }

    /// <summary>
    /// 
    /// </summary>
    public HorizontalSeparator()
    {
        Content = new BoxView
        {
            Color = Colors.Transparent,
            HeightRequest = 0,
            HorizontalOptions = LayoutOptions.Fill,
        };
    }

}
