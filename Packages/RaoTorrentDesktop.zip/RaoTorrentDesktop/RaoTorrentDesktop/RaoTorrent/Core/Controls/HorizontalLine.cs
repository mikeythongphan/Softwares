﻿namespace RaoTorrent.Core.Controls;

public class HorizontalLine : ContentView
{

    public HorizontalLine()
    {
        Content = new BoxView
        {
            Color = Colors.LightGray,
            HeightRequest = 1,
            HorizontalOptions = LayoutOptions.Fill,
        };
    }
}
