﻿namespace RaoTorrent.Core.Extensions;

public static class StringExtensions
{

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static string ToFileExtension(this string val)
    {
        var index = val.LastIndexOf('.');
        if (index < 0) return string.Empty;
        var ext = val.Substring(index + 1).ToUpper();
        return ext;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <param name="chars"></param>
    /// <returns></returns>
    public static string Remove(this string val, params char[] chars) => val == null
        ? null
        : chars.Aggregate(val, (current, ch) => current.Replace(ch.ToString(), string.Empty));

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static short ToShort(this string val)
    {
        if (val == null) return 0;
        try
        {
            return short.Parse(val);
        }
        catch
        {
            return 0;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static bool ToBool(this string val)
    {
        if (val == null) return false;
        try
        {
            return bool.Parse(val);
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static int ToInt(this string val)
    {
        if (val == null) return 0;
        try
        {
            return int.Parse(val);
        }
        catch
        {
            return 0;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static int? ToIntN(this string val)
    {
        try { return int.Parse(val); }
        catch { return null; }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static long ToLong(this string val)
    {
        if (val == null) return 0;
        try
        {
            return long.Parse(val);
        }
        catch
        {
            return 0;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static ulong ToULong(this string val)
    {
        if (val == null) return 0;
        try
        {
            return ulong.Parse(val);
        }
        catch
        {
            return 0;
        }
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static bool IsPostalCode(this string val) => val.Length == 5 && val.ToInt() != 0;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static decimal ToDecimal(this string val)
    {
        try { return decimal.Parse(val); }
        catch { return 0; }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static Tuple<string, string, string> ToLocalities(this string val)
    {
        // Houston, TX 77080
        var city = val.Substring(0, val.IndexOf(','));
        var stateProvince = val.Substring(val.Length - 8, 2);
        var postalCode = val.Substring(val.Length - 5, 5);

        return new Tuple<string, string, string>(city, stateProvince, postalCode);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static string ToPhone(this string val)
    {
        return val.Replace("(", string.Empty)
            .Replace(")", string.Empty)
            .Replace("-", string.Empty)
            .Replace(" ", string.Empty);
    }
}
