﻿using Newtonsoft.Json;

namespace RaoTorrent.Core.Extensions;

public static class ObjectExtensions
{


    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static bool ToBool(this object val) => val.ToString().ToBool();

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static long ToLong(this object val) => val == null ? 0 : val.ToString().ToLong();

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static int ToInt(this object val) => val.ToString().ToInt();

    /// <summary>
    /// 
    /// </summary>
    /// <param name="val"></param>
    /// <returns></returns>
    public static short ToShort(this object val) => val.ToString().ToShort();

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TSrc"></typeparam>
    /// <typeparam name="TDes"></typeparam>
    /// <param name="srcObj"></param>
    /// <param name="desObj"></param>
    /// <param name="keyNames"></param>
    /// <returns></returns>
    public static bool IsPKEqual<TSrc, TDes>(this TSrc srcObj, TDes desObj, List<string> keyNames)
    {

        if (srcObj == null && desObj == null) return true;
        if (srcObj == null || desObj == null) return false;

        var srcProps = srcObj.GetType().GetProperties();
        var desProps = desObj.GetType()
            .GetProperties()
            .Where(x => keyNames.Contains(x.Name))
            .ToList();


        foreach (var desProp in desProps)
        {
            var srcProp = srcProps.First(x => x.Name == desProp.Name);
            var srcVal = srcProp.GetValue(srcObj, null);
            var desVal = desProp.GetValue(desObj, null);

            if (srcVal == null && desVal == null) continue;
            if (srcVal == null || desVal == null || srcVal.ToString() != desVal.ToString()) return false;

        }


        return true;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TFrom"></typeparam>
    /// <typeparam name="TTo"></typeparam>
    /// <param name="toObj"></param>
    /// <param name="fromObj"></param>
    public static bool IsDirty<TFrom, TTo>(this TTo toObj, TFrom fromObj)
    {

        if (fromObj == null || toObj == null) return false;

        var fromProps = fromObj.GetType().GetProperties();
        var toProps = toObj.GetType().GetProperties();

        foreach (var fromProp in fromProps)
        {

            var toProp = toProps.FirstOrDefault(x => x.Name == fromProp.Name);
            if (toProp == null) continue;

            var fromVal = fromProp.GetValue(fromObj, null);
            var toVal = toProp.GetValue(toObj, null);

            if (fromVal == null && toVal == null) continue;
            if (fromVal == null) return true;
            if (toVal == null) return true;
            if (fromVal.ToString() != toVal.ToString()) return true;
        }

        return false;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TFrom"></typeparam>
    /// <typeparam name="TTo"></typeparam>
    /// <param name="toObj"></param>
    /// <param name="fromObj"></param>
    public static void CopyFrom<TFrom, TTo>(this TTo toObj, TFrom fromObj)
    {

        if (fromObj == null || toObj == null) return;

        var fromProps = fromObj.GetType().GetProperties();
        var toProps = toObj.GetType().GetProperties();

        foreach (var fromProp in fromProps)
        {
            var val = fromProp.GetValue(fromObj, null);
            var toProp = toProps.FirstOrDefault(x => x.Name == fromProp.Name);
            if (toProp == null) continue;
            toProp.SetValue(toObj, val, null);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TFrom"></typeparam>
    /// <typeparam name="TTo"></typeparam>
    /// <param name="obj"></param>
    /// <returns></returns>
    public static TTo MapTo<TFrom, TTo>(this TFrom obj)
    {
        var json = JsonConvert.SerializeObject(obj);
        var result = JsonConvert.DeserializeObject<TTo>(json);
        return result;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TFrom"></typeparam>
    /// <typeparam name="TTo"></typeparam>
    /// <param name="obj"></param>
    /// <returns></returns>
    public static List<TTo> MapTo<TFrom, TTo>(this List<TFrom> obj)
    {
        var json = JsonConvert.SerializeObject(obj);
        var result = JsonConvert.DeserializeObject<List<TTo>>(json);
        return result;
    }
}
