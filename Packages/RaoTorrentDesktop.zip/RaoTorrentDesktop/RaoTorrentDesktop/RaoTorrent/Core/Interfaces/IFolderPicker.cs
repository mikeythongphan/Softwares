﻿namespace RaoTorrent.Core.Interfaces
{
    public interface IFolderPicker
    {
        Task<string> PickFolder();
    }
}
