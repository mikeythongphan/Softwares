﻿namespace RaoTorrent.Core.Interfaces
{
    public interface IWorkingView
    {
        string StatusMessage { get; set; }
    }
}
