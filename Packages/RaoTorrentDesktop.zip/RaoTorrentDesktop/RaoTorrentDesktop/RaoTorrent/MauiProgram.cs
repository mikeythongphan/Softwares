﻿using CommunityToolkit.Maui;
using Microsoft.Extensions.Logging;
using RaoTorrent.Core.Interfaces;
using System.Diagnostics;

namespace RaoTorrent;

public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
            .UseMauiCommunityToolkitMediaElement()
            .ConfigureFonts(fonts =>
			{
                //OpenSans
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                //FontAwesome
                fonts.AddFont("FontAwesome-Brands.otf", "FontAwesomeBrands");
                fonts.AddFont("FontAwesome-Regular.otf", "FontAwesomeRegular");
                fonts.AddFont("FontAwesome-Solid.otf", "FontAwesomeSolid");
                // Others
                fonts.AddFont("CalibrilLight.ttf", "Calibril");
                fonts.AddFont("BrandsRegular400.otf", "BrandsRegular");
                fonts.AddFont("FreeRegular400.otf", "FreeRegular");
                fonts.AddFont("FreeSolid900.otf", "FreeSolid");
            });

        AppDomain.CurrentDomain.UnhandledException += (sender, error) =>
        {
            Debug.WriteLine(error);
        };

#if DEBUG
        builder.Logging.AddDebug();
#endif
#if WINDOWS
		builder.Services.AddTransient<IFolderPicker, Platforms.Windows.FolderPicker>();
#elif MACCATALYST
		builder.Services.AddTransient<IFolderPicker, Platforms.MacCatalyst.FolderPicker>();
#endif
        builder.Services.AddTransient<MainPage>();
        builder.Services.AddTransient<App>();
        return builder.Build();
	}
}

