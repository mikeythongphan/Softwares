﻿namespace RaoTorrentService.Domain.Models
{
    public class DeviceModel
    {
        public string? DeviceName { get;set; }
    }
}
