using Microsoft.AspNetCore.Mvc;
using RaoTorrentService.Domain.Models;

namespace RaoTorrentService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AndroidDeviceController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Droid Device 01", "Droid Device 02", "Droid Device 02"
        };

        /// <summary>
        /// 
        /// </summary>
        public AndroidDeviceController()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetDevices")]
        public IEnumerable<DeviceModel> GetDevices()
        {
            return Enumerable.Range(1, 3).Select(index => new DeviceModel
            {
                DeviceName = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }
    }
}