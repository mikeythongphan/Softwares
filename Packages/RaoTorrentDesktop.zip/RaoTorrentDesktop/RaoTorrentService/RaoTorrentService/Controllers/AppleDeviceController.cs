using Microsoft.AspNetCore.Mvc;
using RaoTorrentService.Domain.Models;

namespace RaoTorrentService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AppleDeviceController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Apple Device 01", "Apple Device 02", "Apple Device 02"
        };

        /// <summary>
        /// 
        /// </summary>
        public AppleDeviceController()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetDevices")]
        public IEnumerable<DeviceModel> GetDevices()
        {
            return Enumerable.Range(1, 3).Select(index => new DeviceModel
            {
                DeviceName = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }
    }
}