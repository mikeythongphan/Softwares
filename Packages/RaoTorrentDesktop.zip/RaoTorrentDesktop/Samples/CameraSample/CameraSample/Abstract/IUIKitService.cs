﻿using System;
namespace CameraSample.Abstract
{
	public interface IUIKitService
	{
		void SaveImage(Stream fs);
	}
}

