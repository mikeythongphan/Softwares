﻿namespace CameraSample;
using CameraSample.Abstract;

public partial class MainPage : ContentPage
{
    private IUIKitService UIKitService { get; set; }

    public MainPage()
    {
        InitializeComponent();
        UIKitService = ServiceProvider.GetService<IUIKitService>();

    }

    private void cameraView_CamerasLoaded(object sender, EventArgs e)
    {
        cameraView.Camera = cameraView.Cameras.First();

        MainThread.BeginInvokeOnMainThread(async () =>
        {
            await cameraView.StopCameraAsync();
            await cameraView.StartCameraAsync();
        });
    }

    private async void Button_Clicked(object sender, EventArgs e)
    {
        var fs = await cameraView.TakePhotoAsync(Camera.MAUI.ImageFormat.JPEG);
        myImage.Source = ImageSource.FromStream(() => fs);
        UIKitService.SaveImage(fs);

        //var img = new UIKit.UIImage(cameraView.GetSnapShot(Camera.MAUI.ImageFormat.PNG));
    }

}

