﻿using System;
using System.IO;
using CameraSample.Abstract;
using Foundation;
using UIKit;

namespace CameraSample.Platforms.iOS
{
	public class UIKitService : IUIKitService
	{
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fs"></param>
        public void SaveImage(Stream fs)
        {
            var imageData = NSData.FromStream(fs);
            var image = UIImage.LoadFromData(imageData);
            image.SaveToPhotosAlbum((img, err) =>
            {

            });
        }
    }
}

