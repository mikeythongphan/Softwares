﻿using Camera.MAUI;
using Microsoft.Extensions.Logging;
using CameraSample.Abstract;

namespace CameraSample;

public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
			.UseMauiCameraView()
			.ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
				fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
			});

#if DEBUG
		builder.Logging.AddDebug();
#endif

#if IOS
		builder.Services.AddTransient<IUIKitService, CameraSample.Platforms.iOS.UIKitService>();
#endif

        return builder.Build();
	}
}
