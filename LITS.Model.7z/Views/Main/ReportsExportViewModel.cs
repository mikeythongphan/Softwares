﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.ReportsExport;
using LITS.Model.Views.Management;

namespace LITS.Model.Views.Main
{
    public class ReportsExportViewModel
    {
        public ReportsExportMasterViewModel _ReportsExportMasterViewModel { get; set; }
        public List<ReportsExportDetailViewModel> _ReportsExportDetailViewModel { get; set; }
        public List<ReportsExportTreeViewModel> _ReportsExportTreeViewModel { get; set; }

        public List<StatusViewModel> _StatusViewModel { get; set; }
        public List<TypeViewModel> _TypeViewModel { get; set; }
    }
}
