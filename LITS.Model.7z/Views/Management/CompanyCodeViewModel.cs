﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Views.Management
{
    public class CompanyCodeViewModel
    {
        public bool IsActive { get; set; }
        public bool IsVisible_IsActive { get; set; }
        public bool IsDisable_IsActive { get; set; }

        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }

        public string Name { get; set; }
        public bool IsVisibleName { get; set; }
        public bool IsDisableName { get; set; }

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsDisableDescription { get; set; }

        public int TypeID { get; set; }
        public string Type { get; set; }
        public bool IsVisibleTypeID { get; set; }
        public bool IsDisableTypeID { get; set; }

        public int StatusID { get; set; }
        public string Status { get; set; }
        public bool IsVisibleStatusID { get; set; }
        public bool IsDisableStatusID { get; set; }

        public Nullable<DateTime> CreateDate { get; set; }
        public bool IsVisibleCreateDate { get; set; }
        public bool IsDisableCreateDate { get; set; }

        public string CreateBy { get; set; }
        public bool IsVisibleCreateBy { get; set; }
        public bool IsDisableCreateBy { get; set; }

        public string CompanyCode { get; set; }
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsDisableCompanyCode { get; set; }

        public string CompanyAddress { get; set; }
        public bool IsVisibleCompanyAddress { get; set; }
        public bool IsDisableCompanyAddress { get; set; }

        public string CompanyWard { get; set; }
        public bool IsVisibleCompanyWard { get; set; }
        public bool IsDisableCompanyWard { get; set; }

        public int CompanyDistrictID { get; set; }
        public string CompanyDistrict { get; set; }
        public bool IsVisibleCompanyDistrictID { get; set; }
        public bool IsDisableCompanyDistrictID { get; set; }

        public int CompanyCityID { get; set; }
        public string CompanyCity { get; set; }
        public bool IsVisibleCompanyCityID { get; set; }
        public bool IsDisableCompanyCityID { get; set; }

        public string CompanyPhone { get; set; }
        public bool IsVisibleCompanyPhone { get; set; }
        public bool IsDisableCompanyPhone { get; set; }

        public string CompanyFax { get; set; }
        public bool IsVisibleCompanyFax { get; set; }
        public bool IsDisableCompanyFax { get; set; }

        public string CompanyNameVN { get; set; }
        public bool IsVisibleCompanyNameVN { get; set; }
        public bool IsDisableCompanyNameVN { get; set; }

        public int CompanyTypeID { get; set; }
        public string CompanyType { get; set; }
        public bool IsVisiblefk_m_company_type_id { get; set; }
        public bool IsDisablefk_m_company_type_id { get; set; }

        public string CompanyCat { get; set; }
        public bool IsVisibleCompanyCat { get; set; }
        public bool IsDisableCompanyCat { get; set; }

        public string TaxCode { get; set; }
        public bool IsVisibleTaxCode { get; set; }
        public bool IsDisableTaxCode { get; set; }

        public string BusinessLicense { get; set; }
        public bool IsVisibleBusinessLicense { get; set; }
        public bool IsDisableBusinessLicense { get; set; }

        public Nullable<DateTime> Note { get; set; }
        public bool IsVisibleNote { get; set; }
        public bool IsDisableNote { get; set; }

        public Nullable<DateTime> ProcessedDate { get; set; }
        public bool IsVisibleProcessedDate { get; set; }
        public bool IsDisableProcessedDate { get; set; }

        public string ProcessedBy { get; set; }
        public bool IsVisibleProcessedBy { get; set; }
        public bool IsDisableProcessedBy { get; set; }

        public bool IsPromotion { get; set; }
        public bool IsVisibleIsPromotion { get; set; }
        public bool IsDisableIsPromotion { get; set; }

        public decimal RateOffer { get; set; }
        public bool IsVisibleRateOffer { get; set; }
        public bool IsDisableRateOffer{ get; set; }

        public Nullable<DateTime> EffectiveFromDate { get; set; }
        public bool IsVisibleEffectiveFromDate { get; set; }
        public bool IsDisableEffectiveFromDate { get; set; }

        public Nullable<DateTime> EffectiveToDate { get; set; }
        public bool IsVisibleEffectiveToDate { get; set; }
        public bool IsDisableEffectiveToDate { get; set; }

        public string Remarks { get; set; }
        public bool IsVisibleRemarks { get; set; }
        public bool IsDisableRemarks { get; set; }

        public int ReasonCompanyID { get; set; }
        public string ReasonCompany { get; set; }
        public bool IsVisibleReasonCompanyID { get; set; }
        public bool IsDisableReasonCompanyID { get; set; }

        public string CompanyShortName { get; set; }
        public bool IsVisibleCompanyShortName { get; set; }
        public bool IsDisableCompanyShortName { get; set; }

        public string BusinessRegistrationNumber { get; set; }
        public bool IsVisibleBusinessRegistrationNumber { get; set; }
        public bool IsDisableBusinessRegistrationNumber { get; set; }

        public Nullable<DateTime> DateOfIncorporate { get; set; }
        public bool IsVisibleDateOfIncorporate { get; set; }
        public bool IsDisableDateOfIncorporate { get; set; }

        public string LatestDateUpdateOnBusinessLicense { get; set; }
        public bool IsVisibleLatestDateUpdateOnBusinessLicense { get; set; }
        public bool IsDisableLatestDateUpdateOnBusinessLicense { get; set; }

        public int NumberofChange { get; set; }
        public bool IsVisibleNumberofChange { get; set; }
        public bool IsDisableNumberofChange { get; set; }

        public int BusinessNatureID { get; set; }
        public string BusinessNature { get; set; }
        public bool IsVisibleBusinessNatureID { get; set; }
        public bool IsDisableBusinessNatureID { get; set; }

        public int CustomerRelationshipID { get; set; }
        public string CustomerRelationship { get; set; }
        public bool IsVisibleCustomerRelationshipID { get; set; }
        public bool IsDisableCustomerRelationshipID { get; set; }

        public int IndustryID { get; set; }
        public string Industry { get; set; }
        public bool IsVisibleIndustryID { get; set; }
        public bool IsDisableIndustryID { get; set; }

        public int TotalMonthsInOperation { get; set; }
        public bool IsVisibleTotalMonthsInOperation { get; set; }
        public bool IsDisableTotalMonthsInOperation { get; set; }

        public decimal RegisteredCapital { get; set; }
        public bool IsVisibleRegisteredCapital { get; set; }
        public bool IsDisableRegisteredCapital { get; set; }

        public int NumberOfBanksUsage { get; set; }
        public bool IsVisibleNumberOfBanksUsage { get; set; }
        public bool IsDisableNumberOfBanksUsage { get; set; }

        public string BillingAddress { get; set; }
        public bool IsVisibleBillingAddress { get; set; }
        public bool IsDisableBillingAddress { get; set; }

        public string TaxNumber { get; set; }
        public bool IsVisibleTaxNumber { get; set; }
        public bool IsDisableTaxNumber { get; set; }
    }
}
