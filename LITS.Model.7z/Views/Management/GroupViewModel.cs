﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Views.Management
{
    public class GroupViewModel
    {       
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsEnabledID { get; set; }

        public int? ParentID { get; set; }
        public bool IsVisibleParentID { get; set; }
        public bool IsEnabledParentID { get; set; }

        public string Name { get; set; }
        public bool IsVisibleName { get; set; }
        public bool IsEnabledName { get; set; }

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsEnabledDescription { get; set; }        

        public Nullable<DateTime> CreateDate { get; set; }
        public bool IsVisibleCreateDate { get; set; }
        public bool IsEnabledCreateDate { get; set; }

        public string CreateBy { get; set; }
        public bool IsVisibleCreateBy { get; set; }
        public bool IsEnabledCreateBy { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisible_IsActive { get; set; }
        public bool IsEnabled_IsActive { get; set; }
    }
}
