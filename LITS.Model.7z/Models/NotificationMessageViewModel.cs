﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Models
{
    public class NotificationMessageViewModel
    {
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }

        public string Code { get; set; }
        public bool IsVisibleCode { get; set; }
        public bool IsDisableCode { get; set; }

        public string Title { get; set; }
        public bool IsVisibleTitle { get; set; }
        public bool IsDisableTitle { get; set; }

        public string Body { get; set; }
        public bool IsVisibleBody { get; set; }
        public bool IsDisableBody { get; set; }

        public string Icon { get; set; }
        public bool IsVisibleIcon { get; set; }
        public bool IsDisableIcon { get; set; }

        public string Image { get; set; }
        public bool IsVisibleImage { get; set; }
        public bool IsDisableImage { get; set; }

        public TimeSpan Timestamp { get; set; }
        public bool IsVisibleTimestamp { get; set; }
        public bool IsDisableTimestamp { get; set; }
        
    }
}
