﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace LITS.Model.Domain.Main
{
    public class CustomerIdentificationViewModel
    {
        public int ID { get; set; }

        public int ApplicationInformationID { get; set; }

        public int CustomerInformationID { get; set; }

        public int? ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public int? StatusID { get; set; }
        public string Status { get; set; }
        public bool IsVisibleStatus { get; set; }
        public bool IsDisableStatus { get; set; }

        public string IdentificationNo { get; set; }
        public bool IsVisibleIdentificationNo { get; set; }
        public bool IsDisableIdentificationNo { get; set; }

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsDisableDescription { get; set; }

        public int? IdentificationTypeID { get; set; }
        public string IdentificationType { get; set; }
        public bool IsVisibleIdentificationType { get; set; }
        public bool IsDisableIdentificationType { get; set; }

        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
}
