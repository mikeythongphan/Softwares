﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Domain.AutoLoan
{
    public class CarDealerViewModel
    {
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }

        public string CarDealerName { get; set; }
        public bool IsVisibleCarDealerName { get; set; }
        public bool IsDisableCarDealerName { get; set; }

        public string CarDealerAddress { get; set; }
        public bool IsVisibleCarDealerAddress { get; set; }
        public bool IsDisableCarDealerAddress { get; set; }

        public string CarDealerWards { get; set; }
        public bool IsVisibleCarDealerWards { get; set; }
        public bool IsDisableCarDealerWards { get; set; }

        public int? CarDealerDistrictID { get; set; }
        public string CarDealerDistrict { get; set; }
        public bool IsVisibleCarDealerDistrict { get; set; }
        public bool IsDisableCarDealerDistrict { get; set; }

        public int? CarDealerCityID { get; set; }
        public string CarDealerCity { get; set; }
        public bool IsVisibleCarDealerCity { get; set; }
        public bool IsDisableCarDealerCity { get; set; }

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsDisableDescription { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisibleIsActive { get; set; }
        public bool IsDisableIsActive { get; set; }

        public int TypeID { get; set; }
        public string Type { get; set; }
        public bool IsVisibleTypeID { get; set; }
        public bool IsDisableTypeID { get; set; }

        public int StatusID { get; set; }
        public string Status { get; set; }
        public bool IsVisibleStatusID { get; set; }
        public bool IsDisableStatusID { get; set; }

        public Nullable<DateTime> CreateDate { get; set; }
        public bool IsVisibleCreateDate { get; set; }
        public bool IsDisableCreateDate { get; set; }

        public string CreateBy { get; set; }
        public bool IsVisibleCreateBy { get; set; }
        public bool IsDisableCreateBy { get; set; }
    }
}
