﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Domain.AutoLoan
{
    public class CarTypeViewModel
    {
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsEnabledID { get; set; }

        public string Name { get; set; }
        public bool IsVisibleName { get; set; }
        public bool IsEnabledName { get; set; }        

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsEnabledDescription { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisibleIsActive { get; set; }
        public bool IsEnabledIsActive { get; set; }

        public int TypeID { get; set; }
        public string Type { get; set; }
        public bool IsVisibleTypeID { get; set; }
        public bool IsEnabledTypeID { get; set; }

        public int StatusID { get; set; }
        public string Status { get; set; }
        public bool IsVisibleStatusID { get; set; }
        public bool IsEnabledStatusID { get; set; }

        public Nullable<DateTime> CreateDate { get; set; }
        public bool IsVisibleCreateDate { get; set; }
        public bool IsEnabledCreateDate { get; set; }

        public string CreateBy { get; set; }
        public bool IsVisibleCreateBy { get; set; }
        public bool IsEnabledCreateBy { get; set; }
    }
}
