﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using LITS.Infrastructure.Context;

namespace LITS.Model.Mappers
{
    public class ViewModelToModelProfile : Profile
    {
        public ViewModelToModelProfile()
        {
            #region Main

            #region SalesCoordinators
            CreateMap<PartialViews.Main.SalesCoordinators.ApplicationInformationViewModel, application_information>()
            .ForMember(dest => dest.arm_code, opts => opts.MapFrom(src => src.ArmCode))
            .ForMember(dest => dest.received_date, opts => opts.MapFrom(src => src.ReceivedDate))
            .ForMember(dest => dest.sale_staff_bank_id, opts => opts.MapFrom(src => src.SaleStaffBankID))
            .ForMember(dest => dest.sale_staff_name, opts => opts.MapFrom(src => src.SaleStaffName));

            CreateMap<PartialViews.Main.SalesCoordinators.CustomerInformationViewModel, customer_information>();
            #endregion

            #region WorkInProgress
            CreateMap<m_type, PartialViews.Main.WorkInProgress.WorkInProgressTreeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            ;

            CreateMap<customer_information, PartialViews.Main.WorkInProgress.WorkInProgressMasterCustomerViewModel>()
            .ForMember(dest => dest.CustomerID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.CustomerName, opts => opts.MapFrom(src => src.full_name))
            .ForMember(dest => dest.CustomerIdentification, opt =>
            {
                opt.UseDestinationValue();
                opt.Ignore();
            })
            ;

            CreateMap<customer_identification, PartialViews.Main.WorkInProgress.WorkInProgressMasterCustomerViewModel>()
            .ForMember(dest => dest.CustomerID, opts => opts.MapFrom(src => src.fk_customer_information_id))
            .ForMember(dest => dest.CustomerIdentification, opts => opts.MapFrom(src => src.identification_no))
            .ForMember(dest => dest.CustomerName, opt =>
            {
                opt.UseDestinationValue();
                opt.Ignore();
            })
            ;

            CreateMap<m_company_code, PartialViews.Main.WorkInProgress.WorkInProgressMasterCompanyViewModel>()
            .ForMember(dest => dest.CompanyID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.CompanyCode, opts => opts.MapFrom(src => src.company_code))
            .ForMember(dest => dest.CompanyName, opts => opts.MapFrom(src => src.name))
            ;
            #endregion

            #region CreateNewLoan
            CreateMap<m_type, PartialViews.Main.CreateNewLoan.CreateNewLoanStep1TreeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            ;
            #endregion

            #endregion

            #region Management
            CreateMap<m_bank_holiday, Model.Views.Management.BankHolidayViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
             .ForMember(dest => dest.BankHoliday, opts => opts.MapFrom(src => src.bank_holiday))
             .ForMember(dest => dest.DescriptionBankHoliday, opts => opts.MapFrom(src => src.description))
             .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
             .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
             .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
             .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
             .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_bank_type, Model.Views.Management.BankTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_branch_code, Model.Views.Management.BranchCodeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_branch_location, Model.Views.Management.BranchLocationViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_business_nature, Model.Views.Management.BusinessNatureViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_business_type, Model.Views.Management.BusinessTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_campaign_code, Model.Views.Management.CampaignCodeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_bank_type, Model.Views.Management.BankTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_cdd, Model.Views.Management.CDDViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_cic, Model.Views.Management.CicViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_city, Model.Views.Management.CityViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_commision_type, Model.Views.Management.CommisionTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_company_code, Model.Views.Management.CompanyCodeViewModel>()
           .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_company_type, Model.Views.Management.CompanyTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_credit_bureau_type, Model.Views.Management.CreditBureauTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_credit_deviation, Model.Views.Management.CreditDeviationViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_criteria, Model.Views.Management.CriteriaViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_current_resident_type, Model.Views.Management.CurrentResidentTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_custody_type, Model.Views.Management.CustodyTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_customer_relationship, Model.Views.Management.CustomerRelationshipViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_customer_segment, Model.Views.Management.CustomerSegmentViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_customer_type, Model.Views.Management.CustomerTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_deviation_code, Model.Views.Management.DeviationCodeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_district, Model.Views.Management.DistrictViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_duplication_type, Model.Views.Management.DuplicationTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_education, Model.Views.Management.EducationViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_employment_type, Model.Views.Management.EmploymentTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_floating_interest_rate, Model.Views.Management.FloatingInterestRateViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_income_type, Model.Views.Management.IncomeTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_industry, Model.Views.Management.IndustryViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_interest_classification, Model.Views.Management.InterestClassificationViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_investigave_type, Model.Views.Management.InvestigaveTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_labour_contract_type, Model.Views.Management.LabourContractTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_loan_purpose, Model.Views.Management.LoanPurposeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_loan_tenor, Model.Views.Management.LoanTenorViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Value, opts => opts.MapFrom(src => src.value))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_loan_trend, Model.Views.Management.LoanTrendViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_loan_type, Model.Views.Management.LoanTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_marital_status, Model.Views.Management.MaritalStatusViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_nationality, Model.Views.Management.NationalityViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_bank_type, Model.Views.Management.BankTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_occupation, Model.Views.Management.OccupationViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_ownership_type, Model.Views.Management.OwnershipTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_bank_type, Model.Views.Management.BankTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));


            CreateMap<m_payment_type, Model.Views.Management.PaymentTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_position, Model.Views.Management.PositionViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_product, Model.Views.Management.ProductViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_program_code, Model.Views.Management.ProgramCodeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_program_type, Model.Views.Management.ProgramTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_property_sale, Model.Views.Management.PropertySaleViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_property_status, Model.Views.Management.PropertyStatusViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_bank_type, Model.Views.Management.BankTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_property_type, Model.Views.Management.PropertyTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_reason, Model.Views.Management.ReasonViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_residence_ownership, Model.Views.Management.ResidenceOwnershipViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_sales_channel, Model.Views.Management.SalesChannelViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_status, Model.Views.Management.StatusViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_product_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_trading_area, Model.Views.Management.TradingAreaViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by));

            CreateMap<m_type, Model.Views.Management.TypeViewModel>()
           .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_m_group_id))
            ;

            CreateMap<m_definition_type, Model.Views.Management.DefinitionTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.Code, opts => opts.MapFrom(src => src.code))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.UpdatedDate, opts => opts.MapFrom(src => src.updated_date))
            .ForMember(dest => dest.UpdatedBy, opts => opts.MapFrom(src => src.updated_by))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            .ForMember(dest => dest.ValidFromDate, opts => opts.MapFrom(src => src.valid_from_date))
            .ForMember(dest => dest.ValidToDate, opts => opts.MapFrom(src => src.valid_to_date))
            ;
            #endregion

            #region Auto Loan

            #region PartialViews

            #region SalesCoordinators
            CreateMap<PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel, application_information>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ApplicationInformationID))
            .ForMember(dest => dest.application_no, opts => opts.MapFrom(src => src.ApplicationNo))
            .ForMember(dest => dest.received_date, opts => opts.MapFrom(src => src.ReceivingDate))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy))
            .ForMember(dest => dest.arm_code, opts => opts.MapFrom(src => src.ARMCode))
            .ForMember(dest => dest.sales_code, opts => opts.MapFrom(src => src.SalesCode))
            .ForMember(dest => dest.eops_txn_ref_no_1, opts => opts.MapFrom(src => src.EOpsTxnReference))
            .ForMember(dest => dest.expecting_disbursed_date, opts => opts.MapFrom(src => src.ExpectingDisbursedDate))
            .ForMember(dest => dest.hard_copy_app_date, opts => opts.MapFrom(src => src.HardCopyApplicationDate))
            .ForMember(dest => dest.ict, opts => opts.MapFrom(src => src.ICT))
            .ForMember(dest => dest.sale_staff_bank_id, opts => opts.MapFrom(src => src.PeoplewiseIDofSaleStaf))
            .ForMember(dest => dest.fk_m_type_id, opts => opts.MapFrom(src => src.ApplicationTypeID))
            .ForMember(dest => dest.fk_m_status_id, opts => opts.MapFrom(src => src.ApplicationStatusID))
            .ForMember(dest => dest.fk_m_branch_code_id, opts => opts.MapFrom(src => src.BranchCodeID))
            .ForMember(dest => dest.fk_m_branch_location_id, opts => opts.MapFrom(src => src.BranchLocationID))
            .ForMember(dest => dest.fk_m_customer_type_id, opts => opts.MapFrom(src => src.CustomerTypeID))
            .ForMember(dest => dest.fk_m_product_id, opts => opts.MapFrom(src => src.ProductTypeID))
            .ForMember(dest => dest.fk_m_program_type_id, opts => opts.MapFrom(src => src.ProgramTypeID))
            .ForMember(dest => dest.fk_m_customer_type_id, opts => opts.MapFrom(src => src.CustomerSegmentID))
            .ForMember(dest => dest.fk_m_trading_area_id, opts => opts.MapFrom(src => src.TradingAreaID))
            .ForMember(dest => dest.fk_m_reason_rework_id, opts => opts.MapFrom(src => src.ReasonForReworkID))
            .ForMember(dest => dest.fk_m_customer_segment_id, opts => opts.MapFrom(src => src.CustomerSegmentID))
            .ForMember(dest => dest.fk_m_cdd_id, opts => opts.MapFrom(src => src.CDDID))
            .ForMember(dest => dest.fk_m_sales_channel_id, opts => opts.MapFrom(src => src.ChannelID))
            .ForMember(dest => dest.is_staff, opts => opts.MapFrom(src => src.IsStafNonStaf))
            .ForMember(dest => dest.is_rework, opts => opts.MapFrom(src => src.IsRework))
            .ForMember(dest => dest.is_black_list, opts => opts.MapFrom(src => src.IsBlackList))
            .ForMember(dest => dest.is_existing, opts => opts.MapFrom(src => src.IsExisting))
            ;
            #endregion

            #endregion

            #endregion
        }
    }
}
