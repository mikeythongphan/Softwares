﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.LendingOperation
{
    public class DisbursementInformationViewModel
    {
        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }

        public Nullable<System.DateTime> DisbursedDate { get; set; }
        public bool IsVisibleDisbursedDate { get; set; }
        public bool IsEnabledDisbursedDate { get; set; }

        public string DisbursalStatus { get; set; }
        public int? DisbursalStatusID { get; set; }
        public bool IsVisibleDisbursalStatus { get; set; }
        public bool IsEnabledDisbursalStatus { get; set; }

        public decimal? DisbursedAmount { get; set; }
        public bool IsVisibleDisbursedAmount { get; set; }
        public bool IsEnabledDisbursedAmount { get; set; }

        public string LoanAccountNumber { get; set; }
        public bool IsVisibleLoanAccountNumber { get; set; }
        public bool IsEnabledLoanAccountNumber { get; set; }

        public int? CustomerRelationshipID { get; set; }
        public string CustomerRelationship { get; set; }
        public bool IsVisibleCustomerRelationship { get; set; }
        public bool IsEnabledCustomerRelationship { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsEnabledApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsEnabledApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
