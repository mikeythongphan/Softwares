﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.LendingOperation
{
    public class DisbursementViewModel
    {
        public int ApplicationInformationID { get; set; }

        public int ALApplicationInformationID { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsEnabledApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsEnabledApplicationStatus { get; set; }

        public string ApllicationNo { get; set; }
        public bool IsVisibleApllicationNo { get; set; }
        public bool IsEnabledApllicationNo { get; set; }

        public int? ChannelID { get; set; }
        public string Channel { get; set; }
        public bool IsVisibleChannel { get; set; }
        public bool IsEnabledChannel { get; set; }

        public Nullable<System.DateTime> ExpectingDisbursedDate { get; set; }
        public bool IsVisibleExpectingDisbursedDate { get; set; }
        public bool IsEnabledExpectingDisbursedDate { get; set; }

        public Nullable<System.DateTime> RecevingDate { get; set; }
        public bool IsVisibleRecevingDate { get; set; }
        public bool IsEnabledRecevingDate { get; set; }

        public int? CustomerSegmentID { get; set; }
        public string CustomerSegment { get; set; }
        public bool IsVisibleCustomerSegment { get; set; }
        public bool IsEnabledCustomerSegment { get; set; }

        public string ARMCode { get; set; }
        public bool IsVisibleARMCode { get; set; }
        public bool IsEnabledARMCode { get; set; }

        public int? ProgramCodeID { get; set; }
        public string ProgramCode { get; set; }
        public bool IsVisibleProgramCode { get; set; }
        public bool IsEnabledProgramCode { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
