﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.LendingOperation
{
    public class PropertyInformationViewModel
    {
        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }

        public string PlateFormNumber { get; set; }
        public bool IsVisiblePlateFormNumber { get; set; }
        public bool IsEnabledPlateFormNumber { get; set; }

        public string EngineNumber { get; set; }
        public bool IsVisibleEngineNumber { get; set; }
        public bool IsEnabledEngineNumber { get; set; }

        public string ChassisNumber { get; set; }
        public bool IsVisibleChassisNumber { get; set; }
        public bool IsEnabledChassisNumber { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsEnabledApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsEnabledApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
