﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.AutoLoan;

namespace LITS.Model.PartialViews.AutoLoan.OperationSupport
{
    public class CustomerIncomeViewModel
    {
        #region Application ID
        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }
        #endregion

        #region Main

        #region SalariedClient

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Main_Income_1 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Main_Income_1
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Main_Income_1;
            }
            set { _objSalariedClientIncomeViewModel_Main_Income_1 = value; }
        }

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Main_Income_2 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Main_Income_2
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Main_Income_2;
            }
            set { _objSalariedClientIncomeViewModel_Main_Income_2 = value; }
        }

        public decimal? TotalSalariedIncome_Main { get; set; }
        public bool IsVisibleTotalSalariedIncome_Main { get; set; }
        public bool IsEnabledTotalSalariedIncome_Main { get; set; }
        #endregion

        #region Rental

        #region House Rental
        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_1 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_1
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_1;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_1 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_2 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_2
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_2;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_2 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_3 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_3
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_3;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_3 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_4 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_4
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_4;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_4 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_5 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_5
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_5;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_5 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_6 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_6
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_6;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_6 = value; }
        }

        public decimal? TotalHouseRentalIncome_Main { get; set; }
        public bool IsVisibleTotalHouseRentalIncome_Main { get; set; }
        public bool IsEnabledTotalHouseRentalIncome_Main { get; set; }
        #endregion

        #region Car Rental
        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_1 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_1
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_1;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_1 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_2 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_2
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_2;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_2 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_3 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_3
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_3;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_3 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_4 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_4
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_4;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_4 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_5 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_5
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_5;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_5 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_6 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_6
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_6;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_6 = value; }
        }

        public decimal? TotalCarRentalIncome_Main { get; set; }
        public bool IsVisibleTotalCarRentalIncome_Main { get; set; }
        public bool IsEnabledTotalCarRentalIncome_Main { get; set; }
        #endregion

        public decimal? TotalRentalIncome_Main { get; set; }
        public bool IsVisibleTotalRentalIncome_Main { get; set; }
        public bool IsEnabledTotalRentalIncome_Main { get; set; }
        #endregion

        #region SelfEmployed
        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Main_Income_1 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Main_Income_1
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Main_Income_1;
            }
            set { _objSelfEmployedIncomeViewModel_Main_Income_1 = value; }
        }

        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Main_Income_2 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Main_Income_2
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Main_Income_2;
            }
            set { _objSelfEmployedIncomeViewModel_Main_Income_2 = value; }
        }

        public decimal? TotalSelfEmployedIncome_Main { get; set; }
        public bool IsVisibleTotalSelfEmployedIncome_Main { get; set; }
        public bool IsEnabledTotalSelfEmployedIncome_Main { get; set; }
        #endregion

        #region Other
        private OtherIncomeViewModel _objOtherIncomeViewModel_Main_Income_1 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Main_Income_1
        {
            get
            {
                return _objOtherIncomeViewModel_Main_Income_1;
            }
            set { _objOtherIncomeViewModel_Main_Income_1 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Main_Income_2 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Main_Income_2
        {
            get
            {
                return _objOtherIncomeViewModel_Main_Income_2;
            }
            set { _objOtherIncomeViewModel_Main_Income_2 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Main_Income_3 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Main_Income_3
        {
            get
            {
                return _objOtherIncomeViewModel_Main_Income_3;
            }
            set { _objOtherIncomeViewModel_Main_Income_3 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Main_Income_4 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Main_Income_4
        {
            get
            {
                return _objOtherIncomeViewModel_Main_Income_4;
            }
            set { _objOtherIncomeViewModel_Main_Income_4 = value; }
        }

        public decimal? TotalOtherIncome_Main { get; set; }
        public bool IsVisibleTotalOtherIncome_Main { get; set; }
        public bool IsEnabledTotalOtherIncome_Main { get; set; }
        #endregion

        #region Total
        public float TotalIncome_Main { get; set; }
        public bool IsVisibleTotalIncome_Main { get; set; }
        public bool IsEnabledTotalIncome_Main { get; set; }
        #endregion

        #endregion

        #region Co1

        #region SalariedClient
        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co1_Income_1 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co1_Income_1
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co1_Income_1;
            }
            set { _objSalariedClientIncomeViewModel_Co1_Income_1 = value; }
        }

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co1_Income_2 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co1_Income_2
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co1_Income_2;
            }
            set { _objSalariedClientIncomeViewModel_Co1_Income_2 = value; }
        }

        public decimal? TotalSalariedIncome_Co1 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co1 { get; set; }
        public bool IsEnabledTotalSalariedIncome_Co1 { get; set; }
        #endregion

        #region Rental

        #region House Rental
        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_1 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_1
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_1;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_1 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_2 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_2
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_2;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_2 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_3 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_3
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_3;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_3 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_4 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_4
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_4;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_4 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_5 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_5
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_5;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_5 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_6 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_6
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_6;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_6 = value; }
        }

        public decimal? TotalHouseRentalIncome_Co1 { get; set; }
        public bool IsVisibleTotalHouseRentalIncome_Co1 { get; set; }
        public bool IsEnabledTotalHouseRentalIncome_Co1 { get; set; }
        #endregion

        #region Car Rental
        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_1 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_1
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_1;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_1 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_2 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_2
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_2;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_2 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_3 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_3
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_3;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_3 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_4 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_4
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_4;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_4 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_5 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_5
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_5;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_5 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_6 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_6
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_6;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_6 = value; }
        }

        public decimal? TotalCarRentalIncome_Co1 { get; set; }
        public bool IsVisibleTotalCarRentalIncome_Co1 { get; set; }
        public bool IsEnabledTotalCarRentalIncome_Co1 { get; set; }
        #endregion

        public decimal? TotalRentalIncome_Co1 { get; set; }
        public bool IsVisibleTotalRentalIncome_Co1 { get; set; }
        public bool IsEnabledTotalRentalIncome_Co1 { get; set; }
        #endregion

        #region SelfEmployed
        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co1_Income_1 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co1_Income_1
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co1_Income_1;
            }
            set { _objSelfEmployedIncomeViewModel_Co1_Income_1 = value; }
        }

        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co1_Income_2 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co1_Income_2
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co1_Income_2;
            }
            set { _objSelfEmployedIncomeViewModel_Co1_Income_2 = value; }
        }

        public decimal? TotalSelfEmployedIncome_Co1 { get; set; }
        public bool IsVisibleTotalSelfEmployedIncome_Co1 { get; set; }
        public bool IsEnabledTotalSelfEmployedIncome_Co1 { get; set; }
        #endregion

        #region Other
        private OtherIncomeViewModel _objOtherIncomeViewModel_Co1_Income_1 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co1_Income_1
        {
            get
            {
                return _objOtherIncomeViewModel_Co1_Income_1;
            }
            set { _objOtherIncomeViewModel_Co1_Income_1 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co1_Income_2 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co1_Income_2
        {
            get
            {
                return _objOtherIncomeViewModel_Co1_Income_2;
            }
            set { _objOtherIncomeViewModel_Co1_Income_2 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co1_Income_3 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co1_Income_3
        {
            get
            {
                return _objOtherIncomeViewModel_Co1_Income_3;
            }
            set { _objOtherIncomeViewModel_Co1_Income_3 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co1_Income_4 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co1_Income_4
        {
            get
            {
                return _objOtherIncomeViewModel_Co1_Income_4;
            }
            set { _objOtherIncomeViewModel_Co1_Income_4 = value; }
        }

        public decimal? TotalOtherIncome_Co1 { get; set; }
        public bool IsVisibleTotalOtherIncome_Co1 { get; set; }
        public bool IsEnabledTotalOtherIncome_Co1 { get; set; }
        #endregion

        #region Total
        public float TotalIncome_Co1 { get; set; }
        public bool IsVisibleTotalIncome_Co1 { get; set; }
        public bool IsEnabledTotalIncome_Co1 { get; set; }
        #endregion

        #endregion

        #region Co2

        #region SalariedClient

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co2_Income_1 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co2_Income_1
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co2_Income_1;
            }
            set { _objSalariedClientIncomeViewModel_Co2_Income_1 = value; }
        }

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co2_Income_2 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co2_Income_2
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co2_Income_2;
            }
            set { _objSalariedClientIncomeViewModel_Co2_Income_2 = value; }
        }

        public decimal? TotalSalariedIncome_Co2 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co2 { get; set; }
        public bool IsEnabledTotalSalariedIncome_Co2 { get; set; }
        #endregion

        #region Rental

        #region House Rental
        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_1 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_1
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_1;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_1 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_2 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_2
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_2;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_2 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_3 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_3
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_3;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_3 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_4 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_4
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_4;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_4 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_5 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_5
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_5;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_5 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_6 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_6
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_6;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_6 = value; }
        }

        public decimal? TotalHouseRentalIncome_Co2 { get; set; }
        public bool IsVisibleTotalHouseRentalIncome_Co2 { get; set; }
        public bool IsEnabledTotalHouseRentalIncome_Co2 { get; set; }
        #endregion

        #region Car Rental
        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_1 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_1
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_1;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_1 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_2 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_2
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_2;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_2 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_3 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_3
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_3;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_3 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_4 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_4
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_4;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_4 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_5 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_5
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_5;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_5 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_6 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_6
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_6;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_6 = value; }
        }

        public decimal? TotalCarRentalIncome_Co2 { get; set; }
        public bool IsVisibleTotalCarRentalIncome_Co2 { get; set; }
        public bool IsEnabledTotalCarRentalIncome_Co2 { get; set; }
        #endregion

        public decimal? TotalRentalIncome_Co2 { get; set; }
        public bool IsVisibleTotalRentalIncome_Co2 { get; set; }
        public bool IsEnabledTotalRentalIncome_Co2 { get; set; }
        #endregion

        #region SelfEmployed
        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co2_Income_1 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co2_Income_1
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co2_Income_1;
            }
            set { _objSelfEmployedIncomeViewModel_Co2_Income_1 = value; }
        }

        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co2_Income_2 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co2_Income_2
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co2_Income_2;
            }
            set { _objSelfEmployedIncomeViewModel_Co2_Income_2 = value; }
        }

        public decimal? TotalSelfEmployedIncome_Co2 { get; set; }
        public bool IsVisibleTotalSelfEmployedIncome_Co2 { get; set; }
        public bool IsEnabledTotalSelfEmployedIncome_Co2 { get; set; }
        #endregion

        #region Other
        private OtherIncomeViewModel _objOtherIncomeViewModel_Co2_Income_1 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co2_Income_1
        {
            get
            {
                return _objOtherIncomeViewModel_Co2_Income_1;
            }
            set { _objOtherIncomeViewModel_Co2_Income_1 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co2_Income_2 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co2_Income_2
        {
            get
            {
                return _objOtherIncomeViewModel_Co2_Income_2;
            }
            set { _objOtherIncomeViewModel_Co2_Income_2 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co2_Income_3 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co2_Income_3
        {
            get
            {
                return _objOtherIncomeViewModel_Co2_Income_3;
            }
            set { _objOtherIncomeViewModel_Co2_Income_3 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co2_Income_4 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co2_Income_4
        {
            get
            {
                return _objOtherIncomeViewModel_Co2_Income_4;
            }
            set { _objOtherIncomeViewModel_Co2_Income_4 = value; }
        }

        public decimal? TotalOtherIncome_Co2 { get; set; }
        public bool IsVisibleTotalOtherIncome_Co2 { get; set; }
        public bool IsEnabledTotalOtherIncome_Co2 { get; set; }
        #endregion

        #region Total
        public float TotalIncome_Co2 { get; set; }
        public bool IsVisibleTotalIncome_Co2 { get; set; }
        public bool IsEnabledTotalIncome_Co2 { get; set; }
        #endregion

        #endregion

        #region Co3

        #region SalariedClient

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co3_Income_1 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co3_Income_1
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co3_Income_1;
            }
            set { _objSalariedClientIncomeViewModel_Co3_Income_1 = value; }
        }

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co3_Income_2 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co3_Income_2
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co3_Income_2;
            }
            set { _objSalariedClientIncomeViewModel_Co3_Income_2 = value; }
        }

        public decimal? TotalSalariedIncome_Co3 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co3 { get; set; }
        public bool IsEnabledTotalSalariedIncome_Co3 { get; set; }
        #endregion

        #region Rental

        #region House Rental
        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_1 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_1
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_1;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_1 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_2 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_2
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_2;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_2 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_3 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_3
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_3;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_3 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_4 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_4
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_4;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_4 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_5 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_5
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_5;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_5 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_6 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_6
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_6;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_6 = value; }
        }

        public decimal? TotalHouseRentalIncome_Co3 { get; set; }
        public bool IsVisibleTotalHouseRentalIncome_Co3 { get; set; }
        public bool IsEnabledTotalHouseRentalIncome_Co3 { get; set; }
        #endregion

        #region Car Rental
        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_1 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_1
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_1;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_1 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_2 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_2
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_2;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_2 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_3 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_3
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_3;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_3 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_4 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_4
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_4;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_4 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_5 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_5
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_5;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_5 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_6 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_6
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_6;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_6 = value; }
        }

        public decimal? TotalCarRentalIncome_Co3 { get; set; }
        public bool IsVisibleTotalCarRentalIncome_Co3 { get; set; }
        public bool IsEnabledTotalCarRentalIncome_Co3 { get; set; }
        #endregion

        public decimal? TotalRentalIncome_Co3 { get; set; }
        public bool IsVisibleTotalRentalIncome_Co3 { get; set; }
        public bool IsEnabledTotalRentalIncome_Co3 { get; set; }
        #endregion

        #region SelfEmployed
        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co3_Income_1 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co3_Income_1
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co3_Income_1;
            }
            set { _objSelfEmployedIncomeViewModel_Co3_Income_1 = value; }
        }

        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co3_Income_2 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co3_Income_2
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co3_Income_2;
            }
            set { _objSelfEmployedIncomeViewModel_Co3_Income_2 = value; }
        }

        public decimal? TotalSelfEmployedIncome_Co3 { get; set; }
        public bool IsVisibleTotalSelfEmployedIncome_Co3 { get; set; }
        public bool IsEnabledTotalSelfEmployedIncome_Co3 { get; set; }
        #endregion

        #region Other
        private OtherIncomeViewModel _objOtherIncomeViewModel_Co3_Income_1 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co3_Income_1
        {
            get
            {
                return _objOtherIncomeViewModel_Co3_Income_1;
            }
            set { _objOtherIncomeViewModel_Co3_Income_1 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co3_Income_2 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co3_Income_2
        {
            get
            {
                return _objOtherIncomeViewModel_Co3_Income_2;
            }
            set { _objOtherIncomeViewModel_Co3_Income_2 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co3_Income_3 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co3_Income_3
        {
            get
            {
                return _objOtherIncomeViewModel_Co3_Income_3;
            }
            set { _objOtherIncomeViewModel_Co3_Income_3 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co3_Income_4 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co3_Income_4
        {
            get
            {
                return _objOtherIncomeViewModel_Co3_Income_4;
            }
            set { _objOtherIncomeViewModel_Co3_Income_4 = value; }
        }

        public decimal? TotalOtherIncome_Co3 { get; set; }
        public bool IsVisibleTotalOtherIncome_Co3 { get; set; }
        public bool IsEnabledTotalOtherIncome_Co3 { get; set; }
        #endregion

        #region Total
        public float TotalIncome_Co3 { get; set; }
        public bool IsVisibleTotalIncome_Co3 { get; set; }
        public bool IsEnabledTotalIncome_Co3 { get; set; }
        #endregion

        #endregion

        #region Summary
        public decimal? TotalSalariedIncome { get; set; }
        public bool IsVisibleTotalSalariedIncome { get; set; }
        public bool IsEnabledTotalSalariedIncome { get; set; }

        public decimal? TotalRentalIncome { get; set; }
        public bool IsVisibleTotalRentalIncome { get; set; }
        public bool IsEnabledTotalRentalIncome { get; set; }

        public decimal? TotalCarRentalIncome { get; set; }
        public bool IsVisibleTotalCarRentalIncome { get; set; }
        public bool IsEnabledTotalCarRentalIncome { get; set; }

        public decimal? TotalSelfEmployedIncome { get; set; }
        public bool IsVisibleTotalSelfEmployedIncome { get; set; }
        public bool IsEnabledTotalSelfEmployedIncome { get; set; }

        public decimal? TotalIncome { get; set; }
        public bool IsVisibleTotalIncome { get; set; }
        public bool IsEnabledTotalIncome { get; set; }

        public bool IsActive { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        #endregion
    }

    public class SalariedClientIncomeViewModel
    {
        public int ID { get; set; }

        public int CustomerID { get; set; }
        public int CustomerIncomeID { get; set; }

        public int? BorrowerTypeID { get; set; }
        public string BorrowerType { get; set; }
        public bool IsVisibleBorrowerType { get; set; }
        public bool IsEnabledBorrowerType { get; set; }

        public int? IncomeTypeID { get; set; }
        public string IncomeType { get; set; }
        public bool IsVisibleIncomeType { get; set; }
        public bool IsEnabledIncomeType { get; set; }

        public int ALCustomerID { get; set; }
        public int ALCustomerIncomeID { get; set; }
        public int ALCustomerSalariedClientIncomeID { get; set; }

        public int? CompanyCodeID { get; set; }
        public string CompanyCode { get; set; }
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsEnabledCompanyCode { get; set; }

        public string CompanyName { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsEnabledCompanyName { get; set; }

        public string CompanyAddress { get; set; }
        public bool IsVisibleCompanyAddress { get; set; }
        public bool IsEnabledCompanyAddress { get; set; }

        public string CompanyWard { get; set; }
        public bool IsVisibleCompanyWard { get; set; }
        public bool IsEnabledCompanyWard { get; set; }

        public int? CompanyDistrictID { get; set; }
        public string CompanyDistrict { get; set; }
        public bool IsVisibleCompanyDistrict { get; set; }
        public bool IsEnabledCompanyDistrict { get; set; }

        public int? CompanyCityID { get; set; }
        public string CompanyCity { get; set; }
        public bool IsVisibleCompanyCity { get; set; }
        public bool IsEnabledCompanyCity { get; set; }

        public string OfficeTel { get; set; }
        public bool IsVisibleOfficeTel { get; set; }
        public bool IsEnabledOfficeTel { get; set; }

        public int? CompanyNatureOfBusinessID { get; set; }
        public string CompanyNatureOfBusiness { get; set; }
        public bool IsVisibleCompanyNatureOfBusiness { get; set; }
        public bool IsEnabledCompanyNatureOfBusiness { get; set; }

        public int? CompanyIndustryID { get; set; }
        public string CompanyIndustry { get; set; }
        public bool IsVisibleCompanyIndustry { get; set; }
        public bool IsEnabledCompanyIndustry { get; set; }

        public int? OccupationID { get; set; }
        public string Occupation { get; set; }
        public bool IsVisibleOccupation { get; set; }
        public bool IsEnabledOccupation { get; set; }

        public int? CurrentPositionID { get; set; }
        public string CurrentPosition { get; set; }
        public bool IsVisibleCurrentPosition { get; set; }
        public bool IsEnabledCurrentPosition { get; set; }

        public int? EmploymentTypeID { get; set; }
        public string EmploymentType { get; set; }
        public bool IsVisibleEmploymentType { get; set; }
        public bool IsEnabledEmploymentType { get; set; }

        public string WorkingAddress { get; set; }
        public bool IsVisibleWorkingAddress { get; set; }
        public bool IsEnabledWorkingAddress { get; set; }

        public string WorkingWard { get; set; }
        public bool IsVisibleWorkingWard { get; set; }
        public bool IsEnabledWorkingWard { get; set; }

        public int? DistrictWorkingID { get; set; }
        public string District_Working { get; set; }
        public bool IsVisibleDistrict_Working { get; set; }
        public bool IsEnabledDistrict_Working { get; set; }

        public int? CityWorkingID { get; set; }
        public string City_Working { get; set; }
        public bool IsVisibleCity_Working { get; set; }
        public bool IsEnabledCity_Working { get; set; }

        public decimal? PercentSharesInCompany { get; set; }
        public bool IsVisiblePercentSharesInCompany { get; set; }
        public bool IsEnabledPercentSharesInCompany { get; set; }

        public int? TypeOfLabourContractID { get; set; }
        public string TypeOfLabourContract { get; set; }
        public bool IsVisibleTypeOfLabourContract { get; set; }
        public bool IsEnabledTypeOfLabourContract { get; set; }

        public int? ContractLengthID { get; set; }
        public string ContractLength { get; set; }
        public bool IsVisibleContractLength { get; set; }
        public bool IsEnabledContractLength { get; set; }

        public Nullable<System.DateTime> StartDateAtCurrentCompany { get; set; }
        public bool IsVisibleStartDateAtCurrentCompany { get; set; }
        public bool IsEnabledStartDateAtCurrentCompany { get; set; }

        public int? TotalMonthsInCurrentCompany { get; set; }
        public bool IsVisibleTotalMonthsInCurrentCompany { get; set; }
        public bool IsEnabledTotalMonthsInCurrentCompany { get; set; }

        public int? TotalMonthsInWorkingExperience { get; set; }
        public bool IsVisibleTotalMonthsInWorkingExperience { get; set; }
        public bool IsEnabledTotalMonthsInWorkingExperience { get; set; }

        public int? IncometypeID { get; set; }
        public string Incometype { get; set; }
        public bool IsVisibleIncometype { get; set; }
        public bool IsEnabledIncometype { get; set; }

        public decimal? MonthlyIncomeDeclared { get; set; }
        public bool IsVisibleMonthlyIncomeDeclared { get; set; }
        public bool IsEnabledMonthlyIncomeDeclared { get; set; }

        public int? PeriodOfSubmittedBSID { get; set; }
        public string PeriodOfSubmittedBS { get; set; }
        public bool IsVisiblePeriodOfSubmittedBS { get; set; }
        public bool IsEnabledPeriodOfSubmittedBS { get; set; }

        public bool FreelanceIncome { get; set; }
        public bool IsVisibleFreelanceIncome { get; set; }
        public bool IsEnabledFreelanceIncome { get; set; }

        public decimal? GrossBaseSalary { get; set; }
        public bool IsVisibleGrossBaseSalary { get; set; }
        public bool IsEnabledGrossBaseSalary { get; set; }

        public decimal? BasicAllowance { get; set; }
        public bool IsVisibleBasicAllowance { get; set; }
        public bool IsEnabledBasicAllowance { get; set; }

        public decimal? EligibleFixedIncomeOnLC { get; set; }
        public bool IsVisibleEligibleFixedIncomeOnLC { get; set; }
        public bool IsEnabledEligibleFixedIncomeOnLC { get; set; }

        public decimal? FixedIncomeViaBS { get; set; }
        public bool IsVisibleFixedIncomeViaBS { get; set; }
        public bool IsEnabledFixedIncomeViaBS { get; set; }

        public decimal? TotalMonthlyIncomeViaBS { get; set; }
        public bool IsVisibleTotalMonthlyIncomeViaBS { get; set; }
        public bool IsEnabledTotalMonthlyIncomeViaBS { get; set; }

        public decimal? PerformanceBonus { get; set; }
        public bool IsVisiblePerformanceBonus { get; set; }
        public bool IsEnabledPerformanceBonus { get; set; }

        public decimal? FinalIncome { get; set; }
        public bool IsVisibleFinalIncome { get; set; }
        public bool IsEnabledFinalIncome { get; set; }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel;
            }
            set { _objCustomerIncomeMonthlyViewModel = value; }
        }

        private List<CustomerBonusMonthlyViewModel> _objCustomerBonusMonthlyViewModel = new List<CustomerBonusMonthlyViewModel>();
        public List<CustomerBonusMonthlyViewModel> _CustomerBonusMonthlyViewModel
        {
            get
            {
                return _objCustomerBonusMonthlyViewModel;
            }
            set { _objCustomerBonusMonthlyViewModel = value; }
        }

        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsActive { get; set; }
    }

    public class HouseRentalIncomeViewModel
    {
        public int ID { get; set; }

        public int CustomerID { get; set; }
        public int CustomerIncomeID { get; set; }

        public int BorrowerTypeID { get; set; }
        public string BorrowerType { get; set; }
        public bool IsVisibleBorrowerType { get; set; }
        public bool IsEnabledBorrowerType { get; set; }

        public int IncomeTypeID { get; set; }
        public string IncomeType { get; set; }
        public bool IsVisibleIncomeType { get; set; }
        public bool IsEnabledIncomeType { get; set; }

        public int ALCustomerID { get; set; }
        public int ALCustomerIncomeID { get; set; }
        public int ALCustomerSalariedClientIncomeID { get; set; }

        public string DetailsOfPropertyForRent { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent { get; set; }
        public bool IsEnabledDetailsOfPropertyForRent { get; set; }

        public string RentalPropertyAddress { get; set; }
        public bool IsVisibleRentalPropertyAddress { get; set; }
        public bool IsEnabledRentalPropertyAddress { get; set; }

        public string RentalPropertyOwnershipName { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName { get; set; }
        public bool IsEnabledRentalPropertyOwnershipName { get; set; }

        public string LesseeNameAddressContact { get; set; }
        public bool IsVisibleLesseeNameAddressContact { get; set; }
        public bool IsEnabledLesseeNameAddressContact { get; set; }

        public string Ward { get; set; }
        public bool IsVisibleWard { get; set; }
        public bool IsEnabledWard { get; set; }

        public string District { get; set; }
        public bool IsVisibleDistrict { get; set; }
        public bool IsEnabledDistrict { get; set; }
        public int DistrictID { get; set; }

        public string City { get; set; }
        public bool IsVisibleCity { get; set; }
        public bool IsEnabledCity { get; set; }
        public int CityID { get; set; }

        public string RentalContaclTenure { get; set; }
        public bool IsVisibleRentalContaclTenure { get; set; }
        public bool IsEnabledRentalContaclTenure { get; set; }

        public string MonthlyRentalFee { get; set; }
        public bool IsVisibleMonthlyRentalFee { get; set; }
        public bool IsEnabledMonthlyRentalFee { get; set; }

        public string RentalPurpose { get; set; }
        public bool IsVisibleRentalPurpose { get; set; }
        public bool IsEnabledRentalPurpose { get; set; }

        public string RepaymentCycle { get; set; }
        public bool IsVisibleRepaymentCycle { get; set; }
        public bool IsEnabledRepaymentCycle { get; set; }

        public int RepaymentCycleID { get; set; }
        public string IncomePaymentMethod { get; set; }
        public bool IsVisibleIncomePaymentMethod { get; set; }
        public bool IsEnabledIncomePaymentMethod { get; set; }

        public int IncomePaymentMethodID { get; set; }
        public decimal TotalRentalIncome { get; set; }
        public bool IsVisibleTotalRentalIncome { get; set; }
        public bool IsEnabledTotalRentalIncome { get; set; }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel;
            }
            set { _objCustomerIncomeMonthlyViewModel = value; }
        }

        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsActive { get; set; }
    }

    public class CarRentalIncomeViewModel
    {
        public int ID { get; set; }

        public int CustomerID { get; set; }
        public int CustomerIncomeID { get; set; }

        public int BorrowerTypeID { get; set; }
        public string BorrowerType { get; set; }
        public bool IsVisibleBorrowerType { get; set; }
        public bool IsEnabledBorrowerType { get; set; }

        public int IncomeTypeID { get; set; }
        public string IncomeType { get; set; }
        public bool IsVisibleIncomeType { get; set; }
        public bool IsEnabledIncomeType { get; set; }

        public int ALCustomerID { get; set; }
        public int ALCustomerIncomeID { get; set; }
        public int ALCustomerSalariedClientIncomeID { get; set; }

        public string DetailsOfCarforRent { get; set; }
        public bool IsVisibleDetailsOfCarforRent { get; set; }
        public bool IsEnabledDetailsOfCarforRent { get; set; }

        public string TypeOfCar { get; set; }
        public bool IsVisibleTypeOfCar { get; set; }
        public bool IsEnabledTypeOfCar { get; set; }

        public string CarPlateNumber { get; set; }
        public bool IsVisibleCarPlateNumber { get; set; }
        public bool IsEnabledCarPlateNumber { get; set; }

        public string CarOwnershipName { get; set; }
        public bool IsVisibleCarOwnershipName { get; set; }
        public bool IsEnabledCarOwnershipName { get; set; }

        public string CarLesseeNameAddressContact { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact { get; set; }
        public bool IsCarEnabledLesseeNameAddressContact { get; set; }

        public string RentalContractTenure { get; set; }
        public bool IsVisibleRentalContractTenure { get; set; }
        public bool IsEnabledRentalContractTenure { get; set; }

        public string CarMonthlyRentalFee { get; set; }
        public bool IsCarVisibleMonthlyRentalFee { get; set; }
        public bool IsCarEnabledMonthlyRentalFee { get; set; }

        public string CarRepaymentCycle { get; set; }
        public bool IsCarVisibleRepaymentCycle { get; set; }
        public bool IsCarEnabledRepaymentCycle { get; set; }
        public int CarRepaymentCycleID { get; set; }

        public string CarIncomePaymentMethod { get; set; }
        public bool IsCarVisibleIncomePaymentMethod { get; set; }
        public bool IsCarEnabledIncomePaymentMethod { get; set; }
        public int CarIncomePaymentMethodID { get; set; }

        public decimal? TotalCarRentalIncome { get; set; }
        public bool IsVisibleTotalCarRentalIncome { get; set; }
        public bool IsEnabledTotalCarRentalIncome { get; set; }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel;
            }
            set { _objCustomerIncomeMonthlyViewModel = value; }
        }

        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsActive { get; set; }
    }

    public class SelfEmployedIncomeViewModel
    {
        public int ID { get; set; }

        public int CustomerID { get; set; }
        public int CustomerIncomeID { get; set; }

        public int BorrowerTypeID { get; set; }
        public string BorrowerType { get; set; }
        public bool IsVisibleBorrowerType { get; set; }
        public bool IsEnabledBorrowerType { get; set; }

        public int IncomeTypeID { get; set; }
        public string IncomeType { get; set; }
        public bool IsVisibleIncomeType { get; set; }
        public bool IsEnabledIncomeType { get; set; }

        public int ALCustomerID { get; set; }
        public int ALCustomerIncomeID { get; set; }
        public int ALCustomerSalariedClientIncomeID { get; set; }

        public int? CompanyID { get; set; }
        public string CompanyName { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsEnabledCompanyName { get; set; }

        public string BusinessLicenceNumber { get; set; }
        public bool IsVisibleBusinessLicenceNumber { get; set; }
        public bool IsEnabledBusinessLicenceNumber { get; set; }

        public string TaxCode { get; set; }
        public bool IsVisibleTaxCode { get; set; }
        public bool IsEnabledTaxCode { get; set; }

        public string CompanyAddress { get; set; }
        public bool IsVisibleCompanyAddress { get; set; }
        public bool IsEnabledCompanyAddress { get; set; }

        public string SelfWard { get; set; }
        public bool IsVisibleSelfWard { get; set; }
        public bool IsEnabledSelfWard { get; set; }

        public string DisTrict { get; set; }
        public bool IsVisibleDisTrict { get; set; }
        public bool IsEnabledDisTrict { get; set; }
        public int DisTrictID { get; set; }

        public string SelfCity { get; set; }
        public bool IsVisibleSelfCity { get; set; }
        public bool IsEnabledSelfCity { get; set; }
        public string SelfCityID { get; set; }

        public string Ofcetel { get; set; }
        public bool IsVisibleOfcetel { get; set; }
        public bool IsEnabledOfcetel { get; set; }

        public string MainCompanyIndustry1 { get; set; }
        public bool IsVisibleMainCompanyIndustry1 { get; set; }
        public bool IsEnabledMainCompanyIndustry1 { get; set; }
        public int MainCompanyIndustry1ID { get; set; }

        public string MainCompanyIndustry2 { get; set; }
        public bool IsVisibleMainCompanyIndustry2 { get; set; }
        public bool IsEnabledMainCompanyIndustry2 { get; set; }
        public int MainCompanyIndustry2ID { get; set; }

        public string OtherCompanyIndustryBizNature { get; set; }
        public bool IsVisibleOtherCompanyIndustryBizNature { get; set; }
        public bool IsEnabledOtherCompanyIndustryBizNature { get; set; }

        public string SeasonalIndustry { get; set; }
        public bool IsVisibleSeasonalIndustry { get; set; }
        public bool IsEnabledSeasonalIndustry { get; set; }

        public Nullable<DateTime> EstablishedYear { get; set; }
        public bool IsVisibleEstablishedYear { get; set; }
        public bool IsEnabledEstablishedYear { get; set; }

        public int TotalYearsInOperation { get; set; }
        public bool IsVisibleTotalYearsInOperation { get; set; }
        public bool IsEnabledTotalYearsInOperation { get; set; }

        public int ShareholdingInCompany { get; set; }
        public bool IsVisibleShareholdingInCompany { get; set; }
        public bool IsEnabledShareholdingInCompany { get; set; }

        public string ProfLossinLatestYear { get; set; }
        public bool IsVisibleProfLossinLatestYear { get; set; }
        public bool IsEnabledProfLossinLatestYear { get; set; }
        public int ProfLossinLatestYearID { get; set; }

        public string TypeOfSelfEmploymentIncome { get; set; }
        public bool IsVisibleTypeOfSelfEmploymentIncome { get; set; }
        public bool IsEnabledTypeOfSelfEmploymentIncome { get; set; }
        public int TypeOfSelfEmploymentIncomeID { get; set; }

        public int? TotalTurnoverinFS { get; set; }
        public bool IsVisibleTotalTurnoverinFS { get; set; }
        public bool IsEnabledTotalTurnoverinFS { get; set; }

        public decimal? MonthlyTurnoverinyear { get; set; }
        public bool IsVisibleMonthlyTurnoverinyear { get; set; }
        public bool IsEnabledMonthlyTurnoverinyear { get; set; }

        public decimal? TotalUpdatedTurnover { get; set; }
        public bool IsVisibleTotalUpdatedTurnover { get; set; }
        public bool IsEnabledTotalUpdatedTurnover { get; set; }

        public decimal? AverageMonthlyUpdatedTurnover { get; set; }
        public bool IsVisibleAverageMonthlyUpdatedTurnover { get; set; }
        public bool IsEnabledAverageMonthlyUpdatedTurnover { get; set; }

        public decimal? ComparedWithTurnOver { get; set; }
        public bool IsVisibleComparedWithTurnOver { get; set; }
        public bool IsEnabledComparedWithTurnOver { get; set; }

        public decimal? RevisedAverageMonthlyTurnover { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnover { get; set; }
        public bool IsEnabledRevisedAverageMonthlyTurnover { get; set; }

        public int? SplitupIndustry1 { get; set; }
        public bool IsVisibleSplitupIndustr1 { get; set; }
        public bool IsEnabledSplitupIndustry1 { get; set; }

        public int? SplitupIndustry2 { get; set; }
        public bool IsVisibleSplitupIndustry2 { get; set; }
        public bool IsEnabledSplitupIndustry2 { get; set; }

        public int? SplitupIndustry3 { get; set; }
        public bool IsVisibleSplitupIndustry3 { get; set; }
        public bool IsEnabledSplitupIndustry3 { get; set; }

        public int? IndustrialMargin1 { get; set; }
        public bool IsVisibleIndustrialMargin1 { get; set; }
        public bool IsEnabledIndustrialMargin1 { get; set; }

        public int? IndustrialMargin2 { get; set; }
        public bool IsVisibleIndustrialMargin2 { get; set; }
        public bool IsEnabledIndustrialMargin2 { get; set; }

        public int? IndustrialMargin3 { get; set; }
        public bool IsVisibleIndustrialMargin3 { get; set; }
        public bool IsEnabledIndustrialMargin3 { get; set; }

        public string Remark { get; set; }
        public bool IsVisibleRemark { get; set; }
        public bool IsEnabledRemark { get; set; }

        public decimal? MonthlySeflEmployedIncome { get; set; }
        public bool IsVisibleMonthlySeflEmployedIncome { get; set; }
        public bool IsEnabledMonthlySeflEmployedIncome { get; set; }

        public decimal? CustomerMonthlySelfEmployedIncome { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncome { get; set; }
        public bool IsEnabledCustomerMonthlySelfEmployedIncome { get; set; }

        public decimal? TotalTurnoverinFSBank { get; set; }
        public bool IsVisibleTotalTurnoverinFSBank { get; set; }
        public bool IsEnabledTotalTurnoverinFSBank { get; set; }

        public decimal? MonthlyTurnoverInyearBank { get; set; }
        public bool IsVisibleMonthlyTurnoverInyearBank { get; set; }
        public bool IsEnabledMonthlyTurnoverInyearBank { get; set; }

        public int? OtherMonthlyTurnover { get; set; }
        public bool IsVisibleOtherMonthlyTurnover { get; set; }
        public bool IsEnabledOtherMonthlyTurnover { get; set; }

        public decimal? AverageEligibleCreditBalance { get; set; }
        public bool IsVisibleAverageEligibleCreditBalance { get; set; }
        public bool IsEnabledAverageEligibleCreditBalance { get; set; }

        public decimal? TotalEligibleMonthlyIncome { get; set; }
        public bool IsVisibleTotalEligibleMonthlyIncome { get; set; }
        public bool IsEnabledTotalEligibleMonthlyIncome { get; set; }

        public decimal? RevisedAverageMonthlyTurnoverBank { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnoverBank { get; set; }
        public bool IsEnabledRevisedAverageMonthlyTurnoverBank { get; set; }

        public int? SplitupIndustryBank1 { get; set; }
        public bool IsVisibleSplitupIndustryBank1 { get; set; }
        public bool IsEnabledSplitupIndustryBank1 { get; set; }

        public int? SplitupIndustryBank2 { get; set; }
        public bool IsVisibleSplitupIndustryBank2 { get; set; }
        public bool IsEnabledSplitupIndustryBank2 { get; set; }

        public int? SplitupIndustryBank3 { get; set; }
        public bool IsVisibleSplitupIndustryBank3 { get; set; }
        public bool IsEnabledSplitupIndustryBank3 { get; set; }

        public int? IndustrialMarginBank1 { get; set; }
        public bool IsVisibleIndustrialMarginBank1 { get; set; }
        public bool IsEnabledIndustrialMarginBank1 { get; set; }

        public int? IndustrialMarginBank2 { get; set; }
        public bool IsVisibleIndustrialMarginBank2 { get; set; }
        public bool IsEnabledIndustrialMarginBank2 { get; set; }

        public int? IndustrialMarginBank3 { get; set; }
        public bool IsVisibleIndustrialMarginBank3 { get; set; }
        public bool IsEnabledIndustrialMarginBank3 { get; set; }

        public string RemarkBank { get; set; }
        public bool IsVisibleRemarkBank { get; set; }
        public bool IsEnabledRemarkBank { get; set; }

        public decimal? MonthlySelfEmployedIncome { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncome { get; set; }
        public bool IsEnabledMonthlySelfEmployedIncome { get; set; }

        public decimal? CustomerMonthlySelfEmployedIncomeBank { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeBank { get; set; }
        public bool IsEnabledCustomerMonthlySelfEmployedIncomeBank { get; set; }

        public decimal? TotalTurnoverInFS { get; set; }
        public bool IsVisibleTotalTurnoverInFS { get; set; }
        public bool IsEnabledTotalTurnoverInFS { get; set; }

        public decimal? ProftafertaxinLatestYear { get; set; }
        public bool IsVisibleProftafertaxinLatestYear { get; set; }
        public bool IsEnabledProftafertaxinLatestYear { get; set; }

        public decimal? Depreciation { get; set; }
        public bool IsVisibleDepreciation { get; set; }
        public bool IsEnabledDepreciation { get; set; }

        public decimal? MonthlyTurnoverInYear { get; set; }
        public bool IsVisibleMonthlyTurnoverInYear { get; set; }
        public bool IsEnabledMonthlyTurnoverInYear { get; set; }

        public decimal? MonthlySelfEmployedIncomeCPP { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncomeCPP { get; set; }
        public bool IsEnabledMonthlySelfEmployedIncomeCPP { get; set; }

        public decimal? CustomerMonthlySelfEmployedIncomeCPP { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeCPP { get; set; }
        public bool IsEnabledCustomerMonthlySelfEmployedIncomeCPP { get; set; }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel_IGMVAT = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel_IGMVAT
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel_IGMVAT;
            }
            set { _objCustomerIncomeMonthlyViewModel_IGMVAT = value; }
        }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit;
            }
            set { _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit = value; }
        }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan;
            }
            set { _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan = value; }
        }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit;
            }
            set { _objCustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit = value; }
        }

        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsActive { get; set; }
    }

    public class OtherIncomeViewModel
    {
        public int ID { get; set; }

        public int CustomerID { get; set; }
        public int CustomerIncomeID { get; set; }

        public int BorrowerTypeID { get; set; }
        public string BorrowerType { get; set; }
        public bool IsVisibleBorrowerType { get; set; }
        public bool IsEnabledBorrowerType { get; set; }

        public int IncomeTypeID { get; set; }
        public string IncomeType { get; set; }
        public bool IsVisibleIncomeType { get; set; }
        public bool IsEnabledIncomeType { get; set; }

        public int ALCustomerID { get; set; }
        public int ALCustomerIncomeID { get; set; }
        public int ALCustomerSalariedClientIncomeID { get; set; }

        public decimal? DiscountRate1 { get; set; }
        public bool IsVisibleDiscountRate1 { get; set; }
        public bool IsEnabledDiscountRate1 { get; set; }

        public decimal? TotalUpdatedTurnover1_other { get; set; }
        public bool IsVisibleTotalUpdatedTurnover1_other { get; set; }
        public bool IsEnabledTotalUpdatedTurnover1_other { get; set; }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel;
            }
            set { _objCustomerIncomeMonthlyViewModel = value; }
        }

        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsActive { get; set; }
    }
}
