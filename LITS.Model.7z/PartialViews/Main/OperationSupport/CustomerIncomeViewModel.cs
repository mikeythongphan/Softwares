﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.OperationSupport
{
    public class CustomerIncomeViewModel
    {
        #region Main

        #region SalariedClient
        #region Income1
        public string CompanyCode_Main { get; set; }
        public bool IsVisibleCompanyCode_Main { get; set; }
        public bool IsDisableCompanyCode_Main { get; set; }

        public string CompanyName_Main { get; set; }
        public bool IsVisibleCompanyName_Main { get; set; }
        public bool IsDisableCompanyName_Main { get; set; }

        public string CompanyAddress_Main { get; set; }
        public bool IsVisibleCompanyAddress_Main { get; set; }
        public bool IsDisableCompanyAddress_Main { get; set; }

        public string Ward_Company_Main { get; set; }
        public bool IsVisibleWard_Company_Main { get; set; }
        public bool IsDisableWard_Company_Main { get; set; }

        public string District_Company_Main { get; set; }
        public bool IsVisibleDistrict_Company_Main { get; set; }
        public bool IsDisableDistrict_Company_Main { get; set; }

        public string City_Company_Main { get; set; }
        public bool IsVisibleCity_Company_Main { get; set; }
        public bool IsDisableCity_Company_Main { get; set; }

        public int CityID_Company_Main { get; set; }
        public bool IsVisibleCityID_Company_Main { get; set; }
        public bool IsDisableCityID_Company_Main { get; set; }

        public string OfceTel_Main { get; set; }
        public bool IsVisibleOfceTel_Main { get; set; }
        public bool IsDisableOfceTel_Main { get; set; }

        public string CompanyNatureOfBusiness_Main { get; set; }
        public bool IsVisibleCompanyNatureOfBusiness_Main { get; set; }
        public bool IsDisableCompanyNatureOfBusiness_Main { get; set; }
        public int CompanyNatureOfBusinessID_Main { get; set; }

        public string CompanyIndustry_Main { get; set; }
        public bool IsVisibleCompanyIndustry_Main { get; set; }
        public bool IsDisableCompanyIndustry_Main { get; set; }
        public int CompanyIndustryID_Main { get; set; }

        public string Occupation_Main { get; set; }
        public bool IsVisibleOccupation_Main { get; set; }
        public bool IsDisableOccupation_Main { get; set; }
        public int OccupationID_Main { get; set; }

        public string CurrentPosition_Main { get; set; }
        public bool IsVisibleCurrentPosition_Main { get; set; }
        public bool IsDisableCurrentPosition_Main { get; set; }
        public int CurrentPositionID_Main { get; set; }

        public string EmploymentType_Main { get; set; }
        public bool IsVisibleEmploymentType_Main { get; set; }
        public bool IsDisableEmploymentType_Main { get; set; }
        public int EmploymentTypeID_Main { get; set; }

        public string WorkingAddress_Main { get; set; }
        public bool IsVisibleWorkingAddress_Main { get; set; }
        public bool IsDisableWorkingAddress_Main { get; set; }

        public string Ward_Working_Main { get; set; }
        public bool IsVisibleWard_Working_Main { get; set; }
        public bool IsDisableWard_Working_Main { get; set; }

        public string District_Working_Main { get; set; }
        public bool IsVisibleDistrict_Working_Main { get; set; }
        public bool IsDisableDistrict_Working_Main { get; set; }
        public int DistrictID_Working_Main { get; set; }

        public string City_Working_Main { get; set; }
        public bool IsVisibleCity_Working_Main { get; set; }
        public bool IsDisableCity_Working_Main { get; set; }

        public string PercentSharesInCompany_Main { get; set; }
        public bool IsVisiblePercentSharesInCompany_Main { get; set; }
        public bool IsDisablePercentSharesInCompany_Main { get; set; }

        public string TypeOfLabourContract_Main { get; set; }
        public bool IsVisibleTypeOfLabourContract_Main { get; set; }
        public bool IsDisableTypeOfLabourContract_Main { get; set; }
        public int TypeOfLabourContractID_Main { get; set; }

        public string ContractLength_Main { get; set; }
        public bool IsVisibleContractLength_Main { get; set; }
        public bool IsDisableContractLength_Main { get; set; }
        public int ContractLengthID_Main { get; set; }

        public Nullable<System.DateTime> StartDateAtCurrentCompany_Main { get; set; }
        public bool IsVisibleStartDateAtCurrentCompany_Main { get; set; }
        public bool IsDisableStartDateAtCurrentCompany_Main { get; set; }

        public int TotalMonthsInCurrentCompany_Main { get; set; }
        public bool IsVisibleTotalMonthsInCurrentCompany_Main { get; set; }
        public bool IsDisableTotalMonthsInCurrentCompany_Main { get; set; }

        public int TotalMonthsInWorkingExperience_Main { get; set; }
        public bool IsVisibleTotalMonthsInWorkingExperience_Main { get; set; }
        public bool IsDisableTotalMonthsInWorkingExperience_Main { get; set; }

        public string Incometype_Main { get; set; }
        public bool IsVisibleIncometype_Main { get; set; }
        public bool IsDisableIncometype_Main { get; set; }
        public int IncometypeID_Main { get; set; }

        public float MonthlyIncome_Main { get; set; }
        public bool IsVisibleMonthlyIncome_Main { get; set; }
        public bool IsDisableMonthlyIncome_Main { get; set; }

        public string PeriodOfSubmittedBS_Main { get; set; }
        public bool IsVisiblePeriodOfSubmittedBS_Main { get; set; }
        public bool IsDisablePeriodOfSubmittedBS_Main { get; set; }
        public int PeriodOfSubmittedBSID_Main { get; set; }

        public bool FreelanceIncome_Main { get; set; }
        public bool IsVisibleFreelanceIncome_Main { get; set; }
        public bool IsDisableFreelanceIncome_Main { get; set; }

        public float GrossBaseSalary_Main { get; set; }
        public bool IsVisibleGrossBaseSalary_Main { get; set; }
        public bool IsDisableGrossBaseSalary_Main { get; set; }

        public float BasicAllowance_Main { get; set; }
        public bool IsVisibleBasicAllowance_Main { get; set; }
        public bool IsDisableBasicAllowance_Main { get; set; }

        public float EligibleFixedIncomeOnLC_Main { get; set; }
        public bool IsVisibleEligibleFixedIncomeOnLC_Main { get; set; }
        public bool IsDisableEligibleFixedIncomeOnLC_Main { get; set; }

        public float FixedIncomeViaBS_Main { get; set; }
        public bool IsVisibleFixedIncomeViaBS_Main { get; set; }
        public bool IsDisableFixedIncomeViaBS_Main { get; set; }

        public float TotalMonthlyIncomeViaBS_Main { get; set; }
        public bool IsVisibleTotalMonthlyIncomeViaBS_Main { get; set; }
        public bool IsDisableTotalMonthlyIncomeViaBS_Main { get; set; }

        public float PerformanceBonus_Main { get; set; }
        public bool IsVisiblePerformanceBonus_Main { get; set; }
        public bool IsDisablePerformanceBonus_Main { get; set; }

        public float FinalIncome_Main { get; set; }
        public bool IsVisibleFinalIncome_Main { get; set; }
        public bool IsDisableFinalIncome_Main { get; set; }
        #endregion
        #region Income2      
        #endregion
        public float TotalSalariedIncome_Main { get; set; }
        public bool IsVisibleTotalSalariedIncome_Main { get; set; }
        public bool IsDisableTotalSalariedIncome_Main { get; set; }
        #endregion

        #region Rental
        #endregion

        #region SelfEmployed
        #endregion

        #region Other
        #endregion
        public float TotalIncome_Main { get; set; }
        public bool IsVisibleTotalIncome_Main { get; set; }
        public bool IsDisableTotalIncome_Main { get; set; }

        #endregion


        #region Co1

        #region SalariedClient
        #region Income1
        public string CompanyCode_Co1 { get; set; }
        public bool IsVisibleCompanyCode_Co1 { get; set; }
        public bool IsDisableCompanyCode_Co1 { get; set; }

        public string CompanyName_Co1 { get; set; }
        public bool IsVisibleCompanyName_Co1 { get; set; }
        public bool IsDisableCompanyName_Co1 { get; set; }

        public string CompanyAddress_Co1 { get; set; }
        public bool IsVisibleCompanyAddress_Co1 { get; set; }
        public bool IsDisableCompanyAddress_Co1 { get; set; }

        public string Ward_Company_Co1 { get; set; }
        public bool IsVisibleWard_Company_Co1 { get; set; }
        public bool IsDisableWard_Company_Co1 { get; set; }

        public string District_Company_Co1 { get; set; }
        public bool IsVisibleDistrict_Company_Co1 { get; set; }
        public bool IsDisableDistrict_Company_Co1 { get; set; }

        public string City_Company_Co1 { get; set; }
        public bool IsVisibleCity_Company_Co1 { get; set; }
        public bool IsDisableCity_Company_Co1 { get; set; }
        public int CityID_Company_Co1 { get; set; }

        public string OfceTel_Co1 { get; set; }
        public bool IsVisibleOfceTel_Co1 { get; set; }
        public bool IsDisableOfceTel_Co1 { get; set; }

        public string CompanyNatureOfBusiness_Co1 { get; set; }
        public bool IsVisibleCompanyNatureOfBusiness_Co1 { get; set; }
        public bool IsDisableCompanyNatureOfBusiness_Co1 { get; set; }
        public int CompanyNatureOfBusinessID_Co1 { get; set; }

        public string CompanyIndustry_Co1 { get; set; }
        public bool IsVisibleCompanyIndustry_Co1 { get; set; }
        public bool IsDisableCompanyIndustry_Co1 { get; set; }
        public int CompanyIndustryID_Co1 { get; set; }

        public string Occupation_Co1 { get; set; }
        public bool IsVisibleOccupation_Co1 { get; set; }
        public bool IsDisableOccupation_Co1 { get; set; }
        public int OccupationID_Co1 { get; set; }

        public string CurrentPosition_Co1 { get; set; }
        public bool IsVisibleCurrentPosition_Co1 { get; set; }
        public bool IsDisableCurrentPosition_Co1 { get; set; }
        public int CurrentPositionID_Co1 { get; set; }

        public string EmploymentType_Co1 { get; set; }
        public bool IsVisibleEmploymentType_Co1 { get; set; }
        public bool IsDisableEmploymentType_Co1 { get; set; }
        public int EmploymentTypeID_Co1 { get; set; }

        public string WorkingAddress_Co1 { get; set; }
        public bool IsVisibleWorkingAddress_Co1 { get; set; }
        public bool IsDisableWorkingAddress_Co1 { get; set; }

        public string Ward_Working_Co1 { get; set; }
        public bool IsVisibleWard_Working_Co1 { get; set; }
        public bool IsDisableWard_Working_Co1 { get; set; }

        public string District_Working_Co1 { get; set; }
        public bool IsVisibleDistrict_Working_Co1 { get; set; }
        public bool IsDisableDistrict_Working_Co1 { get; set; }
        public int DistrictID_Working_Co1 { get; set; }

        public string City_Working_Co1 { get; set; }
        public bool IsVisibleCity_Working_Co1 { get; set; }
        public bool IsDisableCity_Working_Co1 { get; set; }

        public string PercentSharesInCompany_Co1 { get; set; }
        public bool IsVisiblePercentSharesInCompany_Co1 { get; set; }
        public bool IsDisablePercentSharesInCompany_Co1 { get; set; }

        public string TypeOfLabourContract_Co1 { get; set; }
        public bool IsVisibleTypeOfLabourContract_Co1 { get; set; }
        public bool IsDisableTypeOfLabourContract_Co1 { get; set; }
        public int TypeOfLabourContractID_Co1 { get; set; }

        public string ContractLength_Co1 { get; set; }
        public bool IsVisibleContractLength_Co1 { get; set; }
        public bool IsDisableContractLength_Co1 { get; set; }
        public int ContractLengthID_Co1 { get; set; }

        public Nullable<System.DateTime> StartDateAtCurrentCompany_Co1 { get; set; }
        public bool IsVisibleStartDateAtCurrentCompany_Co1 { get; set; }
        public bool IsDisableStartDateAtCurrentCompany_Co1 { get; set; }

        public int TotalMonthsInCurrentCompany_Co1 { get; set; }
        public bool IsVisibleTotalMonthsInCurrentCompany_Co1 { get; set; }
        public bool IsDisableTotalMonthsInCurrentCompany_Co1 { get; set; }

        public int TotalMonthsInWorkingExperience_Co1 { get; set; }
        public bool IsVisibleTotalMonthsInWorkingExperience_Co1 { get; set; }
        public bool IsDisableTotalMonthsInWorkingExperience_Co1 { get; set; }

        public string Incometype_Co1 { get; set; }
        public bool IsVisibleIncometype_Co1 { get; set; }
        public bool IsDisableIncometype_Co1 { get; set; }
        public int IncometypeID_Co1 { get; set; }

        public float MonthlyIncome_Co1 { get; set; }
        public bool IsVisibleMonthlyIncome_Co1 { get; set; }
        public bool IsDisableMonthlyIncome_Co1 { get; set; }

        public string PeriodOfSubmittedBS_Co1 { get; set; }
        public bool IsVisiblePeriodOfSubmittedBS_Co1 { get; set; }
        public bool IsDisablePeriodOfSubmittedBS_Co1 { get; set; }
        public int PeriodOfSubmittedBSID_Co1 { get; set; }

        public bool FreelanceIncome_Co1 { get; set; }
        public bool IsVisibleFreelanceIncome_Co1 { get; set; }
        public bool IsDisableFreelanceIncome_Co1 { get; set; }

        public float GrossBaseSalary_Co1 { get; set; }
        public bool IsVisibleGrossBaseSalary_Co1 { get; set; }
        public bool IsDisableGrossBaseSalary_Co1 { get; set; }

        public float BasicAllowance_Co1 { get; set; }
        public bool IsVisibleBasicAllowance_Co1 { get; set; }
        public bool IsDisableBasicAllowance_Co1 { get; set; }

        public float EligibleFixedIncomeOnLC_Co1 { get; set; }
        public bool IsVisibleEligibleFixedIncomeOnLC_Co1 { get; set; }
        public bool IsDisableEligibleFixedIncomeOnLC_Co1 { get; set; }

        public float FixedIncomeViaBS_Co1 { get; set; }
        public bool IsVisibleFixedIncomeViaBS_Co1 { get; set; }
        public bool IsDisableFixedIncomeViaBS_Co1 { get; set; }

        public float TotalMonthlyIncomeViaBS_Co1 { get; set; }
        public bool IsVisibleTotalMonthlyIncomeViaBS_Co1 { get; set; }
        public bool IsDisableTotalMonthlyIncomeViaBS_Co1 { get; set; }

        public float PerformanceBonus_Co1 { get; set; }
        public bool IsVisiblePerformanceBonus_Co1 { get; set; }
        public bool IsDisablePerformanceBonus_Co1 { get; set; }

        public float FinalIncome_Co1 { get; set; }
        public bool IsVisibleFinalIncome_Co1 { get; set; }
        public bool IsDisableFinalIncome_Co1 { get; set; }
        #endregion
        #region Income2       
        #endregion
        public float TotalSalariedIncome_Co1 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co1 { get; set; }
        public bool IsDisableTotalSalariedIncome_Co1 { get; set; }
        #endregion

        #region Rental
        #endregion

        #region SelfEmployed
        #endregion

        #region Other
        #endregion

        public float TotalIncome_Co1 { get; set; }
        public bool IsVisibleTotalIncome_Co1 { get; set; }
        public bool IsDisableTotalIncome_Co1 { get; set; }
        #endregion


        #region Co2


        #region SalariedClient
        #region Income1
        public string CompanyCode_Co2 { get; set; }
        public bool IsVisibleCompanyCode_Co2 { get; set; }
        public bool IsDisableCompanyCode_Co2 { get; set; }

        public string CompanyName_Co2 { get; set; }
        public bool IsVisibleCompanyName_Co2 { get; set; }
        public bool IsDisableCompanyName_Co2 { get; set; }

        public string CompanyAddress_Co2 { get; set; }
        public bool IsVisibleCompanyAddress_Co2 { get; set; }
        public bool IsDisableCompanyAddress_Co2 { get; set; }

        public string Ward_Company_Co2 { get; set; }
        public bool IsVisibleWard_Company_Co2 { get; set; }
        public bool IsDisableWard_Company_Co2 { get; set; }

        public string District_Company_Co2 { get; set; }
        public bool IsVisibleDistrict_Company_Co2 { get; set; }
        public bool IsDisableDistrict_Company_Co2 { get; set; }

        public string City_Company_Co2 { get; set; }
        public bool IsVisibleCity_Company_Co2 { get; set; }
        public bool IsDisableCity_Company_Co2 { get; set; }

        public int CityID_Company_Co2 { get; set; }
        public bool IsVisibleCityID_Company_Co2 { get; set; }
        public bool IsDisableCityID_Company_Co2 { get; set; }

        public string OfceTel_Co2 { get; set; }
        public bool IsVisibleOfceTel_Co2 { get; set; }
        public bool IsDisableOfceTel_Co2 { get; set; }

        public string CompanyNatureOfBusiness_Co2 { get; set; }
        public bool IsVisibleCompanyNatureOfBusiness_Co2 { get; set; }
        public bool IsDisableCompanyNatureOfBusiness_Co2 { get; set; }
        public int CompanyNatureOfBusinessID_Co2 { get; set; }

        public string CompanyIndustry_Co2 { get; set; }
        public bool IsVisibleCompanyIndustry_Co2 { get; set; }
        public bool IsDisableCompanyIndustry_Co2 { get; set; }
        public int CompanyIndustryID_Co2 { get; set; }

        public string Occupation_Co2 { get; set; }
        public bool IsVisibleOccupation_Co2 { get; set; }
        public bool IsDisableOccupation_Co2 { get; set; }
        public int OccupationID_Co2 { get; set; }

        public string CurrentPosition_Co2 { get; set; }
        public bool IsVisibleCurrentPosition_Co2 { get; set; }
        public bool IsDisableCurrentPosition_Co2 { get; set; }
        public int CurrentPositionID_Co2 { get; set; }

        public string EmploymentType_Co2 { get; set; }
        public bool IsVisibleEmploymentType_Co2 { get; set; }
        public bool IsDisableEmploymentType_Co2 { get; set; }
        public int EmploymentTypeID_Co2 { get; set; }

        public string WorkingAddress_Co2 { get; set; }
        public bool IsVisibleWorkingAddress_Co2 { get; set; }
        public bool IsDisableWorkingAddress_Co2 { get; set; }

        public string Ward_Working_Co2 { get; set; }
        public bool IsVisibleWard_Working_Co2 { get; set; }
        public bool IsDisableWard_Working_Co2 { get; set; }

        public string District_Working_Co2 { get; set; }
        public bool IsVisibleDistrict_Working_Co2 { get; set; }
        public bool IsDisableDistrict_Working_Co2 { get; set; }
        public int DistrictID_Working_Co2 { get; set; }

        public string City_Working_Co2 { get; set; }
        public bool IsVisibleCity_Working_Co2 { get; set; }
        public bool IsDisableCity_Working_Co2 { get; set; }

        public string PercentSharesInCompany_Co2 { get; set; }
        public bool IsVisiblePercentSharesInCompany_Co2 { get; set; }
        public bool IsDisablePercentSharesInCompany_Co2 { get; set; }

        public string TypeOfLabourContract_Co2 { get; set; }
        public bool IsVisibleTypeOfLabourContract_Co2 { get; set; }
        public bool IsDisableTypeOfLabourContract_Co2 { get; set; }
        public int TypeOfLabourContractID_Co2 { get; set; }

        public string ContractLength_Co2 { get; set; }
        public bool IsVisibleContractLength_Co2 { get; set; }
        public bool IsDisableContractLength_Co2 { get; set; }
        public int ContractLengthID_Co2 { get; set; }

        public Nullable<System.DateTime> StartDateAtCurrentCompany_Co2 { get; set; }
        public bool IsVisibleStartDateAtCurrentCompany_Co2 { get; set; }
        public bool IsDisableStartDateAtCurrentCompany_Co2 { get; set; }

        public int TotalMonthsInCurrentCompany_Co2 { get; set; }
        public bool IsVisibleTotalMonthsInCurrentCompany_Co2 { get; set; }
        public bool IsDisableTotalMonthsInCurrentCompany_Co2 { get; set; }

        public int TotalMonthsInWorkingExperience_Co2 { get; set; }
        public bool IsVisibleTotalMonthsInWorkingExperience_Co2 { get; set; }
        public bool IsDisableTotalMonthsInWorkingExperience_Co2 { get; set; }

        public string Incometype_Co2 { get; set; }
        public bool IsVisibleIncometype_Co2 { get; set; }
        public bool IsDisableIncometype_Co2 { get; set; }
        public int IncometypeID_Co2 { get; set; }

        public float MonthlyIncome_Co2 { get; set; }
        public bool IsVisibleMonthlyIncome_Co2 { get; set; }
        public bool IsDisableMonthlyIncome_Co2 { get; set; }

        public string PeriodOfSubmittedBS_Co2 { get; set; }
        public bool IsVisiblePeriodOfSubmittedBS_Co2 { get; set; }
        public bool IsDisablePeriodOfSubmittedBS_Co2 { get; set; }
        public int PeriodOfSubmittedBSID_Co2 { get; set; }

        public bool FreelanceIncome_Co2 { get; set; }
        public bool IsVisibleFreelanceIncome_Co2 { get; set; }
        public bool IsDisableFreelanceIncome_Co2 { get; set; }

        public float GrossBaseSalary_Co2 { get; set; }
        public bool IsVisibleGrossBaseSalary_Co2 { get; set; }
        public bool IsDisableGrossBaseSalary_Co2 { get; set; }

        public float BasicAllowance_Co2 { get; set; }
        public bool IsVisibleBasicAllowance_Co2 { get; set; }
        public bool IsDisableBasicAllowance_Co2 { get; set; }

        public float EligibleFixedIncomeOnLC_Co2 { get; set; }
        public bool IsVisibleEligibleFixedIncomeOnLC_Co2 { get; set; }
        public bool IsDisableEligibleFixedIncomeOnLC_Co2 { get; set; }

        public float FixedIncomeViaBS_Co2 { get; set; }
        public bool IsVisibleFixedIncomeViaBS_Co2 { get; set; }
        public bool IsDisableFixedIncomeViaBS_Co2 { get; set; }

        public float TotalMonthlyIncomeViaBS_Co2 { get; set; }
        public bool IsVisibleTotalMonthlyIncomeViaBS_Co2 { get; set; }
        public bool IsDisableTotalMonthlyIncomeViaBS_Co2 { get; set; }

        public float PerformanceBonus_Co2 { get; set; }
        public bool IsVisiblePerformanceBonus_Co2 { get; set; }
        public bool IsDisablePerformanceBonus_Co2 { get; set; }

        public float FinalIncome_Co2 { get; set; }
        public bool IsVisibleFinalIncome_Co2 { get; set; }
        public bool IsDisableFinalIncome_Co2 { get; set; }
        #endregion
        #region Income2       
        #endregion
        public float TotalSalariedIncome_Co2 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co2 { get; set; }
        public bool IsDisableTotalSalariedIncome_Co2 { get; set; }
        #endregion

        #region Rental
        #endregion

        #region SelfEmployed
        #endregion

        #region Other
        #endregion

        public float TotalIncome_Co2 { get; set; }
        public bool IsVisibleTotalIncome_Co2 { get; set; }
        public bool IsDisableTotalIncome_Co2 { get; set; }
        #endregion


        #region Co3

        #region SalariedClient
        #region Income1
        public string CompanyCode_Co3 { get; set; }
        public bool IsVisibleCompanyCode_Co3 { get; set; }
        public bool IsDisableCompanyCode_Co3 { get; set; }

        public string CompanyName_Co3 { get; set; }
        public bool IsVisibleCompanyName_Co3 { get; set; }
        public bool IsDisableCompanyName_Co3 { get; set; }

        public string CompanyAddress_Co3 { get; set; }
        public bool IsVisibleCompanyAddress_Co3 { get; set; }
        public bool IsDisableCompanyAddress_Co3 { get; set; }

        public string Ward_Company_Co3 { get; set; }
        public bool IsVisibleWard_Company_Co3 { get; set; }
        public bool IsDisableWard_Company_Co3 { get; set; }

        public string District_Company_Co3 { get; set; }
        public bool IsVisibleDistrict_Company_Co3 { get; set; }
        public bool IsDisableDistrict_Company_Co3 { get; set; }

        public string City_Company_Co3 { get; set; }
        public bool IsVisibleCity_Company_Co3 { get; set; }
        public bool IsDisableCity_Company_Co3 { get; set; }

        public int CityID_Company_Co3 { get; set; }
        public bool IsVisibleCityID_Company_Co3 { get; set; }
        public bool IsDisableCityID_Company_Co3 { get; set; }

        public string OfceTel_Co3 { get; set; }
        public bool IsVisibleOfceTel_Co3 { get; set; }
        public bool IsDisableOfceTel_Co3 { get; set; }

        public string CompanyNatureOfBusiness_Co3 { get; set; }
        public bool IsVisibleCompanyNatureOfBusiness_Co3 { get; set; }
        public bool IsDisableCompanyNatureOfBusiness_Co3 { get; set; }
        public int CompanyNatureOfBusinessID_Co3 { get; set; }

        public string CompanyIndustry_Co3 { get; set; }
        public bool IsVisibleCompanyIndustry_Co3 { get; set; }
        public bool IsDisableCompanyIndustry_Co3 { get; set; }
        public int CompanyIndustryID_Co3 { get; set; }

        public string Occupation_Co3 { get; set; }
        public bool IsVisibleOccupation_Co3 { get; set; }
        public bool IsDisableOccupation_Co3 { get; set; }
        public int OccupationID_Co3 { get; set; }

        public string CurrentPosition_Co3 { get; set; }
        public bool IsVisibleCurrentPosition_Co3 { get; set; }
        public bool IsDisableCurrentPosition_Co3 { get; set; }
        public int CurrentPositionID_Co3 { get; set; }

        public string EmploymentType_Co3 { get; set; }
        public bool IsVisibleEmploymentType_Co3 { get; set; }
        public bool IsDisableEmploymentType_Co3 { get; set; }
        public int EmploymentTypeID_Co3 { get; set; }

        public string WorkingAddress_Co3 { get; set; }
        public bool IsVisibleWorkingAddress_Co3 { get; set; }
        public bool IsDisableWorkingAddress_Co3 { get; set; }

        public string Ward_Working_Co3 { get; set; }
        public bool IsVisibleWard_Working_Co3 { get; set; }
        public bool IsDisableWard_Working_Co3 { get; set; }

        public string District_Working_Co3 { get; set; }
        public bool IsVisibleDistrict_Working_Co3 { get; set; }
        public bool IsDisableDistrict_Working_Co3 { get; set; }
        public int DistrictID_Working_Co3 { get; set; }

        public string City_Working_Co3 { get; set; }
        public bool IsVisibleCity_Working_Co3 { get; set; }
        public bool IsDisableCity_Working_Co3 { get; set; }

        public string PercentSharesInCompany_Co3 { get; set; }
        public bool IsVisiblePercentSharesInCompany_Co3 { get; set; }
        public bool IsDisablePercentSharesInCompany_Co3 { get; set; }

        public string TypeOfLabourContract_Co3 { get; set; }
        public bool IsVisibleTypeOfLabourContract_Co3 { get; set; }
        public bool IsDisableTypeOfLabourContract_Co3 { get; set; }
        public int TypeOfLabourContractID_Co3 { get; set; }

        public string ContractLength_Co3 { get; set; }
        public bool IsVisibleContractLength_Co3 { get; set; }
        public bool IsDisableContractLength_Co3 { get; set; }
        public int ContractLengthID_Co3 { get; set; }

        public Nullable<System.DateTime> StartDateAtCurrentCompany_Co3 { get; set; }
        public bool IsVisibleStartDateAtCurrentCompany_Co3 { get; set; }
        public bool IsDisableStartDateAtCurrentCompany_Co3 { get; set; }

        public int TotalMonthsInCurrentCompany_Co3 { get; set; }
        public bool IsVisibleTotalMonthsInCurrentCompany_Co3 { get; set; }
        public bool IsDisableTotalMonthsInCurrentCompany_Co3 { get; set; }

        public int TotalMonthsInWorkingExperience_Co3 { get; set; }
        public bool IsVisibleTotalMonthsInWorkingExperience_Co3 { get; set; }
        public bool IsDisableTotalMonthsInWorkingExperience_Co3 { get; set; }

        public string Incometype_Co3 { get; set; }
        public bool IsVisibleIncometype_Co3 { get; set; }
        public bool IsDisableIncometype_Co3 { get; set; }
        public int IncometypeID_Co3 { get; set; }

        public float MonthlyIncome_Co3 { get; set; }
        public bool IsVisibleMonthlyIncome_Co3 { get; set; }
        public bool IsDisableMonthlyIncome_Co3 { get; set; }

        public string PeriodOfSubmittedBS_Co3 { get; set; }
        public bool IsVisiblePeriodOfSubmittedBS_Co3 { get; set; }
        public bool IsDisablePeriodOfSubmittedBS_Co3 { get; set; }
        public int PeriodOfSubmittedBSID_Co3 { get; set; }

        public bool FreelanceIncome_Co3 { get; set; }
        public bool IsVisibleFreelanceIncome_Co3 { get; set; }
        public bool IsDisableFreelanceIncome_Co3 { get; set; }

        public float GrossBaseSalary_Co3 { get; set; }
        public bool IsVisibleGrossBaseSalary_Co3 { get; set; }
        public bool IsDisableGrossBaseSalary_Co3 { get; set; }

        public float BasicAllowance_Co3 { get; set; }
        public bool IsVisibleBasicAllowance_Co3 { get; set; }
        public bool IsDisableBasicAllowance_Co3 { get; set; }

        public float EligibleFixedIncomeOnLC_Co3 { get; set; }
        public bool IsVisibleEligibleFixedIncomeOnLC_Co3 { get; set; }
        public bool IsDisableEligibleFixedIncomeOnLC_Co3 { get; set; }

        public float FixedIncomeViaBS_Co3 { get; set; }
        public bool IsVisibleFixedIncomeViaBS_Co3 { get; set; }
        public bool IsDisableFixedIncomeViaBS_Co3 { get; set; }

        public float TotalMonthlyIncomeViaBS_Co3 { get; set; }
        public bool IsVisibleTotalMonthlyIncomeViaBS_Co3 { get; set; }
        public bool IsDisableTotalMonthlyIncomeViaBS_Co3 { get; set; }

        public float PerformanceBonus_Co3 { get; set; }
        public bool IsVisiblePerformanceBonus_Co3 { get; set; }
        public bool IsDisablePerformanceBonus_Co3 { get; set; }

        public float FinalIncome_Co3 { get; set; }
        public bool IsVisibleFinalIncome_Co3 { get; set; }
        public bool IsDisableFinalIncome_Co3 { get; set; }
        #endregion
        #region Income2       
        #endregion
        public float TotalSalariedIncome_Co3 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co3 { get; set; }
        public bool IsDisableTotalSalariedIncome_Co3 { get; set; }
        #endregion

        #region Rental
        #endregion

        #region SelfEmployed
        #endregion

        #region Other
        #endregion

        public float TotalIncome_Co3 { get; set; }
        public bool IsVisibleTotalIncome_Co3 { get; set; }
        public bool IsDisableTotalIncome_Co3 { get; set; }
        #endregion

        public decimal TotalSalariedIncome { get; set; }
        public decimal TotalRentalIncome { get; set; }
        public decimal TotalCarRentalIncome { get; set; }
        public decimal TotalSelfEmployedIncome { get; set; }
        public bool IsActive { get; set; }
    }
}
