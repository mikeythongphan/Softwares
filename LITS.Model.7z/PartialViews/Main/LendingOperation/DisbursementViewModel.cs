﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.LendingOperation
{
    public class DisbursementViewModel
    {
        public bool IsActive { get; set; }
        public string ApllicationNo { get; set; }
        public bool IsVisibleApllicationNo { get; set; }
        public bool IsDisableApllicationNo { get; set; }
        public string Channel { get; set; }
        public bool IsVisibleChannel { get; set; }
        public bool IsDisableChannel { get; set; }
        public Nullable<System.DateTime> ExpectingDisbursedDate { get; set; }
        public bool IsVisibleExpectingDisbursedDate { get; set; }
        public bool IsDisableExpectingDisbursedDate { get; set; }
        public Nullable<System.DateTime> RecevingDate { get; set; }
        public bool IsVisibleRecevingDate { get; set; }
        public bool IsDisableRecevingDate { get; set; }
        public string CustomerSegment { get; set; }
        public bool IsVisibleCustomerSegment { get; set; }
        public bool IsDisableCustomerSegment { get; set; }
        public string ARMCode { get; set; }
        public bool IsVisibleARMCode { get; set; }
        public bool IsDisableARMCode { get; set; }
        public string ProgramCode { get; set; }
        public bool IsVisibleProgramCode { get; set; }
        public bool IsDisableProgramCode { get; set; }
    }
}
