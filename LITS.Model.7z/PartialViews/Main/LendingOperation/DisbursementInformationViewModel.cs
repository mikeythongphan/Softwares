﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.LendingOperation
{
    public class DisbursementInformationViewModel
    {
        public bool IsActive { get; set; }
        public Nullable<System.DateTime> DisbursedDate { get; set; }
        public bool IsVisibleDisbursedDate { get; set; }
        public bool IsDisableDisbursedDate { get; set; }
        public string DisbursalStatus { get; set; }
        public bool IsVisibleDisbursalStatus { get; set; }
        public bool IsDisableDisbursalStatus { get; set; }
        public string DisbursedAmount { get; set; }
        public bool IsVisibleDisbursedAmount { get; set; }
        public bool IsDisableDisbursedAmount { get; set; }
        public string LoanAccountNumber { get; set; }
        public bool IsVisibleLoanAccountNumber { get; set; }
        public bool IsDisableLoanAccountNumber { get; set; }
        public string CustomerRelationship { get; set; }
        public bool IsVisibleCustomerRelationship { get; set; }
        public bool IsDisableCustomerRelationship { get; set; }
    }
}
