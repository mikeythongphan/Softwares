﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using System.ComponentModel.DataAnnotations;

namespace LITS.Model.PartialViews.Main.CreateNewLoan
{
    public class CreateNewLoanStep3ViewModel
    {
        #region Application
        public int? ProductTypeID { get; set; }
        public string ProductType { get; set; }
        public bool IsVisibleProductTypeID { get; set; }
        public bool IsDisableProductTypeID { get; set; }

        public int? ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationTypeID { get; set; }
        public bool IsDisableApplicationTypeID { get; set; }

        public int ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public DateTime? ReceivedDate {get;set;}
        public bool IsVisibleReceivedDate { get; set; }
        public bool IsDisableReceivedDate { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsCompanyBlacklist { get; set; }
        public bool IsCustomerBlacklist { get; set; }
        public bool IsDuplicate { get; set; }
        #endregion

        private List<CreateNewLoanStep3CustomerBlackListViewModel> _objCreateNewLoanStep3CustomerBlackList = new List<CreateNewLoanStep3CustomerBlackListViewModel>();
        public List<CreateNewLoanStep3CustomerBlackListViewModel> lstCreateNewLoanStep3CustomerBlackList
        {
            get
            {
                return _objCreateNewLoanStep3CustomerBlackList;
            }
            set { _objCreateNewLoanStep3CustomerBlackList = value; }
        }
        public bool IsVisibleCreateNewLoanStep3CustomerBlackList { get; set; }
        public bool IsDisableCreateNewLoanStep3CustomerBlackList { get; set; }

        private List<CreateNewLoanStep3CompanyBlackListViewModel> _objCreateNewLoanStep3CompanyBlackList = new List<CreateNewLoanStep3CompanyBlackListViewModel>();
        public List<CreateNewLoanStep3CompanyBlackListViewModel> lstCreateNewLoanStep3CompanyBlackList
        {
            get
            {
                return _objCreateNewLoanStep3CompanyBlackList;
            }
            set { _objCreateNewLoanStep3CompanyBlackList = value; }
        }
        public bool IsVisibleCreateNewLoanStep3CompanyBlackList { get; set; }
        public bool IsDisableCreateNewLoanStep3CompanyBlackList { get; set; }

        private List<CreateNewLoanStep3DuplicateViewModel> _objCreateNewLoanStep3DuplicateViewModel = new List<CreateNewLoanStep3DuplicateViewModel>();
        public List<CreateNewLoanStep3DuplicateViewModel> lstCreateNewLoanStep3DuplicateViewModel
        {
            get
            {
                return _objCreateNewLoanStep3DuplicateViewModel;
            }
            set { _objCreateNewLoanStep3DuplicateViewModel = value; }
        }
        public bool IsVisibleCreateNewLoanStep3DuplicateViewModel { get; set; }
        public bool IsDisableCreateNewLoanStep3DuplicateViewModel { get; set; }
    }

    public class CreateNewLoanStep3CustomerBlackListViewModel
    {
        public int ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public int? CustomerID { get; set; }
        public string CustomerName { get; set; }
        public bool IsVisibleCustomerName { get; set; }
        public bool IsDisableCustomerName { get; set; }

        public string IdentificationType { get; set; }
        public int? IdentificationTypeID { get; set; }
        public bool IsVisibleIdentificationType { get; set; }
        public bool IsDisableIdentificationType { get; set; }

        public string IdentificationNo { get; set; }
        public int? IdentificationNoID { get; set; }
        public bool IsVisibleIdentificationNo { get; set; }
        public bool IsDisableIdentificationNo { get; set; }

        public Nullable<DateTime> DateOfBirth { get; set; }
        public bool IsVisibleDateOfBirth { get; set; }
        public bool IsDisableDateOfBirth { get; set; }

        public bool IsActive { get; set; }
    }

    public class CreateNewLoanStep3CompanyBlackListViewModel
    {
        public int ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public int? CompanyNameID { get; set; }
        public string CompanyName { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsDisableCompanyName { get; set; }

        public string CompanyCodeRLS { get; set; }
        public bool IsVisibleCompanyCodeRLS { get; set; }
        public bool IsDisableCompanyCodeRLS { get; set; }

        public string CompanyCode { get; set; }
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsDisableCompanyCode { get; set; }

        public string CompanyCAT { get; set; }
        public bool IsVisibleCompanyCAT { get; set; }
        public bool IsDisableCompanyCAT { get; set; }

        public string CompanyAddress { get; set; }
        public bool IsVisibleCompanyAddress { get; set; }
        public bool IsDisableCompanyAddress { get; set; }

        public string CompanyWard { get; set; }
        public bool IsVisibleCompanyWard { get; set; }
        public bool IsDisableCompanyWard { get; set; }

        public int? CompanyDistrictID { get; set; }
        public string CompanyDistrict { get; set; }
        public bool IsVisibleCompanyDistrict { get; set; }
        public bool IsDisableCompanyDistrict { get; set; }

        public int? CompanyCityID { get; set; }
        public string CompanyCity { get; set; }
        public bool IsVisibleCompanyCity { get; set; }
        public bool IsDisableCompanyCity { get; set; }

        public string CompanyPhone { get; set; }
        public bool IsVisibleCompanyPhone { get; set; }
        public bool IsDisableCompanyPhone { get; set; }

        public int? CompanyTypeID { get; set; }
        public string CompanyType { get; set; }
        public bool IsVisibleCompanyType { get; set; }
        public bool IsDisableCompanyType { get; set; }

        public string TaxNumber { get; set; }
        public bool IsVisibleTaxNumber { get; set; }
        public bool IsDisableTaxNumber { get; set; }

        public string BusinessRegistrationNumber { get; set; }
        public bool IsVisibleBusinessRegistrationNumber { get; set; }
        public bool IsDisableBusinessRegistrationNumber { get; set; }

        public string CompanyRemark { get; set; }
        public bool IsVisibleCompanyRemark { get; set; }
        public bool IsDisableCompanyRemark { get; set; }

        public bool IsActive { get; set; }
    }

    public class CreateNewLoanStep3DuplicateViewModel
    {
        public int? ApplicationNoDuplicateID { get; set; }
        public string ApplicationNoDuplicate { get; set; }
        public bool IsVisibleApplicationNoDuplicate { get; set; }
        public bool IsDisableApplicationNoDuplicate { get; set; }

        public int? ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public int? ApplicationStatusID { get; set; }
        public string ApplicationStatus { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public int? CustomerID { get; set; }
        public string CustomerName { get; set; }        
        public bool IsVisibleCustomerName { get; set; }
        public bool IsDisableCustomerName { get; set; }

        public Nullable<System.DateTime> ReceivingDate { get; set; }
        public bool IsVisibleReceivingDate { get; set; }
        public bool IsDisableReceivingDate { get; set; }

        public string IdentificationType { get; set; }
        public int? IdentificationTypeID { get; set; }
        public bool IsVisibleIdentificationType { get; set; }
        public bool IsDisableIdentificationType { get; set; }

        public string IdentificationNo { get; set; }
        public int? IdentificationNoID { get; set; }
        public bool IsVisibleIdentificationNo { get; set; }
        public bool IsDisableIdentificationNo { get; set; }

        public bool IsActive { get; set; }
    }
}
