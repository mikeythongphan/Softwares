﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.CreateNewLoan
{
    public class CreateNewLoanStep1ViewModel
    {
        public int? ProductTypeID { get; set; }
        public string ProductType { get; set; }
        public bool IsVisibleProductTypeID { get; set; }
        public bool IsDisableProductTypeID { get; set; }

        public int? ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationTypeID { get; set; }
        public bool IsDisableApplicationTypeID { get; set; }

        public bool IsActive { get; set; }

        private List<CreateNewLoanStep1TreeViewModel> _objCreateNewLoanStep1Tree = new List<CreateNewLoanStep1TreeViewModel>();
        public List<CreateNewLoanStep1TreeViewModel> lstCreateNewLoanStep1Tree
        {
            get
            {
                return _objCreateNewLoanStep1Tree;
            }
            set { _objCreateNewLoanStep1Tree = value; }
        }
    }

    public class CreateNewLoanStep1TreeViewModel
    {
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }

        public int? ParentID { get; set; }
        public bool IsVisibleParentID { get; set; }
        public bool IsDisableParentID { get; set; }

        public string Name { get; set; }
        public bool IsVisibleName { get; set; }
        public bool IsDisableName { get; set; }

        public bool IsActive { get; set; }
    }
}
