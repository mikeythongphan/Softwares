﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.CreditInitiative
{
    public class ApprovalInformationViewModel
    {
        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }

        public string StatusOfDecision { get; set; }
        public bool IsVisibleStatusOfDecision { get; set; }
        public bool IsDisableStatusOfDecision { get; set; }
        public int? StatusOfDecisionID { get; set; }

        public Nullable<System.DateTime> DateOfDecision { get; set; }
        public bool IsVisibleDateOfDecision { get; set; }
        public bool IsDisableDateOfDecision { get; set; }

        public string ApprovalCondition { get; set; }
        public bool IsVisibleApprovalCondition { get; set; }
        public bool IsDisableApprovalCondition { get; set; }

        public string  RejectReason { get; set; }
        public bool IsVisibleRejectReason { get; set; }
        public bool IsDisableRejectReason { get; set; }
        public int? RejectReasonID { get; set; }

        public string CancelReason { get; set; }
        public bool IsVisibleCancelReason { get; set; }
        public bool IsDisableCancelReason { get; set; }
        public int? CancelReasonID { get; set; }

        public string SendBackReason { get; set; }
        public bool IsVisibleSendBackReason { get; set; }
        public bool IsDisableSendBackReason { get; set; }
        public int? SendBackReasonID { get; set; }

        public string Remark { get; set; }
        public bool IsVisibleRemark { get; set; }
        public bool IsDisableRemark { get; set; }

        public string Deviation1 { get; set; }
        public bool IsVisibleDeviation1 { get; set; }
        public bool IsDisableDeviation1 { get; set; }
        public int? Deviation1ID { get; set; }

        public string Deviation2 { get; set; }
        public bool IsVisibleDeviation2 { get; set; }
        public bool IsDisableDeviation2 { get; set; }
        public int? Deviation2ID { get; set; }

        public string Deviation3 { get; set; }
        public bool IsVisibleDeviation3 { get; set; }
        public bool IsDisableDeviation3 { get; set; }
        public int? Deviation3ID { get; set; }

        public string ReasonForDeviation1 { get; set; }
        public bool IsVisibleReasonForDeviation1 { get; set; }
        public bool IsDisableReasonForDeviation1 { get; set; }
        public int? ReasonForDeviation1ID { get; set; }

        public string ReasonForDeviation2 { get; set; }
        public bool IsVisibleReasonForDeviation2 { get; set; }
        public bool IsDisableReasonForDeviation2 { get; set; }
        public int? ReasonForDeviation2ID { get; set; }

        public string ReasonForDeviasion3 { get; set; }
        public bool IsVisibleReasonForDeviasion3 { get; set; }
        public bool IsDisableReasonForDeviasion3 { get; set; }
        public int? ReasonForDeviasion3ID { get; set; }

        public string RemarkForDeviation1 { get; set; }
        public bool IsVisibleRemarkForDeviation1 { get; set; }
        public bool IsDisableRemarkForDeviation1 { get; set; }

        public string RemarkForDeviation2 { get; set; }
        public bool IsVisibleRemarkForDeviation2 { get; set; }
        public bool IsDisableRemarkForDeviation2 { get; set; }

        public string RemarkForDeviation3 { get; set; }
        public bool IsVisibleRemarkForDeviation3 { get; set; }
        public bool IsDisableRemarkForDeviation3 { get; set; }

        public string FinalCaseDeviation { get; set; }
        public bool IsVisibleFinalCaseDeviation { get; set; }
        public bool IsDisableFinalCaseDeviation { get; set; }
        public int? FinalCaseDeviationID { get; set; }

        public decimal? CurrentOutStandingAtSCB { get; set; }
        public bool IsVisibleCurrentOutStandingAtSCB { get; set; }
        public bool IsDisableCurrentOutStandingAtSCB { get; set; }

        public decimal? OnUsML { get; set; }
        public bool IsVisibleOnUsML { get; set; }
        public bool IsDisableOnUsML { get; set; }

        public decimal? OnUsAL { get; set; }
        public bool IsVisibleOnUsAL { get; set; }
        public bool IsDisableOnUsAL { get; set; }

        public decimal? OnUsPL { get; set; }
        public bool IsVisibleOnUsPL { get; set; }
        public bool IsDisableOnUsPL { get; set; }

        public decimal? OnUsCreditCard { get; set; }
        public bool IsVisibleOnUsCreditCard { get; set; }
        public bool IsDisableOnUsCreditCard { get; set; }

        public decimal? TotalEMIAtSCB { get; set; }
        public bool IsVisibleTotalEMIAtSCB { get; set; }
        public bool IsDisableTotalEMIAtSCB { get; set; }

        public string LoanAmountApprovedVND { get; set; }
        public bool IsVisibleLoanAmountApprovedVND { get; set; }
        public bool IsDisableLoanAmountApprovedVND { get; set; }

        public string TenorApproved { get; set; }
        public bool IsVisibleTenorApproved { get; set; }
        public bool IsDisableTenorApproved { get; set; }

        public string CommercialInterest { get; set; }
        public bool IsVisibleCommercialInterest { get; set; }
        public bool IsDisableCommercialInterest { get; set; }

        public decimal? EMIComInt { get; set; }
        public bool IsVisibleEMIComInt { get; set; }
        public bool IsDisableEMIComInt { get; set; }

        public decimal? EMI2Added { get; set; }
        public bool IsVisibleEMI2Added { get; set; }
        public bool IsDisableEMI2Added { get; set; }

        public decimal? DBR2Added { get; set; }
        public bool IsVisibleDBR2Added { get; set; }
        public bool IsDisableDBR2Added { get; set; }

        public decimal? LTV { get; set; }
        public bool IsVisibleLTV { get; set; }
        public bool IsDisableLTV { get; set; }

        public decimal? TotalExposure { get; set; }
        public bool IsVisibleTotalExposure { get; set; }
        public bool IsDisableTotalExposure { get; set; }

        public decimal? TotalEMI { get; set; }
        public bool IsVisibleTotalEMI { get; set; }
        public bool IsDisableTotalEMI { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsEnabledApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsEnabledApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
