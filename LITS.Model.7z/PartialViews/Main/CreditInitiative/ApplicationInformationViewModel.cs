﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.Main;

namespace LITS.Model.PartialViews.Main.CreditInitiative
{
    public class ApplicationInformationViewModel
    {
        public int ApplicationInformationID { get; set; }

        public int ALApplicationInformationID { get; set; }

        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsEnabledApplicationNo { get; set; }

        public string Channel { get; set; }
        public bool IsVisibleChannel { get; set; }
        public bool IsEnabledChannel { get; set; }
        public int? ChannelID { get; set; }

        public string PeoplewiseIDOfSaleStaf { get; set; }
        public bool IsVisiblePeoplewiseIDOfSaleStaf { get; set; }
        public bool IsEnabledPeoplewiseIDOfSaleStaf { get; set; }

        public string ICT { get; set; }
        public bool IsVisibleICT { get; set; }
        public bool IsEnabledICT { get; set; }

        public string Existing { get; set; }
        public bool IsVisibleExisting { get; set; }
        public bool IsEnabledExisting { get; set; }
        public bool IsExisting { get; set; }

        public Nullable<System.DateTime> HardCopyApplicationDate { get; set; }
        public bool IsVisibleHardCopyApplicationDate { get; set; }
        public bool IsEnabledHardCopyApplicationDate { get; set; }

        public string ReasonForReWork { get; set; }
        public bool IsVisibleReasonForReWork { get; set; }
        public bool IsEnabledReasonForReWork { get; set; }

        public Nullable<System.DateTime> RecevingDate { get; set; }
        public bool IsVisibleRecevingDate { get; set; }
        public bool IsEnabledRecevingDate { get; set; }

        public string ProgramType { get; set; }
        public bool IsVisibleProgramType { get; set; }
        public bool IsEnabledProgramType { get; set; }
        public int? ProgramTypeID { get; set; }

        public string SaleTMPWID { get; set; }
        public bool IsVisibleSaleTMPWID { get; set; }
        public bool IsEnabledSaleTMPWID { get; set; }

        public string CDD { get; set; }
        public bool IsVisibleCDD { get; set; }
        public bool IsEnabledCDD { get; set; }
        public int? CDDID { get; set; }

        public string SalesCode { get; set; }
        public bool IsVisibleSalesCode { get; set; }
        public bool IsEnabledSalesCode { get; set; }

        public string BranchLocation { get; set; }
        public bool IsVisibleBranchLocation { get; set; }
        public bool IsEnabledBranchLocation { get; set; }
        public int? BranchLocationID { get; set; }

        public string ARMCode { get; set; }
        public bool IsVisibleARMCode { get; set; }
        public bool IsEnabledARMCode { get; set; }

        public string ProductType { get; set; }
        public bool IsVisibleProductType { get; set; }
        public bool IsEnabledProductType { get; set; }
        public int? ProductTypeID { get; set; }

        public string CustomerType { get; set; }
        public bool IsVisibleCustomerType { get; set; }
        public bool IsEnabledCustomerType { get; set; }
        public int? CustomerTypeID { get; set; }

        public string CustomerSegment { get; set; }
        public bool IsVisibleCustomerSegment { get; set; }
        public bool IsEnabledCustomerSegment { get; set; }
        public int CustomerSegmentID { get; set; }

        public string eOpsTxnReference { get; set; }
        public bool IsVisibleeOpsTxnReference { get; set; }
        public bool IsEnabledeOpsTxnReference { get; set; }

        public string ReasonForRework { get; set; }
        public int? ReasonForReworkID { get; set; }
        public bool IsVisibleReasonForRework { get; set; }
        public bool IsEnabledReasonForRework { get; set; }

        public string Rework { get; set; }
        public bool IsRework { get; set; }
        public bool IsVisibleRework { get; set; }
        public bool IsEnabledRework { get; set; }

        private List<ApplicationDuplicationViewModel> _objApplicationDuplicationViewModel = new List<ApplicationDuplicationViewModel>();
        public List<ApplicationDuplicationViewModel> _ApplicationDuplicationViewModel
        {
            get
            {
                return _objApplicationDuplicationViewModel;
            }
            set { _objApplicationDuplicationViewModel = value; }
        }
        public bool IsVisibleApplicationDuplication { get; set; }
        public bool IsEnabledApplicationDuplication { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsEnabledApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsEnabledApplicationStatus { get; set; }
    }
}
