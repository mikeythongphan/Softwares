﻿using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Model.PartialViews.Main.WorkInProgress;

namespace LITS.Data.Repository.Main.WorkInProgress
{
    public class WorkInProgressDetailRepository : RepositoryBase<WorkInProgressDetailViewModel>, IWorkInProgressDetailRepository
    {
        public WorkInProgressDetailRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
