﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Configuration;
using LITS.Model.Views.Main;
using LITS.Interface.Repository.Main;

namespace LITS.Data.Repository.Main
{
    public class OperationSupportRepository : RepositoryBase<OperationSupportViewModel>, IOperationSupportRepository
    {
        public OperationSupportRepository (IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
