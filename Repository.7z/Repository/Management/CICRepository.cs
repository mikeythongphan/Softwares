﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class CicRepository : RepositoryBase<CicViewModel>, ICICRepository
    {
        private LITSEntities _LITSEntities;

        public CicRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_cic entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_cic entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_cic, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_cic Get(Expression<Func<m_cic, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_cic> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_cic GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_cic GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_cic> GetMany(Expression<Func<m_cic, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_cic> GetPage<TOrder>(Page page, Expression<Func<m_cic, bool>> where, Expression<Func<m_cic, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_cic entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CicViewModel> GetListActiveAll()
        {
            List<m_cic> bankHolidayList = _LITSEntities.m_cic.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<CicViewModel> resultList = new List<CicViewModel>();
            foreach (m_cic temp in bankHolidayList)
            {
                CicViewModel data = Mapper.Map<m_cic, CicViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CicViewModel> GetListActiveById(int? Id)
        {
            List<m_cic> bankHolidayList = _LITSEntities.m_cic.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CicViewModel> resultList = new List<CicViewModel>();
            foreach (m_cic temp in bankHolidayList)
            {
                CicViewModel data = Mapper.Map<m_cic, CicViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CicViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_cic> bankHolidayList = _LITSEntities.m_cic.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CicViewModel> resultList = new List<CicViewModel>();
            foreach (m_cic temp in bankHolidayList)
            {
                CicViewModel data = Mapper.Map<m_cic, CicViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CicViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_cic> bankHolidayList = _LITSEntities.m_cic.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CicViewModel> resultList = new List<CicViewModel>();
            foreach (m_cic temp in bankHolidayList)
            {
                CicViewModel data = Mapper.Map<m_cic, CicViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CicViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_cic> bankHolidayList = _LITSEntities.m_cic.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CicViewModel> resultList = new List<CicViewModel>();
            foreach (m_cic temp in bankHolidayList)
            {
                CicViewModel data = Mapper.Map<m_cic, CicViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CicViewModel> GetListAll()
        {
            List<m_cic> bankHolidayList = _LITSEntities.m_cic.ToList();
            List<CicViewModel> resultList = new List<CicViewModel>();
            foreach (m_cic temp in bankHolidayList)
            {
                CicViewModel data = Mapper.Map<m_cic, CicViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CicViewModel> GetListById(int? Id)
        {
            List<m_cic> bankHolidayList = _LITSEntities.m_cic.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<CicViewModel> resultList = new List<CicViewModel>();
            foreach (m_cic temp in bankHolidayList)
            {
                CicViewModel data = Mapper.Map<m_cic, CicViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CicViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_cic> bankHolidayList = _LITSEntities.m_cic.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CicViewModel> resultList = new List<CicViewModel>();
            foreach (m_cic temp in bankHolidayList)
            {
                CicViewModel data = Mapper.Map<m_cic, CicViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CicViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_cic> bankHolidayList = _LITSEntities.m_cic.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CicViewModel> resultList = new List<CicViewModel>();
            foreach (m_cic temp in bankHolidayList)
            {
                CicViewModel data = Mapper.Map<m_cic, CicViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CicViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_cic> bankHolidayList = _LITSEntities.m_cic.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CicViewModel> resultList = new List<CicViewModel>();
            foreach (m_cic temp in bankHolidayList)
            {
                CicViewModel data = Mapper.Map<m_cic, CicViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(CicViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CicViewModel, m_cic>(model[0]);
                            data.is_active = false;
                            context.m_cic.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(CicViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_cic data = AutoMapper.Mapper.Map<CicViewModel, m_cic>(objModel);
                        context.m_cic.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(CicViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_cic data = Mapper.Map<CicViewModel, m_cic>(objModel);
                        context.m_cic.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
