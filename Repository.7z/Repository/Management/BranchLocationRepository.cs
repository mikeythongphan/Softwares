﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class BranchLocationRepository : RepositoryBase<BranchLocationViewModel>, IBranchLocationRepository
    {
        private LITSEntities _LITSEntities;

        public BranchLocationRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_branch_location entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_branch_location entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_branch_location, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_branch_location Get(Expression<Func<m_branch_location, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_branch_location> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_branch_location GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_branch_location GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_branch_location> GetMany(Expression<Func<m_branch_location, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_branch_location> GetPage<TOrder>(Page page, Expression<Func<m_branch_location, bool>> where, Expression<Func<m_branch_location, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_branch_location entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<BranchLocationViewModel> GetListActiveAll()
        {
            List<m_branch_location> bankHolidayList = _LITSEntities.m_branch_location.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<BranchLocationViewModel> resultList = new List<BranchLocationViewModel>();
            foreach (m_branch_location temp in bankHolidayList)
            {
                BranchLocationViewModel data = Mapper.Map<m_branch_location, BranchLocationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BranchLocationViewModel> GetListActiveById(int? Id)
        {
            List<m_branch_location> bankHolidayList = _LITSEntities.m_branch_location.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<BranchLocationViewModel> resultList = new List<BranchLocationViewModel>();
            foreach (m_branch_location temp in bankHolidayList)
            {
                BranchLocationViewModel data = Mapper.Map<m_branch_location, BranchLocationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BranchLocationViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_branch_location> bankHolidayList = _LITSEntities.m_branch_location.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<BranchLocationViewModel> resultList = new List<BranchLocationViewModel>();
            foreach (m_branch_location temp in bankHolidayList)
            {
                BranchLocationViewModel data = Mapper.Map<m_branch_location, BranchLocationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BranchLocationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_branch_location> bankHolidayList = _LITSEntities.m_branch_location.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<BranchLocationViewModel> resultList = new List<BranchLocationViewModel>();
            foreach (m_branch_location temp in bankHolidayList)
            {
                BranchLocationViewModel data = Mapper.Map<m_branch_location, BranchLocationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BranchLocationViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_branch_location> bankHolidayList = _LITSEntities.m_branch_location.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<BranchLocationViewModel> resultList = new List<BranchLocationViewModel>();
            foreach (m_branch_location temp in bankHolidayList)
            {
                BranchLocationViewModel data = Mapper.Map<m_branch_location, BranchLocationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BranchLocationViewModel> GetListAll()
        {
            List<m_branch_location> bankHolidayList = _LITSEntities.m_branch_location.ToList();
            List<BranchLocationViewModel> resultList = new List<BranchLocationViewModel>();
            foreach (m_branch_location temp in bankHolidayList)
            {
                BranchLocationViewModel data = Mapper.Map<m_branch_location, BranchLocationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BranchLocationViewModel> GetListById(int? Id)
        {
            List<m_branch_location> bankHolidayList = _LITSEntities.m_branch_location.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<BranchLocationViewModel> resultList = new List<BranchLocationViewModel>();
            foreach (m_branch_location temp in bankHolidayList)
            {
                BranchLocationViewModel data = Mapper.Map<m_branch_location, BranchLocationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BranchLocationViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_branch_location> bankHolidayList = _LITSEntities.m_branch_location.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<BranchLocationViewModel> resultList = new List<BranchLocationViewModel>();
            foreach (m_branch_location temp in bankHolidayList)
            {
                BranchLocationViewModel data = Mapper.Map<m_branch_location, BranchLocationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BranchLocationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_branch_location> bankHolidayList = _LITSEntities.m_branch_location.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<BranchLocationViewModel> resultList = new List<BranchLocationViewModel>();
            foreach (m_branch_location temp in bankHolidayList)
            {
                BranchLocationViewModel data = Mapper.Map<m_branch_location, BranchLocationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BranchLocationViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_branch_location> bankHolidayList = _LITSEntities.m_branch_location.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<BranchLocationViewModel> resultList = new List<BranchLocationViewModel>();
            foreach (m_branch_location temp in bankHolidayList)
            {
                BranchLocationViewModel data = Mapper.Map<m_branch_location, BranchLocationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(BranchLocationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<BranchLocationViewModel, m_branch_location>(model[0]);
                            data.is_active = false;
                            context.m_branch_location.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(BranchLocationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_branch_location data = AutoMapper.Mapper.Map<BranchLocationViewModel, m_branch_location>(objModel);
                        context.m_branch_location.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(BranchLocationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_branch_location data = Mapper.Map<BranchLocationViewModel, m_branch_location>(objModel);
                        context.m_branch_location.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
