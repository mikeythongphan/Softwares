﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class CustodyTypeRepository : RepositoryBase<CustodyTypeViewModel>, ICustodyTypeRepository
    {
        private LITSEntities _LITSEntities;

        public CustodyTypeRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_custody_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_custody_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_custody_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_custody_type Get(Expression<Func<m_custody_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_custody_type> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_custody_type GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_custody_type GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_custody_type> GetMany(Expression<Func<m_custody_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_custody_type> GetPage<TOrder>(Page page, Expression<Func<m_custody_type, bool>> where, Expression<Func<m_custody_type, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_custody_type entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CustodyTypeViewModel> GetListActiveAll()
        {
            List<m_custody_type> bankHolidayList = _LITSEntities.m_custody_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<CustodyTypeViewModel> resultList = new List<CustodyTypeViewModel>();
            foreach (m_custody_type temp in bankHolidayList)
            {
                CustodyTypeViewModel data = Mapper.Map<m_custody_type, CustodyTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustodyTypeViewModel> GetListActiveById(int? Id)
        {
            List<m_custody_type> bankHolidayList = _LITSEntities.m_custody_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CustodyTypeViewModel> resultList = new List<CustodyTypeViewModel>();
            foreach (m_custody_type temp in bankHolidayList)
            {
                CustodyTypeViewModel data = Mapper.Map<m_custody_type, CustodyTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustodyTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_custody_type> bankHolidayList = _LITSEntities.m_custody_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CustodyTypeViewModel> resultList = new List<CustodyTypeViewModel>();
            foreach (m_custody_type temp in bankHolidayList)
            {
                CustodyTypeViewModel data = Mapper.Map<m_custody_type, CustodyTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustodyTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_custody_type> bankHolidayList = _LITSEntities.m_custody_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CustodyTypeViewModel> resultList = new List<CustodyTypeViewModel>();
            foreach (m_custody_type temp in bankHolidayList)
            {
                CustodyTypeViewModel data = Mapper.Map<m_custody_type, CustodyTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustodyTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_custody_type> bankHolidayList = _LITSEntities.m_custody_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CustodyTypeViewModel> resultList = new List<CustodyTypeViewModel>();
            foreach (m_custody_type temp in bankHolidayList)
            {
                CustodyTypeViewModel data = Mapper.Map<m_custody_type, CustodyTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustodyTypeViewModel> GetListAll()
        {
            List<m_custody_type> bankHolidayList = _LITSEntities.m_custody_type.ToList();
            List<CustodyTypeViewModel> resultList = new List<CustodyTypeViewModel>();
            foreach (m_custody_type temp in bankHolidayList)
            {
                CustodyTypeViewModel data = Mapper.Map<m_custody_type, CustodyTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustodyTypeViewModel> GetListById(int? Id)
        {
            List<m_custody_type> bankHolidayList = _LITSEntities.m_custody_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<CustodyTypeViewModel> resultList = new List<CustodyTypeViewModel>();
            foreach (m_custody_type temp in bankHolidayList)
            {
                CustodyTypeViewModel data = Mapper.Map<m_custody_type, CustodyTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustodyTypeViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_custody_type> bankHolidayList = _LITSEntities.m_custody_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CustodyTypeViewModel> resultList = new List<CustodyTypeViewModel>();
            foreach (m_custody_type temp in bankHolidayList)
            {
                CustodyTypeViewModel data = Mapper.Map<m_custody_type, CustodyTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustodyTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_custody_type> bankHolidayList = _LITSEntities.m_custody_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CustodyTypeViewModel> resultList = new List<CustodyTypeViewModel>();
            foreach (m_custody_type temp in bankHolidayList)
            {
                CustodyTypeViewModel data = Mapper.Map<m_custody_type, CustodyTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustodyTypeViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_custody_type> bankHolidayList = _LITSEntities.m_custody_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CustodyTypeViewModel> resultList = new List<CustodyTypeViewModel>();
            foreach (m_custody_type temp in bankHolidayList)
            {
                CustodyTypeViewModel data = Mapper.Map<m_custody_type, CustodyTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(CustodyTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CustodyTypeViewModel, m_custody_type>(model[0]);
                            data.is_active = false;
                            context.m_custody_type.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(CustodyTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_custody_type data = AutoMapper.Mapper.Map<CustodyTypeViewModel, m_custody_type>(objModel);
                        context.m_custody_type.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(CustodyTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_custody_type data = Mapper.Map<CustodyTypeViewModel, m_custody_type>(objModel);
                        context.m_custody_type.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
