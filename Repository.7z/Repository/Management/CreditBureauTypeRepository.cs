﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class CreditBureauTypeRepository : RepositoryBase<CreditBureauTypeViewModel>, ICreditBureauTypeRepository
    {
        private LITSEntities _LITSEntities;

        public CreditBureauTypeRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_credit_bureau_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_credit_bureau_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_credit_bureau_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_credit_bureau_type Get(Expression<Func<m_credit_bureau_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_credit_bureau_type> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_credit_bureau_type GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_credit_bureau_type GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_credit_bureau_type> GetMany(Expression<Func<m_credit_bureau_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_credit_bureau_type> GetPage<TOrder>(Page page, Expression<Func<m_credit_bureau_type, bool>> where, Expression<Func<m_credit_bureau_type, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_credit_bureau_type entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CreditBureauTypeViewModel> GetListActiveAll()
        {
            List<m_credit_bureau_type> bankHolidayList = _LITSEntities.m_credit_bureau_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<CreditBureauTypeViewModel> resultList = new List<CreditBureauTypeViewModel>();
            foreach (m_credit_bureau_type temp in bankHolidayList)
            {
                CreditBureauTypeViewModel data = Mapper.Map<m_credit_bureau_type, CreditBureauTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditBureauTypeViewModel> GetListActiveById(int? Id)
        {
            List<m_credit_bureau_type> bankHolidayList = _LITSEntities.m_credit_bureau_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CreditBureauTypeViewModel> resultList = new List<CreditBureauTypeViewModel>();
            foreach (m_credit_bureau_type temp in bankHolidayList)
            {
                CreditBureauTypeViewModel data = Mapper.Map<m_credit_bureau_type, CreditBureauTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditBureauTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_credit_bureau_type> bankHolidayList = _LITSEntities.m_credit_bureau_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CreditBureauTypeViewModel> resultList = new List<CreditBureauTypeViewModel>();
            foreach (m_credit_bureau_type temp in bankHolidayList)
            {
                CreditBureauTypeViewModel data = Mapper.Map<m_credit_bureau_type, CreditBureauTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditBureauTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_credit_bureau_type> bankHolidayList = _LITSEntities.m_credit_bureau_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CreditBureauTypeViewModel> resultList = new List<CreditBureauTypeViewModel>();
            foreach (m_credit_bureau_type temp in bankHolidayList)
            {
                CreditBureauTypeViewModel data = Mapper.Map<m_credit_bureau_type, CreditBureauTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditBureauTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_credit_bureau_type> bankHolidayList = _LITSEntities.m_credit_bureau_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CreditBureauTypeViewModel> resultList = new List<CreditBureauTypeViewModel>();
            foreach (m_credit_bureau_type temp in bankHolidayList)
            {
                CreditBureauTypeViewModel data = Mapper.Map<m_credit_bureau_type, CreditBureauTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditBureauTypeViewModel> GetListAll()
        {
            List<m_credit_bureau_type> bankHolidayList = _LITSEntities.m_credit_bureau_type.ToList();
            List<CreditBureauTypeViewModel> resultList = new List<CreditBureauTypeViewModel>();
            foreach (m_credit_bureau_type temp in bankHolidayList)
            {
                CreditBureauTypeViewModel data = Mapper.Map<m_credit_bureau_type, CreditBureauTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditBureauTypeViewModel> GetListById(int? Id)
        {
            List<m_credit_bureau_type> bankHolidayList = _LITSEntities.m_credit_bureau_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<CreditBureauTypeViewModel> resultList = new List<CreditBureauTypeViewModel>();
            foreach (m_credit_bureau_type temp in bankHolidayList)
            {
                CreditBureauTypeViewModel data = Mapper.Map<m_credit_bureau_type, CreditBureauTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditBureauTypeViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_credit_bureau_type> bankHolidayList = _LITSEntities.m_credit_bureau_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CreditBureauTypeViewModel> resultList = new List<CreditBureauTypeViewModel>();
            foreach (m_credit_bureau_type temp in bankHolidayList)
            {
                CreditBureauTypeViewModel data = Mapper.Map<m_credit_bureau_type, CreditBureauTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditBureauTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_credit_bureau_type> bankHolidayList = _LITSEntities.m_credit_bureau_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CreditBureauTypeViewModel> resultList = new List<CreditBureauTypeViewModel>();
            foreach (m_credit_bureau_type temp in bankHolidayList)
            {
                CreditBureauTypeViewModel data = Mapper.Map<m_credit_bureau_type, CreditBureauTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditBureauTypeViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_credit_bureau_type> bankHolidayList = _LITSEntities.m_credit_bureau_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CreditBureauTypeViewModel> resultList = new List<CreditBureauTypeViewModel>();
            foreach (m_credit_bureau_type temp in bankHolidayList)
            {
                CreditBureauTypeViewModel data = Mapper.Map<m_credit_bureau_type, CreditBureauTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(CreditBureauTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CreditBureauTypeViewModel, m_credit_bureau_type>(model[0]);
                            data.is_active = false;
                            context.m_credit_bureau_type.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(CreditBureauTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_credit_bureau_type data = AutoMapper.Mapper.Map<CreditBureauTypeViewModel, m_credit_bureau_type>(objModel);
                        context.m_credit_bureau_type.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(CreditBureauTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_credit_bureau_type data = Mapper.Map<CreditBureauTypeViewModel, m_credit_bureau_type>(objModel);
                        context.m_credit_bureau_type.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
