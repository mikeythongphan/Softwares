﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class BankTypeRepository : RepositoryBase<BankTypeViewModel>, IBankTypeRepository
    {
        private LITSEntities _LITSEntities;

        public BankTypeRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_bank_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_bank_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_bank_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_bank_type Get(Expression<Func<m_bank_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_bank_type> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_bank_type GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_bank_type GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_bank_type> GetMany(Expression<Func<m_bank_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_bank_type> GetPage<TOrder>(Page page, Expression<Func<m_bank_type, bool>> where, Expression<Func<m_bank_type, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_bank_type entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<BankTypeViewModel> GetListActiveAll()
        {
            List<m_bank_type> BankTypeList = _LITSEntities.m_bank_type.ToList();
            BankTypeList = BankTypeList.Where(p => p.is_active == true).ToList();
            List<BankTypeViewModel> resultList = new List<BankTypeViewModel>();
            foreach (m_bank_type temp in BankTypeList)
            {
                BankTypeViewModel data = Mapper.Map<m_bank_type, BankTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankTypeViewModel> GetListActiveById(int? Id)
        {
            List<m_bank_type> BankTypeList = _LITSEntities.m_bank_type.ToList();
            BankTypeList = BankTypeList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<BankTypeViewModel> resultList = new List<BankTypeViewModel>();
            foreach (m_bank_type temp in BankTypeList)
            {
                BankTypeViewModel data = Mapper.Map<m_bank_type, BankTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_bank_type> BankTypeList = _LITSEntities.m_bank_type.ToList();
            BankTypeList = BankTypeList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<BankTypeViewModel> resultList = new List<BankTypeViewModel>();
            foreach (m_bank_type temp in BankTypeList)
            {
                BankTypeViewModel data = Mapper.Map<m_bank_type, BankTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId )
        {
            List<m_bank_type> BankTypeList = _LITSEntities.m_bank_type.ToList();
            BankTypeList = BankTypeList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<BankTypeViewModel> resultList = new List<BankTypeViewModel>();
            foreach (m_bank_type temp in BankTypeList)
            {
                BankTypeViewModel data = Mapper.Map<m_bank_type, BankTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankTypeViewModel> GetListActiveByTypeId(int? TypeId )
        {
            List<m_bank_type> BankTypeList = _LITSEntities.m_bank_type.ToList();
            BankTypeList = BankTypeList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<BankTypeViewModel> resultList = new List<BankTypeViewModel>();
            foreach (m_bank_type temp in BankTypeList)
            {
                BankTypeViewModel data = Mapper.Map<m_bank_type, BankTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankTypeViewModel> GetListAll()
        {
            List<m_bank_type> BankTypeList = _LITSEntities.m_bank_type.ToList();
            List<BankTypeViewModel> resultList = new List<BankTypeViewModel>();
            foreach (m_bank_type temp in BankTypeList)
            {
                BankTypeViewModel data = Mapper.Map<m_bank_type, BankTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankTypeViewModel> GetListById(int? Id)
        {
            List<m_bank_type> BankTypeList = _LITSEntities.m_bank_type.ToList();
            BankTypeList = BankTypeList.Where(p => p.pk_id == Id).ToList();
            List<BankTypeViewModel> resultList = new List<BankTypeViewModel>();
            foreach (m_bank_type temp in BankTypeList)
            {
                BankTypeViewModel data = Mapper.Map<m_bank_type, BankTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankTypeViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_bank_type> BankTypeList = _LITSEntities.m_bank_type.ToList();
            BankTypeList = BankTypeList.Where(p => p.fk_status_id == StatusId).ToList();
            List<BankTypeViewModel> resultList = new List<BankTypeViewModel>();
            foreach (m_bank_type temp in BankTypeList)
            {
                BankTypeViewModel data = Mapper.Map<m_bank_type, BankTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId )
        {
            List<m_bank_type> BankTypeList = _LITSEntities.m_bank_type.ToList();
            BankTypeList = BankTypeList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<BankTypeViewModel> resultList = new List<BankTypeViewModel>();
            foreach (m_bank_type temp in BankTypeList)
            {
                BankTypeViewModel data = Mapper.Map<m_bank_type, BankTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankTypeViewModel> GetListByTypeId(int? TypeId )
        {
            List<m_bank_type> BankTypeList = _LITSEntities.m_bank_type.ToList();
            BankTypeList = BankTypeList.Where(p => p.fk_type_id == TypeId).ToList();
            List<BankTypeViewModel> resultList = new List<BankTypeViewModel>();
            foreach (m_bank_type temp in BankTypeList)
            {
                BankTypeViewModel data = Mapper.Map<m_bank_type, BankTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(BankTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<BankTypeViewModel, m_bank_type>(model[0]);
                            data.is_active = false;
                            context.m_bank_type.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(BankTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_bank_type data = AutoMapper.Mapper.Map<BankTypeViewModel, m_bank_type>(objModel);
                        context.m_bank_type.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }        

        public bool Update(BankTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_bank_type data = Mapper.Map<BankTypeViewModel, m_bank_type>(objModel);
                        context.m_bank_type.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
