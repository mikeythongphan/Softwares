﻿
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.LendingOperation;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;

namespace LITS.Data.Repository.AutoLoan.LendingOperation
{
    public class PostDisbursementConditionRepository : RepositoryBase<PostDisbursementConditionViewModel>, IPostDisbursementConditionRepository
    {
        public PostDisbursementConditionRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

    }
}
