﻿using System;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using PagedList;
using System.Linq.Expressions;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class AppliedLoanInformationRepository : RepositoryBase<AppliedLoanInformationViewModel>, IAppliedLoanInformationRepository
    {
        public AppliedLoanInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        public void Add(Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel Get(Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel> GetMany(Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel, bool>> where, Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        IEnumerable<Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel> IRepository<Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel>.GetAll()
        {
            throw new NotImplementedException();
        }

        Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel IRepository<Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel>.GetById(long id)
        {
            throw new NotImplementedException();
        }

        Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel IRepository<Model.PartialViews.AutoLoan.OperationSupport.AppliedLoanInformationViewModel>.GetById(string id)
        {
            throw new NotImplementedException();
        }
    }
}
