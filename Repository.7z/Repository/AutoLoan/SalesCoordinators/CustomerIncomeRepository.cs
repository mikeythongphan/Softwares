﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CustomerIncomeRepository : RepositoryBase<CustomerIncomeViewModel>, ICustomerIncomeRepository
    {
        public CustomerIncomeRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
