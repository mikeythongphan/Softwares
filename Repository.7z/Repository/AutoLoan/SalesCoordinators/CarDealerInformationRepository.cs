﻿using System;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using PagedList;
using System.Linq.Expressions;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CarDealerInformationRepository : RepositoryBase<CarDealerInformationViewModel>, ICarDealerInformationRepository
    {
        public CarDealerInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        public void Add(Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel Get(Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel> GetMany(Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel, bool>> where, Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        IEnumerable<Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel> IRepository<Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel>.GetAll()
        {
            throw new NotImplementedException();
        }

        Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel IRepository<Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel>.GetById(long id)
        {
            throw new NotImplementedException();
        }

        Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel IRepository<Model.PartialViews.AutoLoan.OperationSupport.CarDealerInformationViewModel>.GetById(string id)
        {
            throw new NotImplementedException();
        }
    }
}
