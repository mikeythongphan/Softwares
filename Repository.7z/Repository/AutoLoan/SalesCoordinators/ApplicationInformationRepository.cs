﻿using System;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using PagedList;
using System.Linq.Expressions;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class ApplicationInformationRepository : RepositoryBase<ApplicationInformationViewModel>,IApplicationInformationRepository
    {
        public ApplicationInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        public void Add(Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel Get(Expression<Func<Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel> GetMany(Expression<Func<Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel, bool>> where, Expression<Func<Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }
    }
}
