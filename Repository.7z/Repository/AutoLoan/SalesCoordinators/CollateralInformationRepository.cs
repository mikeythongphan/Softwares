﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using PagedList;
using System.Linq.Expressions;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CollateralInformationRepository : RepositoryBase<CollateralInformationViewModel>, ICollateralInformationRepository
    {
        public CollateralInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        public void Add(Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel Get(Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel> GetMany(Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel, bool>> where, Expression<Func<Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        IEnumerable<Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel> IRepository<Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel>.GetAll()
        {
            throw new NotImplementedException();
        }

        Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel IRepository<Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel>.GetById(long id)
        {
            throw new NotImplementedException();
        }

        Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel IRepository<Model.PartialViews.AutoLoan.OperationSupport.CollateralInformationViewModel>.GetById(string id)
        {
            throw new NotImplementedException();
        }
    }
}
