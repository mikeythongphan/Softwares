﻿using System;
using System.Collections.Generic;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using LITS.Core.Main;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class OperationSupportRepository : RepositoryBase<SalesCoordinatorsViewModel>, IOperationSupportRepository
    {
        private LITSEntities _LITSEntities;

        public OperationSupportRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }
    }
}
