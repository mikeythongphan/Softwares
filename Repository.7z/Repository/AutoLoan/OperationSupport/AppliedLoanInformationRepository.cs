﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using LITS.Interface.Repository.AutoLoan.OperationSupport;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class AppliedLoanInformationRepository : RepositoryBase<AppliedLoanInformationViewModel>, IAppliedLoanInformationRepository
    {
        public AppliedLoanInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
