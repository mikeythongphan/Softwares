﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using PagedList;
using System.Linq.Expressions;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class CustomerInformationRepository : RepositoryBase<CustomerInformationViewModel>, ICustomerInformationRepository
    {
        public CustomerInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        public void Add(ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public ApplicationInformationViewModel Get(Expression<Func<ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<ApplicationInformationViewModel> GetMany(Expression<Func<ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<ApplicationInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<ApplicationInformationViewModel, bool>> where, Expression<Func<ApplicationInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

    }
}
