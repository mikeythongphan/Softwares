﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using LITS.Interface.Repository.AutoLoan.OperationSupport;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class CustomerCreditBureauRepository : RepositoryBase<CustomerCreditBureauViewModel>, ICustomerCreditBureauRepository
    {
        public CustomerCreditBureauRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

      
    }
}
