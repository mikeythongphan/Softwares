﻿using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class ApplicationInformationRepository : RepositoryBase<ApplicationInformationViewModel>, IApplicationInformationRepository
    {
        public ApplicationInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

    }
}
