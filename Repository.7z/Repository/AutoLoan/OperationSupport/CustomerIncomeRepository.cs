﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using LITS.Interface.Repository.AutoLoan.OperationSupport;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class CustomerIncomeRepository : RepositoryBase<CustomerIncomeViewModel>, ICustomerIncomeRepository
    {
        public CustomerIncomeRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
