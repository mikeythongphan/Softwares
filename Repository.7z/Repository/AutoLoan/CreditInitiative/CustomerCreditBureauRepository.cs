﻿
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Data.Repository.AutoLoan.CreditInitiative
{
    public class CustomerCreditBureauRepository : RepositoryBase<CustomerCreditBureauViewModel>, ICustomerCreditBureauRepository
    {
        public CustomerCreditBureauRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

    }
}
