﻿
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Data.Repository.AutoLoan.CreditInitiative
{
    public class ARTARepository : RepositoryBase<ARTAViewModel>, IARTARepository
    {
        public ARTARepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

    }
}
