﻿
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Data.Repository.AutoLoan.CreditInitiative
{
    public class CustomerInformationRepository : RepositoryBase<CustomerInformationViewModel>, ICustomerInformationRepository
    {
        public CustomerInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

    }
}
