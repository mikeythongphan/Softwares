﻿
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Data.Repository.AutoLoan.CreditInitiative
{
    public class ApprovalInformationRepository : RepositoryBase<ApprovalInformationViewModel>, IApprovalInformationRepository
    {
        public ApprovalInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

    }
}
