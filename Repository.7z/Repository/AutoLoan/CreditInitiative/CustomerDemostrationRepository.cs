﻿
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Data.Repository.AutoLoan.CreditInitiative
{
    public class CustomerDemostrationRepository : RepositoryBase<CustomerDemostrationViewModel>, ICustomerDemostrationRepository
    {
        public CustomerDemostrationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

    }
}
