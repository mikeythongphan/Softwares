﻿
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Data.Repository.AutoLoan.CreditInitiative
{
    public class AppliedLoanInformationRepository : RepositoryBase<AppliedLoanInformationViewModel>, IAppliedLoanInformationRepository
    {
        public AppliedLoanInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

    }
}
