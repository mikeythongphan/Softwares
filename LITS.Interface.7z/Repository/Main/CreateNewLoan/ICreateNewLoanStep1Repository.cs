﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.Main.CreateNewLoan;
using LITS.Model.Views.Main;

namespace LITS.Interface.Repository.Main.CreateNewLoan
{
    public interface ICreateNewLoanStep1Repository : IRepository<CreateNewLoanStep1ViewModel>
    {
    }
}
