﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Model.Views.Main;

namespace LITS.Interface.Repository.Main
{
    public interface ICreditInitiativeRepository : IRepository<CreditInitiativeViewModel>
    {
    }
}
