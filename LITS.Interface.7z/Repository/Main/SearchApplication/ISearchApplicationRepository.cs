﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.Views.Main;

namespace LITS.Interface.Repository.Main.SearchApplication
{
    public interface ISearchApplicationRepository : IRepository<WorkInProgressViewModel>
    {
        WorkInProgressViewModel SearchData(WorkInProgressViewModel obj, string strAreaName, string strControllerName);

        WorkInProgressViewModel LoadChildDetail(int appId, string strAreaName, string strControllerName);
    }
}
