﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.Main.SalesCoordinators;

namespace LITS.Interface.Repository.Main.SalesCoordinators
{
    public interface IApplicationInformationRepository : IRepository<ApplicationInformationViewModel>
    {}
}
