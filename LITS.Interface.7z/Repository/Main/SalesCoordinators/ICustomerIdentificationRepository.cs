﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Main.SalesCoordinators
{
    public interface ICustomerIdentificationRepository : IRepository<customer_identification>
    {}
}
