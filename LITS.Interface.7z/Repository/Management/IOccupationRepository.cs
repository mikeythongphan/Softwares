﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IOccupationRepository : IRepository<m_occupation>
    {
        List<OccupationViewModel> GetListAll();

        List<OccupationViewModel> GetListById(int? Id);

        List<OccupationViewModel> GetListByStatusId(int? StatusId);

        List<OccupationViewModel> GetListByTypeId(int? TypeId);

        List<OccupationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<OccupationViewModel> GetListActiveAll();

        List<OccupationViewModel> GetListActiveById(int? Id);

        List<OccupationViewModel> GetListActiveByStatusId(int? StatusId);

        List<OccupationViewModel> GetListActiveByTypeId(int? TypeId);

        List<OccupationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(OccupationViewModel objModel);

        bool Update(OccupationViewModel objModel);

        bool Delete(OccupationViewModel objModel);
    }
}
