﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ICurrentResidentTypeRepository : IRepository<m_current_resident_type>
    {
        List<CurrentResidentTypeViewModel> GetListAll();

        List<CurrentResidentTypeViewModel> GetListById(int? Id);

        List<CurrentResidentTypeViewModel> GetListByStatusId(int? StatusId);

        List<CurrentResidentTypeViewModel> GetListByTypeId(int? TypeId);

        List<CurrentResidentTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CurrentResidentTypeViewModel> GetListActiveAll();

        List<CurrentResidentTypeViewModel> GetListActiveById(int? Id);

        List<CurrentResidentTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<CurrentResidentTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<CurrentResidentTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CurrentResidentTypeViewModel objModel);

        bool Update(CurrentResidentTypeViewModel objModel);

        bool Delete(CurrentResidentTypeViewModel objModel);
    }
}
