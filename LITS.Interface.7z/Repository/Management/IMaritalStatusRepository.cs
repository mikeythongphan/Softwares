﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IMaritalStatusRepository : IRepository<m_marital_status>
    {
        List<MaritalStatusViewModel> GetListAll();

        List<MaritalStatusViewModel> GetListById(int? Id);

        List<MaritalStatusViewModel> GetListByStatusId(int? StatusId);

        List<MaritalStatusViewModel> GetListByTypeId(int? TypeId);

        List<MaritalStatusViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<MaritalStatusViewModel> GetListActiveAll();

        List<MaritalStatusViewModel> GetListActiveById(int? Id);

        List<MaritalStatusViewModel> GetListActiveByStatusId(int? StatusId);

        List<MaritalStatusViewModel> GetListActiveByTypeId(int? TypeId);

        List<MaritalStatusViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(MaritalStatusViewModel objModel);

        bool Update(MaritalStatusViewModel objModel);

        bool Delete(MaritalStatusViewModel objModel);
    }
}
