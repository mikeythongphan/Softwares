﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IBranchLocationRepository : IRepository<m_branch_location>
    {
        List<BranchLocationViewModel> GetListAll();

        List<BranchLocationViewModel> GetListById(int? Id);

        List<BranchLocationViewModel> GetListByStatusId(int? StatusId);

        List<BranchLocationViewModel> GetListByTypeId(int? TypeId);

        List<BranchLocationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<BranchLocationViewModel> GetListActiveAll();

        List<BranchLocationViewModel> GetListActiveById(int? Id);

        List<BranchLocationViewModel> GetListActiveByStatusId(int? StatusId);

        List<BranchLocationViewModel> GetListActiveByTypeId(int? TypeId);

        List<BranchLocationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(BranchLocationViewModel objModel);

        bool Update(BranchLocationViewModel objModel);

        bool Delete(BranchLocationViewModel objModel);
    }
}
