﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ICityRepository : IRepository<m_city>
    {
        List<CityViewModel> GetListAll();

        List<CityViewModel> GetListById(int? Id);

        List<CityViewModel> GetListByStatusId(int? StatusId);

        List<CityViewModel> GetListByTypeId(int? TypeId);

        List<CityViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CityViewModel> GetListActiveAll();

        List<CityViewModel> GetListActiveById(int? Id);

        List<CityViewModel> GetListActiveByStatusId(int? StatusId);

        List<CityViewModel> GetListActiveByTypeId(int? TypeId);

        List<CityViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CityViewModel objModel);

        bool Update(CityViewModel objModel);

        bool Delete(CityViewModel objModel);
    }
}
