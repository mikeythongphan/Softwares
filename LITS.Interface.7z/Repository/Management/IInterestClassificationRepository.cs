﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IInterestClassificationRepository : IRepository<m_interest_classification>
    {
        List<InterestClassificationViewModel> GetListAll();

        List<InterestClassificationViewModel> GetListById(int? Id);

        List<InterestClassificationViewModel> GetListByStatusId(int? StatusId);

        List<InterestClassificationViewModel> GetListByTypeId(int? TypeId);

        List<InterestClassificationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<InterestClassificationViewModel> GetListActiveAll();

        List<InterestClassificationViewModel> GetListActiveById(int? Id);

        List<InterestClassificationViewModel> GetListActiveByStatusId(int? StatusId);

        List<InterestClassificationViewModel> GetListActiveByTypeId(int? TypeId);

        List<InterestClassificationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(InterestClassificationViewModel objModel);

        bool Update(InterestClassificationViewModel objModel);

        bool Delete(InterestClassificationViewModel objModel);
    }
}
