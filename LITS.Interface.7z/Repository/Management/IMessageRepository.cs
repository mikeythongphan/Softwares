﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IMessageRepository : IRepository<m_message>
    {
        List<MessageViewModel> GetListAll();

        List<MessageViewModel> GetListById(int? Id);

        List<MessageViewModel> GetListByStatusId(int? StatusId);

        List<MessageViewModel> GetListByTypeId(int? TypeId);

        List<MessageViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<MessageViewModel> GetListActiveAll();

        List<MessageViewModel> GetListActiveById(int? Id);

        List<MessageViewModel> GetListActiveByStatusId(int? StatusId);

        List<MessageViewModel> GetListActiveByTypeId(int? TypeId);

        List<MessageViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(MessageViewModel objModel);

        bool Update(MessageViewModel objModel);

        bool Delete(MessageViewModel objModel);
    }
}
