﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IBankTypeRepository : IRepository<m_bank_type>
    {
        List<BankTypeViewModel> GetListAll();

        List<BankTypeViewModel> GetListById(int? Id);

        List<BankTypeViewModel> GetListByStatusId(int? StatusId);

        List<BankTypeViewModel> GetListByTypeId(int? TypeId);

        List<BankTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<BankTypeViewModel> GetListActiveAll();

        List<BankTypeViewModel> GetListActiveById(int? Id);

        List<BankTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<BankTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<BankTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(BankTypeViewModel objModel);

        bool Update(BankTypeViewModel objModel);

        bool Delete(BankTypeViewModel objModel);
    }
}
