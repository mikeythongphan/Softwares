﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IPropertyTypeRepository : IRepository<m_property_type>
    {
        List<PropertyTypeViewModel> GetListAll();

        List<PropertyTypeViewModel> GetListById(int? Id);

        List<PropertyTypeViewModel> GetListByStatusId(int? StatusId);

        List<PropertyTypeViewModel> GetListByTypeId(int? TypeId);

        List<PropertyTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<PropertyTypeViewModel> GetListActiveAll();

        List<PropertyTypeViewModel> GetListActiveById(int? Id);

        List<PropertyTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<PropertyTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<PropertyTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(PropertyTypeViewModel objModel);

        bool Update(PropertyTypeViewModel objModel);

        bool Delete(PropertyTypeViewModel objModel);
    }
}
