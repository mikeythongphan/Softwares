﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IBankHolidayRepository : IRepository<m_bank_holiday>
    {
        List<BankHolidayViewModel> GetListAll();

        List<BankHolidayViewModel> GetListById(int? Id);

        List<BankHolidayViewModel> GetListByStatusId(int? StatusId);

        List<BankHolidayViewModel> GetListByTypeId(int? TypeId);

        List<BankHolidayViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<BankHolidayViewModel> GetListActiveAll();

        List<BankHolidayViewModel> GetListActiveById(int? Id);

        List<BankHolidayViewModel> GetListActiveByStatusId(int? StatusId);

        List<BankHolidayViewModel> GetListActiveByTypeId(int? TypeId);

        List<BankHolidayViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(BankHolidayViewModel objModel);

        bool Update(BankHolidayViewModel objModel);

        bool Delete(BankHolidayViewModel objModel);
    }
}
