﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ICriteriaRepository : IRepository<m_criteria>
    {
        List<CriteriaViewModel> GetListAll();

        List<CriteriaViewModel> GetListById(int? Id);

        List<CriteriaViewModel> GetListByStatusId(int? StatusId);

        List<CriteriaViewModel> GetListByTypeId(int? TypeId);

        List<CriteriaViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CriteriaViewModel> GetListActiveAll();

        List<CriteriaViewModel> GetListActiveById(int? Id);

        List<CriteriaViewModel> GetListActiveByStatusId(int? StatusId);

        List<CriteriaViewModel> GetListActiveByTypeId(int? TypeId);

        List<CriteriaViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CriteriaViewModel objModel);

        bool Update(CriteriaViewModel objModel);

        bool Delete(CriteriaViewModel objModel);
    }
}
