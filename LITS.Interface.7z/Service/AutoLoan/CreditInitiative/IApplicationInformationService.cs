﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.CreditInitiative
{
    public interface IApplicationInformationService
    {
        ApplicationInformationViewModel GetById(int? Id);

        ApplicationInformationViewModel GetAll();

        application_information GetApplicationInformation(int? Id);

        void Create(ApplicationInformationViewModel obj);

        void Delete(ApplicationInformationViewModel obj);

        void Update(ApplicationInformationViewModel obj);
    }
}
