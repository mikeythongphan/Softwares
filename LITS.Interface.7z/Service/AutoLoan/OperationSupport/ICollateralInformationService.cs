﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.OperationSupport
{
    public interface ICollateralInformationService
    {
        CollateralInformationViewModel GetById(int? Id);

        CollateralInformationViewModel GetAll();

       // application_information GetApplicationInformation(int? Id);        

        void Create(CollateralInformationViewModel obj);

        void Delete(CollateralInformationViewModel obj);

        void Save();
    }
}
