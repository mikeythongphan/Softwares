﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IDisbursalScenarioService
    {
        List<DisbursalScenarioViewModel> GetListAll();

        List<DisbursalScenarioViewModel> GetListById(int? Id);

        List<DisbursalScenarioViewModel> GetListByStatusId(int? StatusId);

        List<DisbursalScenarioViewModel> GetListByTypeId(int? TypeId);

        List<DisbursalScenarioViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<DisbursalScenarioViewModel> GetListActiveAll();

        List<DisbursalScenarioViewModel> GetListActiveById(int? Id);

        List<DisbursalScenarioViewModel> GetListActiveByStatusId(int? StatusId);

        List<DisbursalScenarioViewModel> GetListActiveByTypeId(int? TypeId);

        List<DisbursalScenarioViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(DisbursalScenarioViewModel objModel);

        bool Update(DisbursalScenarioViewModel objModel);

        bool Delete(DisbursalScenarioViewModel objModel);
    }
}
