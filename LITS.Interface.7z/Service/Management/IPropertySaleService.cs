﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface IPropertySaleService
    {
        List<PropertySaleViewModel> GetListAll();

        List<PropertySaleViewModel> GetListById(int? Id);

        List<PropertySaleViewModel> GetListByStatusId(int? StatusId);

        List<PropertySaleViewModel> GetListByTypeId(int? TypeId);

        List<PropertySaleViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<PropertySaleViewModel> GetListActiveAll();

        List<PropertySaleViewModel> GetListActiveById(int? Id);

        List<PropertySaleViewModel> GetListActiveByStatusId(int? StatusId);

        List<PropertySaleViewModel> GetListActiveByTypeId(int? TypeId);

        List<PropertySaleViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(PropertySaleViewModel objModel);

        bool Update(PropertySaleViewModel objModel);

        bool Delete(PropertySaleViewModel objModel);
    }
}
