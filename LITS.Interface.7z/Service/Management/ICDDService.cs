﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface ICDDService
    {
        List<CDDViewModel> GetListAll();

        List<CDDViewModel> GetListById(int? Id);

        List<CDDViewModel> GetListByStatusId(int? StatusId);

        List<CDDViewModel> GetListByTypeId(int? TypeId);

        List<CDDViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CDDViewModel> GetListActiveAll();

        List<CDDViewModel> GetListActiveById(int? Id);

        List<CDDViewModel> GetListActiveByStatusId(int? StatusId);

        List<CDDViewModel> GetListActiveByTypeId(int? TypeId);

        List<CDDViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CDDViewModel objModel);

        bool Update(CDDViewModel objModel);

        bool Delete(CDDViewModel objModel);
    }
}
