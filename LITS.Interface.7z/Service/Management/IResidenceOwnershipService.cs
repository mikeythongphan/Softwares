﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IResidenceOwnershipService
    {
        List<ResidenceOwnershipViewModel> GetListAll();

        List<ResidenceOwnershipViewModel> GetListById(int? Id);

        List<ResidenceOwnershipViewModel> GetListByStatusId(int? StatusId);

        List<ResidenceOwnershipViewModel> GetListByTypeId(int? TypeId);

        List<ResidenceOwnershipViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<ResidenceOwnershipViewModel> GetListActiveAll();

        List<ResidenceOwnershipViewModel> GetListActiveById(int? Id);

        List<ResidenceOwnershipViewModel> GetListActiveByStatusId(int? StatusId);

        List<ResidenceOwnershipViewModel> GetListActiveByTypeId(int? TypeId);

        List<ResidenceOwnershipViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(ResidenceOwnershipViewModel objModel);

        bool Update(ResidenceOwnershipViewModel objModel);

        bool Delete(ResidenceOwnershipViewModel objModel);
    }
}
