﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface ICustomerRelationshipService
    {
        List<CustomerRelationshipViewModel> GetListAll();

        List<CustomerRelationshipViewModel> GetListById(int? Id);

        List<CustomerRelationshipViewModel> GetListByStatusId(int? StatusId);

        List<CustomerRelationshipViewModel> GetListByTypeId(int? TypeId);

        List<CustomerRelationshipViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CustomerRelationshipViewModel> GetListActiveAll();

        List<CustomerRelationshipViewModel> GetListActiveById(int? Id);

        List<CustomerRelationshipViewModel> GetListActiveByStatusId(int? StatusId);

        List<CustomerRelationshipViewModel> GetListActiveByTypeId(int? TypeId);

        List<CustomerRelationshipViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CustomerRelationshipViewModel objModel);

        bool Update(CustomerRelationshipViewModel objModel);

        bool Delete(CustomerRelationshipViewModel objModel);
    }
}
