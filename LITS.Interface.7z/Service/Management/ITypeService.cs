﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface ITypeService
    {
        List<TypeViewModel> GetListAll();

        List<TypeViewModel> GetListById(int? Id);

        List<TypeViewModel> GetListByParentId(int? ParentId);

        List<TypeViewModel> GetListActiveAll();

        List<TypeViewModel> GetListActiveById(int? Id);

        List<TypeViewModel> GetListActiveByParentId(int? ParentId);

        bool Create(TypeViewModel objModel);

        bool Update(TypeViewModel objModel);

        bool Delete(TypeViewModel objModel);
    }
}
