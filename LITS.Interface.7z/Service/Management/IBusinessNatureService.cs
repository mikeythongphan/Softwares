﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface IBusinessNatureService
    {
        List<BusinessNatureViewModel> GetListAll();

        List<BusinessNatureViewModel> GetListById(int? Id);

        List<BusinessNatureViewModel> GetListByStatusId(int? StatusId);

        List<BusinessNatureViewModel> GetListByTypeId(int? TypeId);

        List<BusinessNatureViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<BusinessNatureViewModel> GetListActiveAll();

        List<BusinessNatureViewModel> GetListActiveById(int? Id);

        List<BusinessNatureViewModel> GetListActiveByStatusId(int? StatusId);

        List<BusinessNatureViewModel> GetListActiveByTypeId(int? TypeId);

        List<BusinessNatureViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(BusinessNatureViewModel objModel);

        bool Update(BusinessNatureViewModel objModel);

        bool Delete(BusinessNatureViewModel objModel);
    }
}
