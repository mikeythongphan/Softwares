﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface IStatusService
    {
        List<StatusViewModel> GetListAll();

        List<StatusViewModel> GetListById(int? Id);

        List<StatusViewModel> GetListByStatusId(int? StatusId);

        List<StatusViewModel> GetListByTypeId(int? TypeId);

        List<StatusViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<StatusViewModel> GetListActiveAll();

        List<StatusViewModel> GetListActiveById(int? Id);

        List<StatusViewModel> GetListActiveByStatusId(int? StatusId);

        List<StatusViewModel> GetListActiveByTypeId(int? TypeId);

        List<StatusViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(StatusViewModel objModel);

        bool Update(StatusViewModel objModel);

        bool Delete(StatusViewModel objModel);
    }
}
