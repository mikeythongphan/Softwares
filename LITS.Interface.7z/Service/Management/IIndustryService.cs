﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IIndustryService
    {
        List<IndustryViewModel> GetListAll();

        List<IndustryViewModel> GetListById(int? Id);

        List<IndustryViewModel> GetListByStatusId(int? StatusId);

        List<IndustryViewModel> GetListByTypeId(int? TypeId);

        List<IndustryViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<IndustryViewModel> GetListActiveAll();

        List<IndustryViewModel> GetListActiveById(int? Id);

        List<IndustryViewModel> GetListActiveByStatusId(int? StatusId);

        List<IndustryViewModel> GetListActiveByTypeId(int? TypeId);

        List<IndustryViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(IndustryViewModel objModel);

        bool Update(IndustryViewModel objModel);

        bool Delete(IndustryViewModel objModel);
    }
}
