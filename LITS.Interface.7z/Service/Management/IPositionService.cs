﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IPositionService
    {
        List<PositionViewModel> GetListAll();

        List<PositionViewModel> GetListById(int? Id);

        List<PositionViewModel> GetListByStatusId(int? StatusId);

        List<PositionViewModel> GetListByTypeId(int? TypeId);

        List<PositionViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<PositionViewModel> GetListActiveAll();

        List<PositionViewModel> GetListActiveById(int? Id);

        List<PositionViewModel> GetListActiveByStatusId(int? StatusId);

        List<PositionViewModel> GetListActiveByTypeId(int? TypeId);

        List<PositionViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(PositionViewModel objModel);

        bool Update(PositionViewModel objModel);

        bool Delete(PositionViewModel objModel);
    }
}
