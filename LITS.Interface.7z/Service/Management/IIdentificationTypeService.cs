﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IIdentificationTypeService
    {
        List<IdentificationTypeViewModel> GetListAll();

        List<IdentificationTypeViewModel> GetListById(int? Id);

        List<IdentificationTypeViewModel> GetListByStatusId(int? StatusId);

        List<IdentificationTypeViewModel> GetListByTypeId(int? TypeId);

        List<IdentificationTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<IdentificationTypeViewModel> GetListActiveAll();

        List<IdentificationTypeViewModel> GetListActiveById(int? Id);

        List<IdentificationTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<IdentificationTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<IdentificationTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(IdentificationTypeViewModel objModel);

        bool Update(IdentificationTypeViewModel objModel);

        bool Delete(IdentificationTypeViewModel objModel);
    }
}
