﻿using System;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

using LITS.Interface.Service.Main.CreateNewLoan;
using LITS.Interface.Repository.Main.CreateNewLoan;
using LITS.Interface.Repository.Management;

using LITS.Model.PartialViews.Main.CreateNewLoan;
using LITS.Model.Views.Main;

namespace LITS.Service.Main.CreateNewLoan
{
    public class CreateNewLoanService : ICreateNewLoanService
    {
        private readonly ICreateNewLoanRepository _CreateNewLoanRepository;
        private readonly ICreateNewLoanStep1Repository _CreateNewLoanStep1Repository;
        private readonly ICreateNewLoanStep2Repository _CreateNewLoanStep2Repository;
        private readonly ICreateNewLoanStep3Repository _CreateNewLoanStep3Repository;

        private readonly IIdentificationTypeRepository _IdentificationTypeRepository;
        private readonly ICompanyTypeRepository _CompanyTypeRepository;

        private LITSEntities _LITSEntities;

        private readonly IUnitOfWork _unitOfWork;

        public CreateNewLoanService(ICreateNewLoanRepository createNewLoanRepository,
            ICreateNewLoanStep1Repository createNewLoanStep1Repository,
            ICreateNewLoanStep2Repository createNewLoanStep2Repository,
            ICreateNewLoanStep3Repository createNewLoanStep3Repository,
            IIdentificationTypeRepository IdentificationTypeRepository,
            ICompanyTypeRepository CompanyTypeRepository,
            IUnitOfWork unitOfWork,
            LITSEntities litsEntities)
        {
            this._CreateNewLoanRepository = createNewLoanRepository;
            this._CreateNewLoanStep1Repository = createNewLoanStep1Repository;
            this._CreateNewLoanStep2Repository = createNewLoanStep2Repository;
            this._CreateNewLoanStep3Repository = createNewLoanStep3Repository;
            this._IdentificationTypeRepository = IdentificationTypeRepository;
            this._CompanyTypeRepository = CompanyTypeRepository;
            this._unitOfWork = unitOfWork;
            this._LITSEntities = litsEntities;
        }

        /// <summary>
        /// LoadIndexStep1
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="strAreaName"></param>
        /// <param name="strControllerName"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep1(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {           
            objParam._CreateNewLoanStep1ViewModel = _CreateNewLoanRepository.LoadIndexStep1(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam).
                _CreateNewLoanStep1ViewModel;           

            return objParam;
        }

        /// <summary>
        /// LoadIndexStep2
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="strAreaName"></param>
        /// <param name="strControllerName"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep2(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam._CreateNewLoanStep2ViewModel._M_IdentificationTypeViewModel = _IdentificationTypeRepository.
               GetListActiveByTypeId((int)objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID);

            objParam._CreateNewLoanStep2ViewModel._M_CompanyTypeViewModel = _CompanyTypeRepository.
                GetListActiveByTypeId((int)objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID);

            return objParam;
        }

        /// <summary>
        /// LoadIndexStep3
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="strAreaName"></param>
        /// <param name="strControllerName"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep3(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// Submit
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="strAreaName"></param>
        /// <param name="strControllerName"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel Submit(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            _unitOfWork.Commit();
            return objParam;
        }
    }
}
