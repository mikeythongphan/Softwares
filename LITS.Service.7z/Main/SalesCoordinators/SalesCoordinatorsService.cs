﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Interface.Service.Main.SalesCoordinators;
using LITS.Interface.Repository.Main.SalesCoordinators;
using LITS.Infrastructure.Factory;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main.SalesCoordinators;
using LITS.Infrastructure.Context;

namespace LITS.Service.Main.SalesCoordinators
{
    public class SalesCoordinatorsService : ISalesCoordinatorsService
    {
        private readonly ISalesCoordinatorsRepository _salesCoordinatorsRepository;
        private readonly ICustomerIdentificationRepository _customerIdentificationRepository;
        private readonly IUnitOfWork _unitOfWork;

        public SalesCoordinatorsService(ISalesCoordinatorsRepository salesCoordinatorsRepository,
            ICustomerIdentificationRepository customerIdentificationRepository, 
            IUnitOfWork unitOfWork)
        {
            this._salesCoordinatorsRepository = salesCoordinatorsRepository;
            this._customerIdentificationRepository = customerIdentificationRepository;
            this._unitOfWork = unitOfWork;
        }

        #region SalesCoordinatorsService Members

        public SalesCoordinatorsViewModel GetSalesCoordinatorsByAppId(int? Id)
        {
            SalesCoordinatorsViewModel obj = new SalesCoordinatorsViewModel();

            return obj;
        }

        public application_information GetApplicationInformation()
        {
            application_information obj = new application_information();

            return obj;
        }

        public customer_information GetCustomerInformation(int? Id)
        {
            customer_information obj = new customer_information();

            return obj;
        }

        public IEnumerable<customer_identification> GetCustomerIdentificationByCustId(int CustId)
        {
            List<customer_identification> obj = new List<customer_identification>();
            obj = _customerIdentificationRepository.GetMany(c => c.fk_customer_information_id == CustId).ToList();
            return obj;
        }

        public void CreateSalesCoordinators(SalesCoordinatorsViewModel sc)
        { }

        public void DeleteSalesCoordinators(int? Id)
        { }

        public void SaveSalesCoordinators()
        { }

        #endregion
    }
}
