﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Service.AutoLoan.CreditInitiative
{
    public class ApprovalInformationService : IApprovalInformationService
    {
        public ApprovalInformationService()
        {
        }

        public void Create(ApprovalInformationViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        approval_information data = AutoMapper.Mapper.Map<ApprovalInformationViewModel, approval_information>(sc);

                        context.approval_information.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(ApprovalInformationViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<ApprovalInformationViewModel, approval_information>(obj);
                            context.approval_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public ApprovalInformationViewModel GetAll()
        {
            throw new NotImplementedException();
        }


        public ApprovalInformationViewModel GetById(int? Id)
        {
            ApprovalInformationViewModel obj = new ApprovalInformationViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.approval_information.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<approval_information, ApprovalInformationViewModel>(data);
            return obj;
        }

        public void Update(ApprovalInformationViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<ApprovalInformationViewModel, approval_information>(obj);
                        context.approval_information.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
