﻿using System;
using System.Linq;
using System.Data.Entity;

#region Infrastructure
using LITS.Infrastructure.Factory;
#endregion

#region Interface
using LITS.Interface.Service.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.Management;
#endregion

#region Model
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
#endregion

namespace LITS.Service.AutoLoan.SalesCoordinators
{
    public class SalesCoordinatorsService : ISalesCoordinatorsService
    {
        #region SalesCoordinators
        private readonly ISalesCoordinatorsRepository _SalesCoordinatorsRepository;
        private readonly IApplicationInformationRepository _ApplicationInformationRepository;
        private readonly IAppliedLoanInformationRepository _AppliedLoanInformationRepository;
        private readonly IARTARepository _ARTARepository;
        private readonly ICarDealerInformationRepository _CarDealerInformationRepository;
        private readonly ICollateralInformationRepository _CollateralInformationRepository;
        private readonly ICustomerInformationRepository _CustomerInformationRepository;
        private readonly ICustomerCreditBureauRepository _CustomerCreditBureauRepository;
        private readonly ICustomerDemostrationRepository _CustomerDemostrationRepository;
        private readonly ICustomerIncomeRepository _CustomerIncomeRepository;
        #endregion

        #region MetaData
        private readonly IBranchCodeRepository _BranchCodeRepository;
        private readonly IBranchLocationRepository _BranchLocationRepository;
        private readonly ICustomerTypeRepository _CustomerTypeRepository;
        private readonly IFloatingInterestRateRepository _FloatingInterestRateRepository;
        private readonly ILoanPurposeRepository _LoanPurposeRepository;
        private readonly ILoanTenorRepository _LoanTenorRepository;
        private readonly IPaymentTypeRepository _PaymentTypeRepository;
        private readonly IProductTypeRepository _ProductTypeRepository;
        private readonly IProductRepository _ProductRepository;
        private readonly IProgramTypeRepository _ProgramTypeRepository;
        private readonly IPropertySaleRepository _PropertySaleRepository;
        private readonly IPropertyStatusRepository _PropertyStatusRepository;
        private readonly IPropertyTypeRepository _PropertyTypeRepository;
        private readonly ITradingAreaRepository _TradingAreaRepository;
        private readonly IIncomeTypeRepository _IncomeTypeRepository;
        private readonly ISalesChannelRepository _SalesChannelRepository;
        private readonly ICustomerSegmentRepository _CustomerSegmentRepository;
        private readonly ICustomerRelationshipRepository _CustomerRelationshipRepository;
        private readonly ICDDRepository _CDDRepository;
        private readonly ICICRepository _CICRepository;
        private readonly IReasonRepository _ReasonRepository;
        private readonly IStatusRepository _StatusRepository;
        private readonly ITypeRepository _TypeRepository;
        #endregion

        private readonly IUnitOfWork _unitOfWork;

        public SalesCoordinatorsService(ISalesCoordinatorsRepository SalesCoordinatorsRepository,
            IApplicationInformationRepository ApplicationInformationRepository,
            IAppliedLoanInformationRepository AppliedLoanInformationRepository,
            IARTARepository ARTARepository,
            ICarDealerInformationRepository CarDealerInformationRepository,
            ICollateralInformationRepository CollateralInformationRepository,
            ICustomerInformationRepository CustomerInformationRepository,
            ICustomerCreditBureauRepository CustomerCreditBureauRepository,
            ICustomerDemostrationRepository CustomerDemostrationRepository,
            ICustomerIncomeRepository CustomerIncomeRepository,
            IBranchCodeRepository BranchCodeRepository,
            IBranchLocationRepository BranchLocationRepository,
            ICustomerTypeRepository CustomerTypeRepository,
            IFloatingInterestRateRepository FloatingInterestRateRepository,
            ILoanPurposeRepository LoanPurposeRepository,
            ILoanTenorRepository LoanTenorRepository,
            IPaymentTypeRepository PaymentTypeRepository,
            IProductTypeRepository ProductTypeRepository,
            IProductRepository ProductRepository,
            IProgramTypeRepository ProgramTypeRepository,
            IPropertySaleRepository PropertySaleRepository,
            IPropertyStatusRepository PropertyStatusRepository,
            IPropertyTypeRepository PropertyTypeRepository,
            ITradingAreaRepository TradingAreaRepository,
            IIncomeTypeRepository IncomeTypeRepository,
            ISalesChannelRepository SalesChannelRepository,
            ICustomerSegmentRepository CustomerSegmentRepository,
            ICustomerRelationshipRepository CustomerRelationshipRepository,
            ICDDRepository CDDRepository,
            ICICRepository CICRepository,
            IReasonRepository ReasonRepository,
            IStatusRepository StatusRepository,
            ITypeRepository TypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._SalesCoordinatorsRepository = SalesCoordinatorsRepository;
            this._ApplicationInformationRepository = ApplicationInformationRepository;
            this._AppliedLoanInformationRepository = AppliedLoanInformationRepository;
            this._ARTARepository = ARTARepository;
            this._CarDealerInformationRepository = CarDealerInformationRepository;
            this._CollateralInformationRepository = CollateralInformationRepository;
            this._CustomerInformationRepository = CustomerInformationRepository;
            this._CustomerCreditBureauRepository = CustomerCreditBureauRepository;
            this._CustomerDemostrationRepository = CustomerDemostrationRepository;
            this._CustomerIncomeRepository = CustomerIncomeRepository;
            this._BranchCodeRepository = BranchCodeRepository;
            this._BranchLocationRepository = BranchLocationRepository;
            this._CustomerTypeRepository = CustomerTypeRepository;
            this._FloatingInterestRateRepository = FloatingInterestRateRepository;
            this._LoanPurposeRepository = LoanPurposeRepository;
            this._LoanTenorRepository = LoanTenorRepository;
            this._PaymentTypeRepository = PaymentTypeRepository;
            this._ProductTypeRepository = ProductTypeRepository;
            this._ProductRepository = ProductRepository;
            this._ProgramTypeRepository = ProgramTypeRepository;
            this._PropertySaleRepository = PropertySaleRepository;
            this._PropertyStatusRepository = PropertyStatusRepository;
            this._PropertyTypeRepository = PropertyTypeRepository;
            this._TradingAreaRepository = TradingAreaRepository;
            this._IncomeTypeRepository = IncomeTypeRepository;
            this._SalesChannelRepository = SalesChannelRepository;
            this._CustomerSegmentRepository = CustomerSegmentRepository;
            this._CustomerRelationshipRepository = CustomerRelationshipRepository;
            this._CDDRepository = CDDRepository;
            this._CICRepository = CICRepository;
            this._ReasonRepository = ReasonRepository;
            this._StatusRepository = StatusRepository;
            this._TypeRepository = TypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public SalesCoordinatorsViewModel LoadIndex(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            #region MetaData
            objParam._M_BranchCodeViewModel = _BranchCodeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_BranchLocationViewModel = _BranchLocationRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerTypeViewModel = _CustomerTypeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_FloatingInterestRateViewModel = _FloatingInterestRateRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_LoanPurposeViewModel = _LoanPurposeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_LoanTenorViewModel = _LoanTenorRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PaymentTypeViewModel = _PaymentTypeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_ProductViewModel = _ProductRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_ProgramTypeViewModel = _ProgramTypeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PropertySaleViewModel = _PropertySaleRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PropertyStatusViewModel = _PropertyStatusRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PropertyTypeViewModel = _PropertyTypeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_TradingAreaViewModel = _TradingAreaRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_StatusViewModel = _StatusRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_TypeViewModel = _TypeRepository.GetListActiveById((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_SalesChannelViewModel = _SalesChannelRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerSegmentViewModel = _CustomerSegmentRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_ReasonViewModel = _ReasonRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CDDViewModel = _CDDRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            #endregion

            return _SalesCoordinatorsRepository.LoadIndex(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        public SalesCoordinatorsViewModel Save(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _SalesCoordinatorsRepository.Save(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        public SalesCoordinatorsViewModel Submit(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _SalesCoordinatorsRepository.Submit(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        public SalesCoordinatorsViewModel NSG(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _SalesCoordinatorsRepository.NSG(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        public SalesCoordinatorsViewModel Cancel(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _SalesCoordinatorsRepository.Cancel(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        public SalesCoordinatorsViewModel Delete(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _SalesCoordinatorsRepository.Delete(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        public SalesCoordinatorsViewModel FRMQueue(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _SalesCoordinatorsRepository.FRMQueue(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }
    }
}
