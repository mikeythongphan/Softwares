﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using System.Data.Entity;

namespace LITS.Service.AutoLoan.SalesCoordinators
{
    public class CustomerInformationService : ICustomerInformationService
    {
        public CustomerInformationService()
        {
        }

        #region ApplicationInformationService Members
        /// <summary>
        /// Application Information ViewModel
        /// </summary>
        /// <param name="Id">int</param>
        public CustomerInformationViewModel GetById(int? Id)
        {
            CustomerInformationViewModel obj = new CustomerInformationViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.customer_information.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<customer_information, CustomerInformationViewModel>(data);
            return obj;
        }
        /// <summary>
        /// GetAll
        /// </summary>
        /// <returns></returns>
        public CustomerInformationViewModel GetAll()
        {
            CustomerInformationViewModel obj = new CustomerInformationViewModel();
            return obj;
        }

        /// <summary>
        /// Create
        /// </summary>
        /// <param name="sc">ApplicationInformationViewModel</param>
        public void Create(CustomerInformationViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        customer_information data = AutoMapper.Mapper.Map<CustomerInformationViewModel, customer_information>(sc);

                        context.customer_information.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="obj">ApplicationInformationViewModel</param>
        public void Update(CustomerInformationViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<CustomerInformationViewModel, customer_information>(obj);
                        context.customer_information.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="id">int</param>
        public void Delete(CustomerInformationViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            CustomerInformationViewModel model = obj;
                            //model.IsActive = false;
                            var data = AutoMapper.Mapper.Map<CustomerInformationViewModel, customer_information>(model);
                            context.customer_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Save
        /// </summary>
        public void Save()
        { }

        #endregion
    }
}
