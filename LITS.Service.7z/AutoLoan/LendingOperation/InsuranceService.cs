﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.LendingOperation;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;

namespace LITS.Service.AutoLoan.LendingOperation
{
    public class InsuranceService : IInsuranceService
    {
        public void Create(InsuranceViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_personal_application data = AutoMapper.Mapper.Map<InsuranceViewModel, al_personal_application>(sc);

                        context.al_personal_application.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(InsuranceViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<InsuranceViewModel, al_personal_application>(obj);
                            context.al_personal_application.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public InsuranceViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public InsuranceViewModel GetById(int? Id)
        {
            InsuranceViewModel obj = new InsuranceViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.al_personal_application.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<al_personal_application, InsuranceViewModel>(data);
            return obj;
        }

        public void Update(InsuranceViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<InsuranceViewModel, al_personal_application>(obj);

                        context.al_personal_application.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
