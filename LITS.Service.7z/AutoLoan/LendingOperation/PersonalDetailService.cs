﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.LendingOperation;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;

namespace LITS.Service.AutoLoan.LendingOperation
{
    public class PersonalDetailService : IPersonalDetailService
    {
        public void Create(PersonalDetailViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        disbursement_information data = AutoMapper.Mapper.Map<PersonalDetailViewModel, disbursement_information>(sc);

                        context.disbursement_information.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(PersonalDetailViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<PersonalDetailViewModel, disbursement_information>(obj);
                            context.disbursement_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public PersonalDetailViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public PersonalDetailViewModel GetById(int? Id)
        {
            PersonalDetailViewModel obj = new PersonalDetailViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.disbursement_information.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<disbursement_information, PersonalDetailViewModel>(data);
            return obj;
        }

        public void Update(PersonalDetailViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<PersonalDetailViewModel, disbursement_information>(obj);

                        context.disbursement_information.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
