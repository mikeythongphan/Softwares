﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.OperationSupport;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using System.Data.Entity;

namespace LITS.Service.AutoLoan.OperationSupport
{
    public class AppliedLoanInformationService : IAppliedLoanInformationService
    {


        /// <summary>
        /// Application Information Service
        /// </summary>
        /// <param name="applicationInformationRepository">ICustomerInformationRepository</param>
        /// <param name="unitOfWork">IUnitOfWork</param>
        public AppliedLoanInformationService()
        {

        }

        #region ApplicationInformationService Members
        /// <summary>
        /// Application Information ViewModel
        /// </summary>
        /// <param name="Id">int</param>
        public AppliedLoanInformationViewModel GetById(int? Id)
        {
            AppliedLoanInformationViewModel obj = new AppliedLoanInformationViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.al_personal_application.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<al_personal_application, AppliedLoanInformationViewModel>(data);
            return obj;
        }
        /// <summary>
        /// GetAll
        /// </summary>
        /// <returns></returns>
        public AppliedLoanInformationViewModel GetAll()
        {
            AppliedLoanInformationViewModel obj = new AppliedLoanInformationViewModel();
            return obj;
        }
        /// <summary>
        /// GetApplicationInformation
        /// </summary>
        /// <param name="Id">int</param>
        /// <returns></returns>
        //public application_information GetApplicationInformation(int? Id)
        //{
        //    application_information obj = new application_information();
        //    return obj;
        //}

        /// <summary>
        /// Create
        /// </summary>
        /// <param name="sc">ApplicationInformationViewModel</param>
        public void Create(AppliedLoanInformationViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_personal_application data = AutoMapper.Mapper.Map<AppliedLoanInformationViewModel, al_personal_application>(sc);

                        context.al_personal_application.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="obj">ApplicationInformationViewModel</param>
        public void Update(AppliedLoanInformationViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<AppliedLoanInformationViewModel, al_personal_application>(obj);

                        context.al_personal_application.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="id">int</param>
        public void Delete(AppliedLoanInformationViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            AppliedLoanInformationViewModel model = obj;
                            model.IsActive = false;
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<AppliedLoanInformationViewModel, al_personal_application>(model);
                            context.al_personal_application.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Save
        /// </summary>
        public void Save()
        { }

        #endregion
    }
}
