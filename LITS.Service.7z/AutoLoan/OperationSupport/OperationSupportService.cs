﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#region Infrastructure
using LITS.Infrastructure.Factory;
#endregion

#region Interface
using LITS.Interface.Service.AutoLoan.OperationSupport;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Interface.Repository.Management;
#endregion

#region Model
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
#endregion

namespace LITS.Service.AutoLoan.OperationSupport
{
    public class OperationSupportService : IOperationSupportService
    {

    }
}
