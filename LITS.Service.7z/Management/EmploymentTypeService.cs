﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class EmploymentTypeService : IEmploymentTypeService
    {
        private readonly IEmploymentTypeRepository _EmploymentTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public EmploymentTypeService(IEmploymentTypeRepository EmploymentTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._EmploymentTypeRepository = EmploymentTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<EmploymentTypeViewModel> GetListAll()
        {
            return _EmploymentTypeRepository.GetListAll();
        }

        public List<EmploymentTypeViewModel> GetListById(int? Id)
        {
            return _EmploymentTypeRepository.GetListById(Id);
        }

        public List<EmploymentTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _EmploymentTypeRepository.GetListByStatusId(StatusId);
        }

        public List<EmploymentTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _EmploymentTypeRepository.GetListByTypeId(TypeId);
        }

        public List<EmploymentTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _EmploymentTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<EmploymentTypeViewModel> GetListActiveAll()
        {
            return _EmploymentTypeRepository.GetListActiveAll();
        }

        public List<EmploymentTypeViewModel> GetListActiveById(int? Id)
        {
            return _EmploymentTypeRepository.GetListActiveById(Id);
        }

        public List<EmploymentTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _EmploymentTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<EmploymentTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _EmploymentTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<EmploymentTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _EmploymentTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(EmploymentTypeViewModel objModel)
        {
            return _EmploymentTypeRepository.Create(objModel);
        }

        public bool Update(EmploymentTypeViewModel objModel)
        {
            return _EmploymentTypeRepository.Update(objModel);
        }

        public bool Delete(EmploymentTypeViewModel objModel)
        {
            return _EmploymentTypeRepository.Delete(objModel);
        }
    }
}
