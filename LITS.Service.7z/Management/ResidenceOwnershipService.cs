﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class ResidenceOwnershipService : IResidenceOwnershipService
    {
        private readonly IResidenceOwnershipRepository _ResidenceOwnershipRepository;

        private readonly IUnitOfWork _unitOfWork;

        public ResidenceOwnershipService(IResidenceOwnershipRepository ResidenceOwnershipRepository,
            IUnitOfWork unitOfWork)
        {
            this._ResidenceOwnershipRepository = ResidenceOwnershipRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<ResidenceOwnershipViewModel> GetListAll()
        {
            return _ResidenceOwnershipRepository.GetListAll();
        }

        public List<ResidenceOwnershipViewModel> GetListById(int? Id)
        {
            return _ResidenceOwnershipRepository.GetListById(Id);
        }

        public List<ResidenceOwnershipViewModel> GetListByStatusId(int? StatusId)
        {
            return _ResidenceOwnershipRepository.GetListByStatusId(StatusId);
        }

        public List<ResidenceOwnershipViewModel> GetListByTypeId(int? TypeId)
        {
            return _ResidenceOwnershipRepository.GetListByTypeId(TypeId);
        }

        public List<ResidenceOwnershipViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _ResidenceOwnershipRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<ResidenceOwnershipViewModel> GetListActiveAll()
        {
            return _ResidenceOwnershipRepository.GetListActiveAll();
        }

        public List<ResidenceOwnershipViewModel> GetListActiveById(int? Id)
        {
            return _ResidenceOwnershipRepository.GetListActiveById(Id);
        }

        public List<ResidenceOwnershipViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _ResidenceOwnershipRepository.GetListActiveByStatusId(StatusId);
        }

        public List<ResidenceOwnershipViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _ResidenceOwnershipRepository.GetListActiveByTypeId(TypeId);
        }

        public List<ResidenceOwnershipViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _ResidenceOwnershipRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(ResidenceOwnershipViewModel objModel)
        {
            return _ResidenceOwnershipRepository.Create(objModel);
        }

        public bool Update(ResidenceOwnershipViewModel objModel)
        {
            return _ResidenceOwnershipRepository.Update(objModel);
        }

        public bool Delete(ResidenceOwnershipViewModel objModel)
        {
            return _ResidenceOwnershipRepository.Delete(objModel);
        }
    }
}
