﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class DisbursalScenarioService : IDisbursalScenarioService
    {
        private readonly IDisbursalScenarioRepository _DisbursalScenarioRepository;

        private readonly IUnitOfWork _unitOfWork;

        public DisbursalScenarioService(IDisbursalScenarioRepository DisbursalScenarioRepository,
            IUnitOfWork unitOfWork)
        {
            this._DisbursalScenarioRepository = DisbursalScenarioRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<DisbursalScenarioViewModel> GetListAll()
        {
            return _DisbursalScenarioRepository.GetListAll();
        }

        public List<DisbursalScenarioViewModel> GetListById(int? Id)
        {
            return _DisbursalScenarioRepository.GetListById(Id);
        }

        public List<DisbursalScenarioViewModel> GetListByStatusId(int? StatusId)
        {
            return _DisbursalScenarioRepository.GetListByStatusId(StatusId);
        }

        public List<DisbursalScenarioViewModel> GetListByTypeId(int? TypeId)
        {
            return _DisbursalScenarioRepository.GetListByTypeId(TypeId);
        }

        public List<DisbursalScenarioViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _DisbursalScenarioRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<DisbursalScenarioViewModel> GetListActiveAll()
        {
            return _DisbursalScenarioRepository.GetListActiveAll();
        }

        public List<DisbursalScenarioViewModel> GetListActiveById(int? Id)
        {
            return _DisbursalScenarioRepository.GetListActiveById(Id);
        }

        public List<DisbursalScenarioViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _DisbursalScenarioRepository.GetListActiveByStatusId(StatusId);
        }

        public List<DisbursalScenarioViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _DisbursalScenarioRepository.GetListActiveByTypeId(TypeId);
        }

        public List<DisbursalScenarioViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _DisbursalScenarioRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(DisbursalScenarioViewModel objModel)
        {
            return _DisbursalScenarioRepository.Create(objModel);
        }

        public bool Update(DisbursalScenarioViewModel objModel)
        {
            return _DisbursalScenarioRepository.Update(objModel);
        }

        public bool Delete(DisbursalScenarioViewModel objModel)
        {
            return _DisbursalScenarioRepository.Delete(objModel);
        }
    }
}
