﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class PropertyStatusService : IPropertyStatusService
    {
        private readonly IPropertyStatusRepository _PropertyStatusRepository;

        private readonly IUnitOfWork _unitOfWork;

        public PropertyStatusService(IPropertyStatusRepository PropertyStatusRepository,
            IUnitOfWork unitOfWork)
        {
            this._PropertyStatusRepository = PropertyStatusRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<PropertyStatusViewModel> GetListAll()
        {
            return _PropertyStatusRepository.GetListAll();
        }

        public List<PropertyStatusViewModel> GetListById(int? Id)
        {
            return _PropertyStatusRepository.GetListById(Id);
        }

        public List<PropertyStatusViewModel> GetListByStatusId(int? StatusId)
        {
            return _PropertyStatusRepository.GetListByStatusId(StatusId);
        }

        public List<PropertyStatusViewModel> GetListByTypeId(int? TypeId)
        {
            return _PropertyStatusRepository.GetListByTypeId(TypeId);
        }

        public List<PropertyStatusViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _PropertyStatusRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<PropertyStatusViewModel> GetListActiveAll()
        {
            return _PropertyStatusRepository.GetListActiveAll();
        }

        public List<PropertyStatusViewModel> GetListActiveById(int? Id)
        {
            return _PropertyStatusRepository.GetListActiveById(Id);
        }

        public List<PropertyStatusViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _PropertyStatusRepository.GetListActiveByStatusId(StatusId);
        }

        public List<PropertyStatusViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _PropertyStatusRepository.GetListActiveByTypeId(TypeId);
        }

        public List<PropertyStatusViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _PropertyStatusRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(PropertyStatusViewModel objModel)
        {
            return _PropertyStatusRepository.Create(objModel);
        }

        public bool Update(PropertyStatusViewModel objModel)
        {
            return _PropertyStatusRepository.Update(objModel);
        }

        public bool Delete(PropertyStatusViewModel objModel)
        {
            return _PropertyStatusRepository.Delete(objModel);
        }
    }
}
