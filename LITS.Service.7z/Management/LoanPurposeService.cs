﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class LoanPurposeService : ILoanPurposeService
    {
        private readonly ILoanPurposeRepository _LoanPurposeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public LoanPurposeService(ILoanPurposeRepository LoanPurposeRepository,
            IUnitOfWork unitOfWork)
        {
            this._LoanPurposeRepository = LoanPurposeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<LoanPurposeViewModel> GetListAll()
        {
            return _LoanPurposeRepository.GetListAll();
        }

        public List<LoanPurposeViewModel> GetListById(int? Id)
        {
            return _LoanPurposeRepository.GetListById(Id);
        }

        public List<LoanPurposeViewModel> GetListByStatusId(int? StatusId)
        {
            return _LoanPurposeRepository.GetListByStatusId(StatusId);
        }

        public List<LoanPurposeViewModel> GetListByTypeId(int? TypeId)
        {
            return _LoanPurposeRepository.GetListByTypeId(TypeId);
        }

        public List<LoanPurposeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _LoanPurposeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<LoanPurposeViewModel> GetListActiveAll()
        {
            return _LoanPurposeRepository.GetListActiveAll();
        }

        public List<LoanPurposeViewModel> GetListActiveById(int? Id)
        {
            return _LoanPurposeRepository.GetListActiveById(Id);
        }

        public List<LoanPurposeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _LoanPurposeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<LoanPurposeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _LoanPurposeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<LoanPurposeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _LoanPurposeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(LoanPurposeViewModel objModel)
        {
            return _LoanPurposeRepository.Create(objModel);
        }

        public bool Update(LoanPurposeViewModel objModel)
        {
            return _LoanPurposeRepository.Update(objModel);
        }

        public bool Delete(LoanPurposeViewModel objModel)
        {
            return _LoanPurposeRepository.Delete(objModel);
        }
    }
}
