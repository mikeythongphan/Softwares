﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class BankTypeService : IBankTypeService
    {
        private readonly IBankTypeRepository _BankTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public BankTypeService(IBankTypeRepository BankTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._BankTypeRepository = BankTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<BankTypeViewModel> GetListAll()
        {
            return _BankTypeRepository.GetListAll();
        }

        public List<BankTypeViewModel> GetListById(int? Id)
        {
            return _BankTypeRepository.GetListById(Id);
        }

        public List<BankTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _BankTypeRepository.GetListByStatusId(StatusId);
        }

        public List<BankTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _BankTypeRepository.GetListByTypeId(TypeId);
        }

        public List<BankTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BankTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<BankTypeViewModel> GetListActiveAll()
        {
            return _BankTypeRepository.GetListActiveAll();
        }

        public List<BankTypeViewModel> GetListActiveById(int? Id)
        {
            return _BankTypeRepository.GetListActiveById(Id);
        }

        public List<BankTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _BankTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<BankTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _BankTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<BankTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BankTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(BankTypeViewModel objModel)
        {
            return _BankTypeRepository.Create(objModel);
        }

        public bool Update(BankTypeViewModel objModel)
        {
            return _BankTypeRepository.Update(objModel);
        }

        public bool Delete(BankTypeViewModel objModel)
        {
            return _BankTypeRepository.Delete(objModel);
        }
    }
}
