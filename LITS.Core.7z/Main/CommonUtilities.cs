﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;

namespace LITS.Core.Main
{
    public class CommonUtilities
    {
        #region CreateActionLog
        /// <summary>
        /// CreateActionLog
        /// </summary>
        /// <param name="appId"></param>
        /// <param name="action"></param>
        /// <param name="actionBy"></param>
        public static void CreateActionLog(int appId, string action, string actionBy)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {

                        application_action_log appLog = new application_action_log();
                        appLog.fk_application_information_id = appId;
                        appLog.action = action;
                        appLog.action_by = actionBy;
                        appLog.action_date = DateTime.Now;
                        appLog.created_date = DateTime.Now;
                        appLog.created_by = actionBy;
                        appLog.fk_status_id = (int)EnumList.ActiveStatus.Active;
                        appLog.fk_type_id = (int)EnumList.Type.StatusRow;

                        context.application_action_log.Add(appLog);
                        context.SaveChanges();

                        context.Commit();
                    }
                    catch (Exception ex)
                    {
                        string errorMSG = string.Format("CheckBlackList::{0}", ex);
                        //Logger.Error(errorMSG);
                        transaction.Rollback();
                    }
                }
            }
        }

        #endregion

        #region CreateDataLog
        /// <summary>
        /// CreateAppChangedLog
        /// </summary>
        /// <param name="appId"></param>
        /// <param name="preValue"></param>
        /// <param name="currValue"></param>
        /// <param name="currentID"></param>
        public static void CreateAppChangedLog(int appId, string preValue, string currValue, string currentID)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        application_changed_log log = new application_changed_log();
                        log.fk_application_information_id = appId;
                        log.pre_value = preValue;
                        log.curr_value = currValue;
                        log.updated_date = DateTime.Now;
                        log.updated_by = currentID;
                        log.created_date = DateTime.Now;
                        log.created_by = currentID;
                        log.fk_status_id = (int)EnumList.ActiveStatus.Active;
                        log.fk_type_id = (int)EnumList.Type.StatusRow;

                        context.application_changed_log.Add(log);
                        context.SaveChanges();

                        context.Commit();
                    }
                    catch (Exception ex)
                    {
                        string errorMSG = string.Format("CreateAppChangedLog::{0}", ex);
                        //Logger.Error(errorMSG);
                        transaction.Rollback();
                    }
                }
            }
        }

        /// <summary>
        /// CreateAppChangedLog
        /// </summary>
        /// <param name="appId"></param>
        /// <param name="preValue"></param>
        /// <param name="currValue"></param>
        /// <param name="currentID"></param>
        /// <param name="logType"></param>
        public static void CreateAppChangedLog(int appId, string preValue, string currValue, string currentID, string logType)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        application_changed_log log = new application_changed_log();
                        log.fk_application_information_id = appId;
                        log.pre_value = preValue;
                        log.curr_value = currValue;
                        log.log_type = logType;
                        log.updated_date = DateTime.Now;
                        log.updated_by = currentID;
                        log.created_date = DateTime.Now;
                        log.created_by = currentID;
                        log.fk_status_id = (int)EnumList.ActiveStatus.Active;
                        log.fk_type_id = (int)EnumList.Type.StatusRow;

                        context.application_changed_log.Add(log);
                        context.SaveChanges();

                        context.Commit();
                    }
                    catch (Exception ex)
                    {
                        string errorMSG = string.Format("CreateAppChangedLog::{0}", ex);
                        //Logger.Error(errorMSG);
                        transaction.Rollback();
                    }
                }
            }
        }

        /// <summary>
        /// CreateAppChangedLogData
        /// </summary>
        /// <param name="appId"></param>
        /// <param name="changedValue"></param>
        /// <param name="currentID"></param>
        /// <param name="actionUserRole"></param>
        public static void CreateAppChangedLogData(int appId, string changedValue, string currentID, string actionUserRole)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        // update current records IsFinalData to false by (ApplicationNo and ActionUserRole)
                        //AppActionLogDataService.UpdateAppActionLogDataByActionUserRole(appNo, actionUserRole);

                        // create new log data
                        application_action_log_data dataLog = new application_action_log_data();
                        dataLog.fk_application_information_id = appId;
                        dataLog.changed_value = changedValue;
                        dataLog.action_by = currentID;
                        dataLog.action_date = DateTime.Now;
                        dataLog.action_user_role = actionUserRole;
                        dataLog.is_final_data = true;
                        dataLog.created_date = DateTime.Now;
                        dataLog.created_by = currentID;
                        dataLog.fk_status_id = (int)EnumList.ActiveStatus.Active;
                        dataLog.fk_type_id = (int)EnumList.Type.StatusRow;

                        context.application_action_log_data.Add(dataLog);
                        context.SaveChanges();

                        context.Commit();
                    }
                    catch (Exception ex)
                    {
                        string errorMSG = string.Format("CreateAppChangedLog::{0}", ex);
                        //Logger.Error(errorMSG);
                        transaction.Rollback();
                    }
                }
            }
        }

        /// <summary>
        /// CreateAppChangedLogDataWithoutMarkFinal
        /// </summary>
        /// <param name="appId"></param>
        /// <param name="changedValue"></param>
        /// <param name="currentID"></param>
        /// <param name="actionUserRole"></param>
        public static void CreateAppChangedLogDataWithoutMarkFinal(int appId, string changedValue, string currentID, string actionUserRole)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        application_action_log_data dataLog = new application_action_log_data();
                        dataLog.fk_application_information_id = appId;
                        dataLog.changed_value = changedValue;
                        dataLog.action_by = currentID;
                        dataLog.action_date = DateTime.Now;
                        dataLog.action_user_role = actionUserRole;
                        dataLog.created_date = DateTime.Now;
                        dataLog.created_by = currentID;
                        dataLog.fk_status_id = (int)EnumList.ActiveStatus.Active;
                        dataLog.fk_type_id = (int)EnumList.Type.StatusRow;

                        context.application_action_log_data.Add(dataLog);
                        context.SaveChanges();

                        context.Commit();
                    }
                    catch (Exception ex)
                    {
                        string errorMSG = string.Format("CreateAppChangedLog::{0}", ex);
                        //Logger.Error(errorMSG);
                        transaction.Rollback();
                    }
                }
            }
        }

        #endregion
    }
}